/* eslint-disable */

export {dl as ClipStyle} from '@int/impl/geotoolkit.base.js';
