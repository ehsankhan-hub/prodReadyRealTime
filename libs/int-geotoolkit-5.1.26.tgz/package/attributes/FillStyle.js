/* eslint-disable */

export {go as FillStyle} from '@int/impl/geotoolkit.base.js';
