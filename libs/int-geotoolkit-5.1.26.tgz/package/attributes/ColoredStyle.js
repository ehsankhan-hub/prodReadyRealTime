/* eslint-disable */

export {ro as ColoredStyle} from '@int/impl/geotoolkit.base.js';
