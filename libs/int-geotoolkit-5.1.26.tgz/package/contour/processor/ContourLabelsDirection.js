/* eslint-disable */

export {dGt as ContourLabelsDirection} from '@int/impl/geotoolkit.contour.js';
