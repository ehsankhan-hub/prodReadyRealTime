/* eslint-disable */

export {KLt as ColorMap} from '@int/impl/geotoolkit.contour.js';
