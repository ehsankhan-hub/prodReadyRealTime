/* eslint-disable */

export {lX as CgmExport} from '@int/impl/geotoolkit.cgm.js';
