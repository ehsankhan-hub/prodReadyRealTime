/* eslint-disable */

export {sDt as AspectRatioTrackWidthStrategy} from '@int/impl/geotoolkit.deviation.js';
