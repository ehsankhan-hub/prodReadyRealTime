/* eslint-disable */

export {gDt as DeviatedValueTransformer} from '@int/impl/geotoolkit.deviation.js';
