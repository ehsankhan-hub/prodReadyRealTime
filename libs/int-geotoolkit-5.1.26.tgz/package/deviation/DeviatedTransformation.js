/* eslint-disable */

export {Ndt as DeviatedTransformation} from '@int/impl/geotoolkit.deviation.js';
