/* eslint-disable */

export {ADt as DeviatedHeader} from '@int/impl/geotoolkit.deviation.js';
