/* eslint-disable */

export {vc as DocumentRenderingContext} from '@int/impl/geotoolkit.base.js';
