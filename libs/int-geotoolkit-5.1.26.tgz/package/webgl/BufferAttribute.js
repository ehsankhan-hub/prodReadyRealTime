/* eslint-disable */

export {OW as BufferAttribute} from '@int/impl/geotoolkit.base.js';
