/* eslint-disable */

export {JP as AbstractHandle} from '@int/impl/geotoolkit.controls.js';
