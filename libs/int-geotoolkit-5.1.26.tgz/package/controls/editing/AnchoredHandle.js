/* eslint-disable */

export {tU as AnchoredHandle} from '@int/impl/geotoolkit.controls.js';
