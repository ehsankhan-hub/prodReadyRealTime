/* eslint-disable */

export {nU as BoxHandle} from '@int/impl/geotoolkit.controls.js';
