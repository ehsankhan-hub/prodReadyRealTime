/* eslint-disable */

export {bD as ButtonRegistry} from '@int/impl/geotoolkit.controls.js';
