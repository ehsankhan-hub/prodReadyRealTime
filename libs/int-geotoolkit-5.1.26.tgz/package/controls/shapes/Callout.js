/* eslint-disable */

export {NF as Callout} from '@int/impl/geotoolkit.controls.js';
