/* eslint-disable */

export {aF as DonutChartLegendAdapter} from '@int/impl/geotoolkit.controls.js';
