/* eslint-disable */

export {FO as DataProvider} from '@int/impl/geotoolkit.controls.js';
