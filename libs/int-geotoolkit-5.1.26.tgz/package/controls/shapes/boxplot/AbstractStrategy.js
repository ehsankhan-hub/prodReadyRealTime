/* eslint-disable */

export {XF as AbstractStrategy, WF as BoxValueStatisticType} from '@int/impl/geotoolkit.controls.js';
