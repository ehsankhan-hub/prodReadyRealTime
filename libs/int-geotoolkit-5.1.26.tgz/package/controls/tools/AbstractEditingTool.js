/* eslint-disable */

export {BG as AbstractEditingTool} from '@int/impl/geotoolkit.controls.js';
