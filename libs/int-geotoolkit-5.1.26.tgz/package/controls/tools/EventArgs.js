/* eslint-disable */

export {QM as EventArgs} from '@int/impl/geotoolkit.controls.js';
