/* eslint-disable */

export {tk as CompositeTool} from '@int/impl/geotoolkit.controls.js';
