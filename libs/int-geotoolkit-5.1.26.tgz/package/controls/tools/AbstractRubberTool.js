/* eslint-disable */

export {TR as AbstractRubberTool} from '@int/impl/geotoolkit.controls.js';
