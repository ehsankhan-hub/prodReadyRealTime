/* eslint-disable */

export {LH as Delete} from '@int/impl/geotoolkit.controls.js';
