/* eslint-disable */

export {YG as DeleteNode} from '@int/impl/geotoolkit.controls.js';
