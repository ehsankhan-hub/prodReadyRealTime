/* eslint-disable */

export {EG as DragPoint} from '@int/impl/geotoolkit.controls.js';
