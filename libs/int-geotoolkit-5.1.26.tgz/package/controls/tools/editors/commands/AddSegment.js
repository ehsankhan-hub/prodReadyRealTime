/* eslint-disable */

export {bG as AddSegment} from '@int/impl/geotoolkit.controls.js';
