/* eslint-disable */

export {HG as Flip} from '@int/impl/geotoolkit.controls.js';
