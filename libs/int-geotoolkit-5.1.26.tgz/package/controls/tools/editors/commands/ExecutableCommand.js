/* eslint-disable */

export {OG as ExecutableCommand} from '@int/impl/geotoolkit.controls.js';
