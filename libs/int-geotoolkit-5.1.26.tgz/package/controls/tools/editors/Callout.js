/* eslint-disable */

export {fT as Callout} from '@int/impl/geotoolkit.controls.js';
