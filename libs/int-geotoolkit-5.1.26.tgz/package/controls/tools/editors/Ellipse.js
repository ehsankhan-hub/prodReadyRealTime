/* eslint-disable */

export {VT as Ellipse} from '@int/impl/geotoolkit.controls.js';
