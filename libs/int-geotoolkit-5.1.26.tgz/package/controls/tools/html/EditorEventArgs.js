/* eslint-disable */

export {IH as EditorEventArgs} from '@int/impl/geotoolkit.controls.js';
