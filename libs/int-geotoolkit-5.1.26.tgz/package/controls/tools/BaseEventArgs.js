/* eslint-disable */

export {bM as BaseEventArgs} from '@int/impl/geotoolkit.controls.js';
