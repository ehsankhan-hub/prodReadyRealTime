/* eslint-disable */

export {RR as DOMEventArgs} from '@int/impl/geotoolkit.controls.js';
