/* eslint-disable */

export {cG as EditEvents} from '@int/impl/geotoolkit.controls.js';
