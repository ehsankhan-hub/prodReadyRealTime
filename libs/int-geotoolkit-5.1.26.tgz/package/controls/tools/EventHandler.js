/* eslint-disable */

export {WM as EventHandler} from '@int/impl/geotoolkit.controls.js';
