/* eslint-disable */

export {$R as DOMSupport} from '@int/impl/geotoolkit.controls.js';
