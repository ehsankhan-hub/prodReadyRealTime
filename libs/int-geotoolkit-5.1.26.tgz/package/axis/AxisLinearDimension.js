/* eslint-disable */

export {II as AxisLinearDimension} from '@int/impl/geotoolkit.base.js';
