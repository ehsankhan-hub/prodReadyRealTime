/* eslint-disable */

export {dI as CurvedAxis} from '@int/impl/geotoolkit.base.js';
