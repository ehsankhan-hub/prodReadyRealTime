/* eslint-disable */

export {xC as AdaptiveDateTimeTickGenerator} from '@int/impl/geotoolkit.base.js';
