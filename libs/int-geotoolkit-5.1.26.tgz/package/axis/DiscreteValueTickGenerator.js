/* eslint-disable */

export {Ag as DiscreteValueTickGenerator} from '@int/impl/geotoolkit.base.js';
