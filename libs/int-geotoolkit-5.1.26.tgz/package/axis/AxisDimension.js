/* eslint-disable */

export {ng as AxisDimension, eg as Events} from '@int/impl/geotoolkit.base.js';
