/* eslint-disable */

export {pI as AxisMappingDimension} from '@int/impl/geotoolkit.base.js';
