/* eslint-disable */

export {GI as AdaptiveTangentialTickGenerator} from '@int/impl/geotoolkit.base.js';
