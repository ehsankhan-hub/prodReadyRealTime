/* eslint-disable */

export {Mg as DateTimeTickGenerator, fg as LabelMode} from '@int/impl/geotoolkit.base.js';
