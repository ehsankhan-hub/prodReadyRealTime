/* eslint-disable */

export {SI as AxisFactory} from '@int/impl/geotoolkit.base.js';
