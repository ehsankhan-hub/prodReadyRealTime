/* eslint-disable */

export {kI as Axis} from '@int/impl/geotoolkit.base.js';
