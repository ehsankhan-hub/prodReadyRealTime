/* eslint-disable */

export {iy as AnnotationTitleFactory} from '@int/impl/geotoolkit.base.js';
