/* eslint-disable */

export {pc as AnchoredShape} from '@int/impl/geotoolkit.base.js';
