/* eslint-disable */

export {qy as ColoredSpline} from '@int/impl/geotoolkit.base.js';
