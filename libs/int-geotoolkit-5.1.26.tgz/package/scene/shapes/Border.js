/* eslint-disable */

export {_g as Border, Hg as BorderStyle} from '@int/impl/geotoolkit.base.js';
