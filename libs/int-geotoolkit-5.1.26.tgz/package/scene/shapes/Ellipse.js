/* eslint-disable */

export {Oy as Ellipse} from '@int/impl/geotoolkit.base.js';
