/* eslint-disable */

export {tE as ColoredPolyline} from '@int/impl/geotoolkit.base.js';
