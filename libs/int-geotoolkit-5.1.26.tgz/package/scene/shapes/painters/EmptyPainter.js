/* eslint-disable */

export {yb as EmptyPainter} from '@int/impl/geotoolkit.base.js';
