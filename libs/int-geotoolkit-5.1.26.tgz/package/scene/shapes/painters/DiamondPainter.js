/* eslint-disable */

export {Eb as DiamondPainter} from '@int/impl/geotoolkit.base.js';
