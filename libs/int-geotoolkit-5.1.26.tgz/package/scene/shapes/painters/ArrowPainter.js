/* eslint-disable */

export {vb as ArrowPainter} from '@int/impl/geotoolkit.base.js';
