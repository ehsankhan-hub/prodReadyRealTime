/* eslint-disable */

export {bb as CrossPainter} from '@int/impl/geotoolkit.base.js';
