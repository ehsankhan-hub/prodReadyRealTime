/* eslint-disable */

export {Db as AimPainter} from '@int/impl/geotoolkit.base.js';
