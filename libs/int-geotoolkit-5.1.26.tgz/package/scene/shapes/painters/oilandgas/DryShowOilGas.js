/* eslint-disable */

export {tQ as DryShowOilGas} from '@int/impl/geotoolkit.base.js';
