/* eslint-disable */

export {Jb as Brine} from '@int/impl/geotoolkit.base.js';
