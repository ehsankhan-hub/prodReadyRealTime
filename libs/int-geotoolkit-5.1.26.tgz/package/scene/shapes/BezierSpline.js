/* eslint-disable */

export {Hr as BezierControlPoints} from '@int/impl/geotoolkit.base.js';
