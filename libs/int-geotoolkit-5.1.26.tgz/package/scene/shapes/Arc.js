/* eslint-disable */

export {nE as Arc} from '@int/impl/geotoolkit.base.js';
