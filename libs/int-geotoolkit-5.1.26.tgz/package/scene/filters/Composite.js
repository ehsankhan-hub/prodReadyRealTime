/* eslint-disable */

export {uE as Composite} from '@int/impl/geotoolkit.base.js';
