/* eslint-disable */

export {td as AutoModelLimitsStrategy} from '@int/impl/geotoolkit.base.js';
