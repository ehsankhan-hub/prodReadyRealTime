/* eslint-disable */

export {jB as AnchoredTransformationAdjustmentStrategy} from '@int/impl/geotoolkit.base.js';
