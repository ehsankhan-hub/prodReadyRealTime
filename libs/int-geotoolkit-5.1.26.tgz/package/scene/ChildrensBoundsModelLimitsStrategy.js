/* eslint-disable */

export {ly as ChildrensBoundsModelLimitsStrategy} from '@int/impl/geotoolkit.base.js';
