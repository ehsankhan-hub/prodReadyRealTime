/* eslint-disable */

export {mw as CustomPaperFormat} from '@int/impl/geotoolkit.base.js';
