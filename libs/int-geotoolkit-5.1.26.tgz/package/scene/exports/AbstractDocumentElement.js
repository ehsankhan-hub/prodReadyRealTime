/* eslint-disable */

export {nw as AbstractDocumentElement} from '@int/impl/geotoolkit.base.js';
