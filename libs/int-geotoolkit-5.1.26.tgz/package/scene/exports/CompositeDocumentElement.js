/* eslint-disable */

export {aw as CompositeDocumentElement} from '@int/impl/geotoolkit.base.js';
