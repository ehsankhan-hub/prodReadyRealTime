/* eslint-disable */

export {pE as DocumentElement} from '@int/impl/geotoolkit.base.js';
