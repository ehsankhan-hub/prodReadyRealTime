/* eslint-disable */

export {Iw as AbstractPaperFormat} from '@int/impl/geotoolkit.base.js';
