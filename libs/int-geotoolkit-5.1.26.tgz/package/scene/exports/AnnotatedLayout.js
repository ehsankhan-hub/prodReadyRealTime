/* eslint-disable */

export {yE as AnnotatedLayout} from '@int/impl/geotoolkit.base.js';
