/* eslint-disable */

export {mE as Document} from '@int/impl/geotoolkit.base.js';
