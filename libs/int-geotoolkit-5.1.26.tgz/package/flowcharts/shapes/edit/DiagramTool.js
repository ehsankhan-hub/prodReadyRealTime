/* eslint-disable */

export {Dut as DiagramTool} from '@int/impl/geotoolkit.flowcharts.js';
