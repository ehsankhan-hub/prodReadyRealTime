/* eslint-disable */

export {Sut as DiagramWidget} from '@int/impl/geotoolkit.flowcharts.js';
