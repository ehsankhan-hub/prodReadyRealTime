/* eslint-disable */

export {Zot as DiagramVisual} from '@int/impl/geotoolkit.flowcharts.js';
