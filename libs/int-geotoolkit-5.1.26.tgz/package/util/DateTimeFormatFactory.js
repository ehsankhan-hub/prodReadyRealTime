/* eslint-disable */

export {tC as DateTimeFormatFactory} from '@int/impl/geotoolkit.base.js';
