/* eslint-disable */

export {lh as AnchorType} from '@int/impl/geotoolkit.base.js';
