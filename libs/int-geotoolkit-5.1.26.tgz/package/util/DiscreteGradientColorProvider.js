/* eslint-disable */

export {bu as DiscreteGradientColorProvider} from '@int/impl/geotoolkit.base.js';
