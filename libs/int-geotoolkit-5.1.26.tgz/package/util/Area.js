/* eslint-disable */

export {rh as Area} from '@int/impl/geotoolkit.base.js';
