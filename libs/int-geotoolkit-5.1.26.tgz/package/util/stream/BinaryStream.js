/* eslint-disable */

export {Rv as BinaryStream} from '@int/impl/geotoolkit.base.js';
