/* eslint-disable */

export {Nv as BrowserMemoryStream} from '@int/impl/geotoolkit.base.js';
