/* eslint-disable */

export {Fv as BrowserFileStream} from '@int/impl/geotoolkit.base.js';
