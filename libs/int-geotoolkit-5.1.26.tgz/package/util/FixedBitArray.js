/* eslint-disable */

export {ev as FixedBitArray} from '@int/impl/geotoolkit.base.js';
