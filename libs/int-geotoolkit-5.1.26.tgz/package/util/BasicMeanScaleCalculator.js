/* eslint-disable */

export {pv as BasicMeanScaleCalculator} from '@int/impl/geotoolkit.base.js';
