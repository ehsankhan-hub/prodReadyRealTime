/* eslint-disable */

export {df as AutoNumberFormat} from '@int/impl/geotoolkit.base.js';
