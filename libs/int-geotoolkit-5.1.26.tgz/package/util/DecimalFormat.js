/* eslint-disable */

export {gf as DecimalFormat} from '@int/impl/geotoolkit.base.js';
