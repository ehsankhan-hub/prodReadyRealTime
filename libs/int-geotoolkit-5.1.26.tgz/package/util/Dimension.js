/* eslint-disable */

export {vh as Dimension} from '@int/impl/geotoolkit.base.js';
