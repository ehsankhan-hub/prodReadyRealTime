/* eslint-disable */

export {Iv as ArithmeticMeanScaleCalculator} from '@int/impl/geotoolkit.base.js';
