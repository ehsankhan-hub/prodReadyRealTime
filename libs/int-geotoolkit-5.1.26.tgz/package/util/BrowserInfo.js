/* eslint-disable */

export {Fn as BrowserInfo} from '@int/impl/geotoolkit.base.js';
