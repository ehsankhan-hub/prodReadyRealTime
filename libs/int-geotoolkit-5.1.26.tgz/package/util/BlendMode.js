/* eslint-disable */

export {zr as BlendMode} from '@int/impl/geotoolkit.base.js';
