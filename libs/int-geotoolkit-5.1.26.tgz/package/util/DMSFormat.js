/* eslint-disable */

export {fv as DMSFormat} from '@int/impl/geotoolkit.base.js';
