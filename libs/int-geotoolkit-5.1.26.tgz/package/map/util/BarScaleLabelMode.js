/* eslint-disable */

export {tlt as BarScaleLabelMode} from '@int/impl/geotoolkit.map.js';
