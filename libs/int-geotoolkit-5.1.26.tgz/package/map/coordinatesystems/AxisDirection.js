/* eslint-disable */

export {Qtt as AxisDirection} from '@int/impl/geotoolkit.map.js';
