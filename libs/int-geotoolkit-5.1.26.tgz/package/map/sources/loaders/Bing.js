/* eslint-disable */

export {Lht as Bing} from '@int/impl/geotoolkit.map.js';
