/* eslint-disable */

export {rnt as ArcGISFeature} from '@int/impl/geotoolkit.map.js';
