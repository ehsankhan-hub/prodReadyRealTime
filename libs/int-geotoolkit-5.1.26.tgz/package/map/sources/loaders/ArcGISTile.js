/* eslint-disable */

export {vnt as ArcGISTile} from '@int/impl/geotoolkit.map.js';
