/* eslint-disable */

export {wnt as ArcGISImage} from '@int/impl/geotoolkit.map.js';
