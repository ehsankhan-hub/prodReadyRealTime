/* eslint-disable */

export {tet as DOMImage} from '@int/impl/geotoolkit.map.js';
