/* eslint-disable */

export {ist as CompositeSource} from '@int/impl/geotoolkit.map.js';
