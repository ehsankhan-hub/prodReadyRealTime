/* eslint-disable */

export {yit as AbstractFormat} from '@int/impl/geotoolkit.map.js';
