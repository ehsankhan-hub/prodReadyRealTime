/* eslint-disable */

export {Vnt as ArcGISFeature} from '@int/impl/geotoolkit.map.js';
