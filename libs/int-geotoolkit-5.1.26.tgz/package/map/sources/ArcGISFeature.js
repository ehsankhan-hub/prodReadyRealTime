/* eslint-disable */

export {Knt as ArcGISFeature} from '@int/impl/geotoolkit.map.js';
