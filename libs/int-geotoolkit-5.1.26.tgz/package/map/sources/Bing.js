/* eslint-disable */

export {Tht as Bing} from '@int/impl/geotoolkit.map.js';
