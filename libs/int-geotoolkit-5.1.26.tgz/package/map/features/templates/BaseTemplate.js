/* eslint-disable */

export {Oit as BaseTemplate} from '@int/impl/geotoolkit.map.js';
