/* eslint-disable */

export {Jit as AnnotationById} from '@int/impl/geotoolkit.map.js';
