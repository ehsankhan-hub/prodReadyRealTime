/* eslint-disable */

export {uot as AnnotationByAttribute} from '@int/impl/geotoolkit.map.js';
