/* eslint-disable */

export {eit as Aggregation} from '@int/impl/geotoolkit.map.js';
