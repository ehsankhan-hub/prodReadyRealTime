/* eslint-disable */

export {wit as EvenOddGeometry} from '@int/impl/geotoolkit.map.js';
