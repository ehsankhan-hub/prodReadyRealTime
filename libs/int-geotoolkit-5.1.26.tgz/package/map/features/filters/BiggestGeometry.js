/* eslint-disable */

export {Jlt as BiggestGeometry} from '@int/impl/geotoolkit.map.js';
