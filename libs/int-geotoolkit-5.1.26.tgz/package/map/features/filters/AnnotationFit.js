/* eslint-disable */

export {Zlt as AnnotationFit} from '@int/impl/geotoolkit.map.js';
