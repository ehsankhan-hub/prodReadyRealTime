/* eslint-disable */

export {Klt as ComputedSorter} from '@int/impl/geotoolkit.map.js';
