/* eslint-disable */

export {mst as Edge} from '@int/impl/geotoolkit.map.js';
