/* eslint-disable */

export {_tt as AbstractFeature} from '@int/impl/geotoolkit.map.js';
