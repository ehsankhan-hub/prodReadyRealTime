/* eslint-disable */

export {sst as CompositeConverter} from '@int/impl/geotoolkit.map.js';
