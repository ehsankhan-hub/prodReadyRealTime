/* eslint-disable */

export {Hit as BaseConverter} from '@int/impl/geotoolkit.map.js';
