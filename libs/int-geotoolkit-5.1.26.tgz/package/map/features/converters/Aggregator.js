/* eslint-disable */

export {oot as Aggregator} from '@int/impl/geotoolkit.map.js';
