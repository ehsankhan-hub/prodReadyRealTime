/* eslint-disable */

export {kht as BingImagerySet} from '@int/impl/geotoolkit.map.js';
