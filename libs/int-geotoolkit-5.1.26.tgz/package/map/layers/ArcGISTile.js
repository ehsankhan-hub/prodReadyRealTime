/* eslint-disable */

export {Ult as ArcGISTile} from '@int/impl/geotoolkit.map.js';
