/* eslint-disable */

export {_nt as ArcGISFeature} from '@int/impl/geotoolkit.map.js';
