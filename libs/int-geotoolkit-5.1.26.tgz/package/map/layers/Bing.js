/* eslint-disable */

export {Pht as Bing} from '@int/impl/geotoolkit.map.js';
