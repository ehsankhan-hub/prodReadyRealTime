/* eslint-disable */

export {olt as AggregationSelection} from '@int/impl/geotoolkit.map.js';
