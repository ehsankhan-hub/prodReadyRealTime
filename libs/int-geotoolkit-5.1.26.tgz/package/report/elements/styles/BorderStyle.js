/* eslint-disable */

export {r_ as BorderStyle} from '@int/impl/geotoolkit.report.js';
