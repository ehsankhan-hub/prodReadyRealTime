/* eslint-disable */

export {yZ as ElementStyle} from '@int/impl/geotoolkit.report.js';
