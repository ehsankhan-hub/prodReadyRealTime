/* eslint-disable */

export {GZ as Style} from '@int/impl/geotoolkit.report.js';
