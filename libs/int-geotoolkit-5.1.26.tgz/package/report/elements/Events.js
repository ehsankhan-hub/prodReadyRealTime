/* eslint-disable */

export {r2 as Events} from '@int/impl/geotoolkit.report.js';
