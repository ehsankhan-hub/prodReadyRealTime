/* eslint-disable */

export {Y$ as CompositeElement} from '@int/impl/geotoolkit.report.js';
