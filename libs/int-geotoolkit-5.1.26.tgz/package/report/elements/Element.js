/* eslint-disable */

export {j_ as Element} from '@int/impl/geotoolkit.report.js';
