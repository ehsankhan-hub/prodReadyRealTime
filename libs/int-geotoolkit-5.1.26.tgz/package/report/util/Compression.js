/* eslint-disable */

export {n5 as Compression} from '@int/impl/geotoolkit.report.js';
