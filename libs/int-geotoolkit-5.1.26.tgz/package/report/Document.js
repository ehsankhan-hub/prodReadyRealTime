/* eslint-disable */

export {a3 as Document} from '@int/impl/geotoolkit.report.js';
