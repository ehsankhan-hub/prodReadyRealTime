/* eslint-disable */

export {P3 as Events} from '@int/impl/geotoolkit.report.js';
