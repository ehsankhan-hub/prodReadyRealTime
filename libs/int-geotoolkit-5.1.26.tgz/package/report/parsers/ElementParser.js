/* eslint-disable */

export {a$ as ElementParser} from '@int/impl/geotoolkit.report.js';
