/* eslint-disable */

export {E_ as AbstractElement, C_ as PageBreak} from '@int/impl/geotoolkit.report.js';
