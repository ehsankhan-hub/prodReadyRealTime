/* eslint-disable */

export {u$ as Document, o$ as DocumentEvents} from '@int/impl/geotoolkit.report.js';
