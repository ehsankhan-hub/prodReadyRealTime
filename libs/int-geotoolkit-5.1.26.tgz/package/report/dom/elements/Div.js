/* eslint-disable */

export {y2 as Div} from '@int/impl/geotoolkit.report.js';
