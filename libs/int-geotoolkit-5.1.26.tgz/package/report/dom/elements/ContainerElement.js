/* eslint-disable */

export {P_ as ContainerElement} from '@int/impl/geotoolkit.report.js';
