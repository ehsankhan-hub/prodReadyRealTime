/* eslint-disable */

export {B2 as Body} from '@int/impl/geotoolkit.report.js';
