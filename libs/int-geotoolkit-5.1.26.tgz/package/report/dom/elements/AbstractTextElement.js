/* eslint-disable */

export {L_ as AbstractTextElement} from '@int/impl/geotoolkit.report.js';
