/* eslint-disable */

export {__ as ElementEventArgs} from '@int/impl/geotoolkit.report.js';
