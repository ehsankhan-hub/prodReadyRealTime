/* eslint-disable */

export {gX as CollectionEventArgs, fX as CollectionChangesType} from '@int/impl/geotoolkit.report.js';
