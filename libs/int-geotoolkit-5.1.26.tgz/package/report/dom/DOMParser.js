/* eslint-disable */

export {s3 as DOMParser} from '@int/impl/geotoolkit.report.js';
