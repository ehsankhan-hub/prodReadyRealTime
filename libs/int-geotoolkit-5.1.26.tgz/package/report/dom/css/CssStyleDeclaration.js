/* eslint-disable */

export {j2 as CssStyleDeclaration} from '@int/impl/geotoolkit.report.js';
