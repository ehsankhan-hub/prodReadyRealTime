/* eslint-disable */

export {w5 as CssUtil} from '@int/impl/geotoolkit.report.js';
