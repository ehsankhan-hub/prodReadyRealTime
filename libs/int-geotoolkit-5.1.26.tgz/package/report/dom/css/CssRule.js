/* eslint-disable */

export {H2 as CssRule} from '@int/impl/geotoolkit.report.js';
