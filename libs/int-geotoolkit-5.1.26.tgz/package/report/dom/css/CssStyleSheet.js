/* eslint-disable */

export {$2 as CssStyleSheet} from '@int/impl/geotoolkit.report.js';
