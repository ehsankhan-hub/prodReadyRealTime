/* eslint-disable */

export {J2 as CssRuleList} from '@int/impl/geotoolkit.report.js';
