/* eslint-disable */

export {V2 as CssUnknownRule} from '@int/impl/geotoolkit.report.js';
