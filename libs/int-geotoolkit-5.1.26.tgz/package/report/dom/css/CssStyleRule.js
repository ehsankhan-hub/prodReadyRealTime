/* eslint-disable */

export {q2 as CssStyleRule} from '@int/impl/geotoolkit.report.js';
