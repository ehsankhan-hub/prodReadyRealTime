/* eslint-disable */

export {t3 as Document} from '@int/impl/geotoolkit.report.js';
