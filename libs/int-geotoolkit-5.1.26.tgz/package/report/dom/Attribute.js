/* eslint-disable */

export {oX as Attribute} from '@int/impl/geotoolkit.report.js';
