/* eslint-disable */

export {m7 as Axis, p7 as Events} from '@int/impl/geotoolkit.gauges.js';
