/* eslint-disable */

export {M7 as CircularAxis} from '@int/impl/geotoolkit.gauges.js';
