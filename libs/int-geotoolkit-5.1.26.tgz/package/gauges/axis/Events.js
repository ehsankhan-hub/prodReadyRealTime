/* eslint-disable */

export {w7 as Events} from '@int/impl/geotoolkit.gauges.js';
