/* eslint-disable */

export {k7 as CircularGauge} from '@int/impl/geotoolkit.gauges.js';
