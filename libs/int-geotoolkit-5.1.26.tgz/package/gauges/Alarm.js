/* eslint-disable */

export {h7 as Alarm} from '@int/impl/geotoolkit.gauges.js';
