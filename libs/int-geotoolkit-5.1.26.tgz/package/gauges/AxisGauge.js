/* eslint-disable */

export {B7 as AxisGauge} from '@int/impl/geotoolkit.gauges.js';
