/* eslint-disable */

export {x7 as AbstractFactory} from '@int/impl/geotoolkit.gauges.js';
