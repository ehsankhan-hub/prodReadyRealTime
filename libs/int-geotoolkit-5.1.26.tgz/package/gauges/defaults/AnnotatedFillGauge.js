/* eslint-disable */

export {N7 as AnnotatedFillGauge} from '@int/impl/geotoolkit.gauges.js';
