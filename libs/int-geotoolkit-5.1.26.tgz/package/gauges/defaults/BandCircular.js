/* eslint-disable */

export {R7 as BandCircular} from '@int/impl/geotoolkit.gauges.js';
