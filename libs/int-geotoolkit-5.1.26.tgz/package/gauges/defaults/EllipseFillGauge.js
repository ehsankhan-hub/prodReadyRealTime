/* eslint-disable */

export {U7 as EllipseFillGauge} from '@int/impl/geotoolkit.gauges.js';
