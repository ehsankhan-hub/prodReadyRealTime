/* eslint-disable */

export {G7 as CoveredNeedleCircular} from '@int/impl/geotoolkit.gauges.js';
