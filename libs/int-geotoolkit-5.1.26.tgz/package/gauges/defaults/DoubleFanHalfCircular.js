/* eslint-disable */

export {P7 as DoubleFanHalfCircular} from '@int/impl/geotoolkit.gauges.js';
