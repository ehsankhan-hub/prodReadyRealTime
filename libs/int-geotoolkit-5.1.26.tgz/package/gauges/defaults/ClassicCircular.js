/* eslint-disable */

export {L7 as ClassicCircular} from '@int/impl/geotoolkit.gauges.js';
