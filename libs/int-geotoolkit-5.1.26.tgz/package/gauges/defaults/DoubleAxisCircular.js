/* eslint-disable */

export {T7 as DoubleAxisCircular} from '@int/impl/geotoolkit.gauges.js';
