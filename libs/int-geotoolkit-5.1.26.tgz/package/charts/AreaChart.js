/* eslint-disable */

export {hz as AreaChart} from '@int/impl/geotoolkit.charts.js';
