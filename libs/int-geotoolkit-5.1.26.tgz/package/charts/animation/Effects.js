/* eslint-disable */

export {OH as Effects} from '@int/impl/geotoolkit.charts.js';
