/* eslint-disable */

export {VY as AxisType} from '@int/impl/geotoolkit.charts.js';
