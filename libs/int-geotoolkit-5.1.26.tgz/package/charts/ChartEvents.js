/* eslint-disable */

export {fY as Events} from '@int/impl/geotoolkit.charts.js';
