/* eslint-disable */

export {TV as DonutChart} from '@int/impl/geotoolkit.charts.js';
