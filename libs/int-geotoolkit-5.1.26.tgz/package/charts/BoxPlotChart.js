/* eslint-disable */

export {gz as BoxPlotChart} from '@int/impl/geotoolkit.charts.js';
