/* eslint-disable */

export {cV as AxisDimensionType} from '@int/impl/geotoolkit.charts.js';
