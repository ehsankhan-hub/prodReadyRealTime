/* eslint-disable */

export {kY as BarChart} from '@int/impl/geotoolkit.charts.js';
