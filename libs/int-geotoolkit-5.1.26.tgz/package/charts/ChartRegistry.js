/* eslint-disable */

export {wz as ChartRegistry} from '@int/impl/geotoolkit.charts.js';
