/* eslint-disable */

export {Ez as ChartWidgetRegistry} from '@int/impl/geotoolkit.charts.js';
