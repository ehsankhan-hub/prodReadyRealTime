/* eslint-disable */

export {OY as ErrorChart} from '@int/impl/geotoolkit.charts.js';
