/* eslint-disable */

export {UH as DataEvents} from '@int/impl/geotoolkit.charts.js';
