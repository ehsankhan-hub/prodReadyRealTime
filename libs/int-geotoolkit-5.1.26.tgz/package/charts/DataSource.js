/* eslint-disable */

export {uV as DataSource, sV as DataType} from '@int/impl/geotoolkit.charts.js';
