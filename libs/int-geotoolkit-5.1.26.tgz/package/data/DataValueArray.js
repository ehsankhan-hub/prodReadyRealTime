/* eslint-disable */

export {BJ as DataValueArray} from '@int/impl/geotoolkit.data.js';
