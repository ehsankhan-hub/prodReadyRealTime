/* eslint-disable */

export {$J as CompositeDataInterpolation} from '@int/impl/geotoolkit.data.js';
