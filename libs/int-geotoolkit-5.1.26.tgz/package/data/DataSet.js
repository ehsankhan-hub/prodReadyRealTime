/* eslint-disable */

export {FJ as DataSet} from '@int/impl/geotoolkit.data.js';
