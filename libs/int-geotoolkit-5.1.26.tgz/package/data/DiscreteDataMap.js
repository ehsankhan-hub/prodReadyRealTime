/* eslint-disable */

export {IJ as DiscreteDataMap, pJ as MapType} from '@int/impl/geotoolkit.data.js';
