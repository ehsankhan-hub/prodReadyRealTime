/* eslint-disable */

export {KN as AbstractDataTable} from '@int/impl/geotoolkit.data.js';
