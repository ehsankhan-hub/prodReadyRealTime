/* eslint-disable */

export {xJ as DataSeriesUtil} from '@int/impl/geotoolkit.data.js';
