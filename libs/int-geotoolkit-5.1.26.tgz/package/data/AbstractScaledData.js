/* eslint-disable */

export {sJ as AbstractScaledData} from '@int/impl/geotoolkit.data.js';
