/* eslint-disable */

export {_J as DataBindingRegistry} from '@int/impl/geotoolkit.data.js';
