/* eslint-disable */

export {YN as CalculatedDataSeries} from '@int/impl/geotoolkit.data.js';
