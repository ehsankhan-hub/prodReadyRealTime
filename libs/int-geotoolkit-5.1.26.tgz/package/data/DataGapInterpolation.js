/* eslint-disable */

export {HJ as DataGapInterpolation, OJ as DataGapType} from '@int/impl/geotoolkit.data.js';
