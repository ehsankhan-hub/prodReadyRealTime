/* eslint-disable */

export {WJ as DataClipInterpolation} from '@int/impl/geotoolkit.data.js';
