/* eslint-disable */

export {XJ as DataBinding} from '@int/impl/geotoolkit.data.js';
