/* eslint-disable */

export {Ok as DataObject, Uk as Events} from '@int/impl/geotoolkit.data.js';
