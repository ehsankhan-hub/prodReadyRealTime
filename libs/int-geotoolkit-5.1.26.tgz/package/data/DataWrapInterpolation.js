/* eslint-disable */

export {mJ as DataWrapInterpolation} from '@int/impl/geotoolkit.data.js';
