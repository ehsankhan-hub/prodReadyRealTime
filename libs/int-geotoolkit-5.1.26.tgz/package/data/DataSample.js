/* eslint-disable */

export {RJ as DataSample} from '@int/impl/geotoolkit.data.js';
