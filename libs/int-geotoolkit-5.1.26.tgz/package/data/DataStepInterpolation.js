/* eslint-disable */

export {bJ as DataStepInterpolation, yJ as InterpolationType, EJ as InterpolationMode} from '@int/impl/geotoolkit.data.js';
