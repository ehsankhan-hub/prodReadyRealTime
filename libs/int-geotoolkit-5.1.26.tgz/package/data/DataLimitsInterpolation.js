/* eslint-disable */

export {UJ as DataLimitsInterpolation, LJ as InterpolationEdge} from '@int/impl/geotoolkit.data.js';
