/* eslint-disable */

export {Rm as CompositeLayout} from '@int/impl/geotoolkit.base.js';
