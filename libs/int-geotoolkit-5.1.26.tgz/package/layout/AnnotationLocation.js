/* eslint-disable */

export {uc as AnnotationLocation} from '@int/impl/geotoolkit.base.js';
