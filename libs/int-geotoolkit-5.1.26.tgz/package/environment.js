/*
 * Copyright: Copyright (c) 2022-2023 by INT, Inc.  All rights reserved.<br>
 * Company: INT, Inc. <br>
 * INT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

import {HttpRequest} from '@int/geotoolkit/http/NodeHttpRequest';
import {JC as HttpService} from '@int/impl/geotoolkit.http.js';

HttpService.setRequest(HttpRequest.send);
import {Ju as TextMetrics, Fu as TextMetricsMeasureStrategy} from '@int/impl/geotoolkit.base.js';

TextMetrics.setMeasureTextStrategy(TextMetricsMeasureStrategy.NodeCanvas);
