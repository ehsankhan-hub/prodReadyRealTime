/* eslint-disable */

export {cxt as BoundsCalculation} from '@int/impl/geotoolkit.schematics.js';
