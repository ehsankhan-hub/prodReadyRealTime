/* eslint-disable */

export {QNt as BoundsCalculationRegistry} from '@int/impl/geotoolkit.schematics.js';
