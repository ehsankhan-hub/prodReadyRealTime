/* eslint-disable */

export {nxt as ComponentUtils} from '@int/impl/geotoolkit.schematics.js';
