/* eslint-disable */

export {Hxt as FlippedComponentNode} from '@int/impl/geotoolkit.schematics.js';
