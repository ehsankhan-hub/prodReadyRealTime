/* eslint-disable */

export {Ixt as ExternalGeometryComponentNode} from '@int/impl/geotoolkit.schematics.js';
