/* eslint-disable */

export {Cxt as ComponentNodeProxy} from '@int/impl/geotoolkit.schematics.js';
