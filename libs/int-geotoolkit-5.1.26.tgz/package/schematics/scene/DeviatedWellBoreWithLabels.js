/* eslint-disable */

export {aRt as DeviatedWellBoreWithLabels} from '@int/impl/geotoolkit.schematics.js';
