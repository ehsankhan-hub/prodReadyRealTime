/* eslint-disable */

export {xxt as AbstractComponentNodeFactory} from '@int/impl/geotoolkit.schematics.js';
