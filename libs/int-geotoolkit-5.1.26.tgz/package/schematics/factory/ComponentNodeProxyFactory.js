/* eslint-disable */

export {Sxt as ComponentNodeProxyFactory} from '@int/impl/geotoolkit.schematics.js';
