/* eslint-disable */

export {ANt as DefaultMap} from '@int/impl/geotoolkit.schematics.js';
