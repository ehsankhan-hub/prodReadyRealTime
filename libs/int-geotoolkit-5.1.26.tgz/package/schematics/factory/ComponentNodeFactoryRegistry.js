/* eslint-disable */

export {cNt as ComponentNodeFactoryRegistry} from '@int/impl/geotoolkit.schematics.js';
