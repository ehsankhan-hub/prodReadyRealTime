/* eslint-disable */

export {uxt as FixedTrackWidthStrategy} from '@int/impl/geotoolkit.schematics.js';
