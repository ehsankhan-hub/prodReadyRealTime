/* eslint-disable */

export {zNt as FlippedComponentTooltip} from '@int/impl/geotoolkit.schematics.js';
