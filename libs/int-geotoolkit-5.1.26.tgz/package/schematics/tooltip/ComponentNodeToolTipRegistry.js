/* eslint-disable */

export {KNt as ComponentNodeToolTipRegistry} from '@int/impl/geotoolkit.schematics.js';
