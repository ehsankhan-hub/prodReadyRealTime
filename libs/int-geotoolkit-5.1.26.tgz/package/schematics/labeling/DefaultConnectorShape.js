/* eslint-disable */

export {_Nt as DefaultConnectorShape} from '@int/impl/geotoolkit.schematics.js';
