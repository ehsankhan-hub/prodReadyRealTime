/* eslint-disable */

export {VFt as DefaultDeviatedStrategy} from '@int/impl/geotoolkit.schematics.js';
