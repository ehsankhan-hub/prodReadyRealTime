/* eslint-disable */

export {jFt as DefaultLabelingStrategy} from '@int/impl/geotoolkit.schematics.js';
