/* eslint-disable */

export {dRt as DefaultLabelShape} from '@int/impl/geotoolkit.schematics.js';
