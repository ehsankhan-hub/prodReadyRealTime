/* eslint-disable */

export {ZNt as ConnectorShape} from '@int/impl/geotoolkit.schematics.js';
