/* eslint-disable */

export {kxt as DefaultAliases} from '@int/impl/geotoolkit.schematics.js';
