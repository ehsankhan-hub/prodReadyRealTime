/* eslint-disable */

export {ORt as AbstractLegendItemInfoProvider} from '@int/impl/geotoolkit.schematics.js';
