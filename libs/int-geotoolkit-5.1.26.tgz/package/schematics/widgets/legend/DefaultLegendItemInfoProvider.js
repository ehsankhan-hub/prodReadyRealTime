/* eslint-disable */

export {VRt as DefaultLegendItemInfoProvider, HRt as Mode} from '@int/impl/geotoolkit.schematics.js';
