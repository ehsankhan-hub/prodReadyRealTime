/* eslint-disable */

export {vLt as DualSchematicsWidget} from '@int/impl/geotoolkit.schematics.js';
