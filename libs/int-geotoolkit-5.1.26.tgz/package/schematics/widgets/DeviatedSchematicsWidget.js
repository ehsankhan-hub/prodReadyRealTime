/* eslint-disable */

export {DLt as DeviatedSchematicsWidget} from '@int/impl/geotoolkit.schematics.js';
