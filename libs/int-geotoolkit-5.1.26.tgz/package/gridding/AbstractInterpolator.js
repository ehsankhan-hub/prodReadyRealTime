/* eslint-disable */

export {nW as AbstractInterpolator} from '@int/impl/geotoolkit.gridding.js';
