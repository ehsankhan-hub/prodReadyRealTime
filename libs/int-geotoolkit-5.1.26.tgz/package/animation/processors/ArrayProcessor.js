/* eslint-disable */

export {qn as ArrayProcessor} from '@int/impl/geotoolkit.base.js';
