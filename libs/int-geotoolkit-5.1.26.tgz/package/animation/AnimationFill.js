/* eslint-disable */

export {on as AnimationFill} from '@int/impl/geotoolkit.base.js';
