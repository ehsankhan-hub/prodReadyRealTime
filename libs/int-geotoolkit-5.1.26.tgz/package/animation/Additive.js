/* eslint-disable */

export {un as Additive} from '@int/impl/geotoolkit.base.js';
