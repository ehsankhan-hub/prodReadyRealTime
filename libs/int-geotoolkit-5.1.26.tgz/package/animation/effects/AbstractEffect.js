/* eslint-disable */

export {_n as AbstractEffect} from '@int/impl/geotoolkit.base.js';
