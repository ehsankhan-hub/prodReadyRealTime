/* eslint-disable */

export {io as DeserializationContext} from '@int/impl/geotoolkit.base.js';
