/* eslint-disable */

export {HC as AbstractHttpService} from '@int/impl/geotoolkit.http.js';
