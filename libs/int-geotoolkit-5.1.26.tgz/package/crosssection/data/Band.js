/* eslint-disable */

export {q8t as Band} from '@int/impl/geotoolkit.crosssection.js';
