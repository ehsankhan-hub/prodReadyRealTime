/* eslint-disable */

export {d9 as Annotation} from '@int/impl/geotoolkit.widgets.js';
