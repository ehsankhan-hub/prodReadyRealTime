/* eslint-disable */

export {C9 as AnnotationOverlay, w9 as Events} from '@int/impl/geotoolkit.widgets.js';
