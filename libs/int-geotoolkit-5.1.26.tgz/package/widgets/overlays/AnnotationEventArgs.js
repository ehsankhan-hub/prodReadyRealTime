/* eslint-disable */

export {r9 as AnnotationEventArgs} from '@int/impl/geotoolkit.widgets.js';
