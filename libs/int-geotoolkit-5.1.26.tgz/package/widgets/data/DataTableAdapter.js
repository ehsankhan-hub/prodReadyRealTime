/* eslint-disable */

export {z9 as DataTableAdapter} from '@int/impl/geotoolkit.widgets.js';
