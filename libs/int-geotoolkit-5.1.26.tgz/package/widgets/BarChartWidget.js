/* eslint-disable */

export {E8 as BarChartWidget} from '@int/impl/geotoolkit.widgets.js';
