/* eslint-disable */

export {x9 as Column} from '@int/impl/geotoolkit.widgets.js';
