/* eslint-disable */

export {k9 as Cell} from '@int/impl/geotoolkit.widgets.js';
