/* eslint-disable */

export {d8 as BubbleChart} from '@int/impl/geotoolkit.widgets.js';
