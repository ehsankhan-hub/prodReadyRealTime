/* eslint-disable */

export {$j as AnnotatedWidget, Jj as Events} from '@int/impl/geotoolkit.widgets.js';
