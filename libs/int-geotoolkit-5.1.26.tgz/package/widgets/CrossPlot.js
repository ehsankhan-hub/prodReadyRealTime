/* eslint-disable */

export {l8 as CrossPlot} from '@int/impl/geotoolkit.widgets.js';
