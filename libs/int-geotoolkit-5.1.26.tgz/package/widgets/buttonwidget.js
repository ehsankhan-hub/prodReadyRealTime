/* eslint-disable */

export {k5 as Button, x5 as ButtonWidget, M5 as State} from '@int/impl/geotoolkit.widgets.js';
