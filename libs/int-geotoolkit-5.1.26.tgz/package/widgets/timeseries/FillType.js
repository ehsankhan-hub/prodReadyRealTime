/* eslint-disable */

export {x4 as FillType} from '@int/impl/geotoolkit.widgets.js';
