/* eslint-disable */

export {M4 as Events} from '@int/impl/geotoolkit.widgets.js';
