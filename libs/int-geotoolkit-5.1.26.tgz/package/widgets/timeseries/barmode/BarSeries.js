/* eslint-disable */

export {b4 as BarSeries} from '@int/impl/geotoolkit.widgets.js';
