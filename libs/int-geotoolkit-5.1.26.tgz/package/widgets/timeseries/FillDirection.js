/* eslint-disable */

export {k4 as FillDirection} from '@int/impl/geotoolkit.widgets.js';
