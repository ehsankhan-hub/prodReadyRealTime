/* eslint-disable */

export {J8 as Events} from '@int/impl/geotoolkit.widgets.js';
