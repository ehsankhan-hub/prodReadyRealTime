/* eslint-disable */

export {Nz as BaseWidget} from '@int/impl/geotoolkit.widgets.js';
