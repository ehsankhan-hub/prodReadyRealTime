/* eslint-disable */

export {oat as BorderStrategy} from '@int/impl/geotoolkit.welllog.js';
