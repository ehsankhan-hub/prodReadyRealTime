/* eslint-disable */

export {SCt as AbstractDecimationStrategy} from '@int/impl/geotoolkit.welllog.js';
