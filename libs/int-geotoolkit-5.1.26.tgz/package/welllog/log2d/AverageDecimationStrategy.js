/* eslint-disable */

export {Nmt as AverageDecimationStrategy} from '@int/impl/geotoolkit.welllog.js';
