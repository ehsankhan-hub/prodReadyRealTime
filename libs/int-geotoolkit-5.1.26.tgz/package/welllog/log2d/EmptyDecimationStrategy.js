/* eslint-disable */

export {NCt as EmptyDecimationStrategy} from '@int/impl/geotoolkit.welllog.js';
