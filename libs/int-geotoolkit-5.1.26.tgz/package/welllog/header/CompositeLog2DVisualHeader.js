/* eslint-disable */

export {eBt as CompositeLog2DVisualHeader} from '@int/impl/geotoolkit.welllog.js';
