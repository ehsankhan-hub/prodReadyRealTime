/* eslint-disable */

export {Tgt as AdaptiveLogVisualTitleHeader, Ggt as Elements} from '@int/impl/geotoolkit.welllog.js';
