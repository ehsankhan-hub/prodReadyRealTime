/* eslint-disable */

export {uMt as CorrelationHeader} from '@int/impl/geotoolkit.welllog.multiwell.js';
