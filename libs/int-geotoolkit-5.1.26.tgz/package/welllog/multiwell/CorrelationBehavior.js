/* eslint-disable */

export {xMt as CorrelationBehavior} from '@int/impl/geotoolkit.welllog.multiwell.js';
