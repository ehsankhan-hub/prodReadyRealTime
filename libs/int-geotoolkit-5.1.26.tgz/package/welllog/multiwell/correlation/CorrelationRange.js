/* eslint-disable */

export {ixt as CorrelationRange} from '@int/impl/geotoolkit.welllog.multiwell.js';
