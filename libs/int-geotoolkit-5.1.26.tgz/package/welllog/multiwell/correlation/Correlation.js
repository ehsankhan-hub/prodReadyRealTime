/* eslint-disable */

export {TDt as Correlation} from '@int/impl/geotoolkit.welllog.multiwell.js';
