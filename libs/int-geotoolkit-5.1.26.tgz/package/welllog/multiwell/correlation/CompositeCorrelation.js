/* eslint-disable */

export {Kkt as CompositeCorrelation} from '@int/impl/geotoolkit.welllog.multiwell.js';
