/* eslint-disable */

export {sxt as CorrelationMarker} from '@int/impl/geotoolkit.welllog.multiwell.js';
