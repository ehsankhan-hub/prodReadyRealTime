/* eslint-disable */

export {CDt as AbstractWellTrack} from '@int/impl/geotoolkit.welllog.multiwell.js';
