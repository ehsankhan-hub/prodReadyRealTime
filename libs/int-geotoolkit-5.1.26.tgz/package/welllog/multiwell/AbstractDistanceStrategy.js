/* eslint-disable */

export {Tkt as AbstractDistanceStrategy} from '@int/impl/geotoolkit.welllog.multiwell.js';
