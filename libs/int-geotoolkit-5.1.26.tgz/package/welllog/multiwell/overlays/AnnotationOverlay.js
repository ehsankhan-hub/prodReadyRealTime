/* eslint-disable */

export {Ykt as AnnotationOverlay} from '@int/impl/geotoolkit.welllog.multiwell.js';
