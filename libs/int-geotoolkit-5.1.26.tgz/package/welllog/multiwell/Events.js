/* eslint-disable */

export {pDt as Events} from '@int/impl/geotoolkit.welllog.multiwell.js';
