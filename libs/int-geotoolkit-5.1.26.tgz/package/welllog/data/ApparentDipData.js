/* eslint-disable */

export {fBt as ApparentDipData} from '@int/impl/geotoolkit.welllog.js';
