/* eslint-disable */

export {pCt as ArrayLogAbstractData} from '@int/impl/geotoolkit.welllog.js';
