/* eslint-disable */

export {CBt as AbstractLoader} from '@int/impl/geotoolkit.welllog.js';
