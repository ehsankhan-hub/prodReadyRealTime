/* eslint-disable */

export {ICt as AbstractDataRow} from '@int/impl/geotoolkit.welllog.js';
