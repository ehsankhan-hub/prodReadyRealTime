/* eslint-disable */

export {IBt as DateTimeTickGenerator} from '@int/impl/geotoolkit.welllog.js';
