/* eslint-disable */

export {mQt as AnnotationOverlay} from '@int/impl/geotoolkit.welllog.widgets.js';
