/* eslint-disable */

export {cEt as DepthMarkerShape} from '@int/impl/geotoolkit.welllog.widgets.js';
