/* eslint-disable */

export {Ivt as AnnotationEditor} from '@int/impl/geotoolkit.welllog.widgets.js';
