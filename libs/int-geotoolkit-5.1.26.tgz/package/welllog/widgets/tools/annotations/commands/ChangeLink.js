/* eslint-disable */

export {Qvt as ChangeLink} from '@int/impl/geotoolkit.welllog.widgets.js';
