/* eslint-disable */

export {IQt as CollapsedIntervalTool} from '@int/impl/geotoolkit.welllog.widgets.js';
