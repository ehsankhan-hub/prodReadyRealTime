/* eslint-disable */

export {Xct as CompositeLogCurve} from '@int/impl/geotoolkit.welllog.js';
