/* eslint-disable */

export {Eot as CommonRemoteDataSource} from '@int/impl/geotoolkit.ivaapbackend.js';
