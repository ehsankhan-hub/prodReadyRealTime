/* eslint-disable */

export {Iot as AbstractRemoteDataSource} from '@int/impl/geotoolkit.ivaapbackend.js';
