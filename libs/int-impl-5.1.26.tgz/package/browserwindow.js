/*
 * Copyright: Copyright (c) 2022-2023 by INT, Inc.  All rights reserved.<br>
 * Company: INT, Inc. <br>
 * INT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

/**
 * @module geotoolkit/window
 */
/* global globalThis */
/**
 * @type {*}
 */
export const $window = typeof globalThis !== 'undefined' ? (globalThis.window || {}) : (window || {});

/**
 * @type {*}
 */
export const $document = typeof globalThis !== 'undefined' ? (globalThis.document || {}) : (document || {});
