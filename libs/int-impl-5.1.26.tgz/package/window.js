/*
 * Copyright: Copyright (c) 2022-2024 by INT, Inc.  All rights reserved.<br>
 * Company: INT, Inc. <br>
 * INT PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */
/**
 * @module geotoolkit/window
 */
/*
 * Setup everything so that it looks like the code is being executed in a browser
 * jsdom for dom elements
 * node-canvas for dom-canvas
 * Global variables that existing in a browser (window, document, etc)
 */
import Canvas from 'canvas';
import jsdom from 'jsdom';
import { XMLSerializer } from '@xmldom/xmldom';
/**
 * @type {*}
 */
export const $window = (function () {
    const isMutable = function (obj, propName) {
        if (obj == null || typeof obj !== 'object')
            return true;
        const descriptor = Object.getOwnPropertyDescriptor(obj, propName);
        return (!descriptor || descriptor.set || ('value' in descriptor));
    };
    const setupDOM = function () {
        let window = {};
        try {
            const JSDOM = jsdom['JSDOM'];
            // use to broadcast page error to Nodejs console
            const virtualConsole = new jsdom['VirtualConsole']();
            virtualConsole['on']('error', function (error) {
                global.console.error(error.stack, error.detail);
            });
            virtualConsole['on']('log', function (message) {
                global.console.log('>> [jsdom] :', message);
            });
            const html = '<html><body></body></html>';
            // window object created in order to make eval of the toolkit safe.
            window = new JSDOM(html, {
                'virtualConsole': virtualConsole,
                'resources': 'usable',
                'pretendToBeVisual': true // Enabling window.requestAnimationFrame
            }).window;
            window.XMLSerializer = XMLSerializer;
            // patch jsdom which always returns zeros in getBoundingClientRect()
            const origFoo = window.HTMLElement.prototype.getBoundingClientRect;
            window.HTMLElement.prototype.getBoundingClientRect = function () {
                const result = origFoo.call(this, arguments);
                if (result.width !== 0 || result.height !== 0 || result.top !== 0 || result.left !== 0)
                    return result;
                const width = this.width || parseFloat(this.style.width) || 0;
                const height = this.height || parseFloat(this.style.height) || 0;
                const left = this.left || parseFloat(this.style.marginLeft) || 0;
                const top = this.top || parseFloat(this.style.marginTop) || 0;
                return {
                    width: width,
                    height: height,
                    top: top,
                    left: left,
                    right: left + width,
                    bottom: top + height
                };
            };
        }
        catch (e) {
            global.console.error('Need jsdom version above 13.0.0');
        }
        window.isNaN = global.isNaN;
        window.isFinite = global.isFinite;
        window.parseInt = global.parseInt;
        window.parseFloat = global.parseFloat;
        window.Uint8Array = global.Uint8Array;
        window.Uint32Array = global.Uint32Array;
        window.Int32Array = global.Int32Array;
        window.Float64Array = global.Float64Array;
        window.setTimeout = global.setTimeout;
        window.clearTimeout = global.clearTimeout;
        window.setInterval = global.setInterval;
        window.clearInterval = global.clearInterval;
        window.Promise = global.Promise;
        window.Map = global.Map;
        window.WeakMap = global.WeakMap;
        // expose to other modules
        if (isMutable(global, 'window')) {
            global.window = window;
        }
        global.self = window;
        if (isMutable(global, 'document')) {
            global.document = window.document;
        }
        if (isMutable(global, 'navigator')) {
            global.navigator = window.navigator;
        }
        if (isMutable(global, 'XMLHttpRequest')) {
            global.XMLHttpRequest = window.XMLHttpRequest;
        }
        return window;
    };
    const setupCanvas = function (Canvas) {
        const window = setupDOM();
        window['CanvasRenderingContext2D'] = Canvas['CanvasRenderingContext2D'];
        window['Canvas'] = Canvas['Canvas'];
        window['createCanvas'] = Canvas['createCanvas'];
        window.HTMLCanvasElement = Canvas['Canvas'];
        global['Canvas'] = window['Canvas'];
        window.Image = Canvas['Image'];
        window.HTMLImageElement = Canvas['Image'];
        global.Image = Canvas['Image'];
        global.HTMLImageElement = Canvas['Image'];
        global.HTMLCanvasElement = window.HTMLCanvasElement;
        return window;
    };
    return setupCanvas(Canvas);
})();
/**
 * @type {*}
 */
export const $document = $window.document;
