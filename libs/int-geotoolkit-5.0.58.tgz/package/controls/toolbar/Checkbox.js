/* eslint-disable */

export {pF as Checkbox} from '@int/impl/geotoolkit.controls.js';
