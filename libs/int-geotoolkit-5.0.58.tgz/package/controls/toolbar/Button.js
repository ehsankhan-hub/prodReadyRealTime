/* eslint-disable */

export {nF as Button} from '@int/impl/geotoolkit.controls.js';
