/* eslint-disable */

export {hF as ButtonRegistry} from '@int/impl/geotoolkit.controls.js';
