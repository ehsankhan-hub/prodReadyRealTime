/* eslint-disable */

export {PM as DOMSupport} from '@int/impl/geotoolkit.controls.js';
