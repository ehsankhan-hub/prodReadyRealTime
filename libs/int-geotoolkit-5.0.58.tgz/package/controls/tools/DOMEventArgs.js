/* eslint-disable */

export {yM as DOMEventArgs} from '@int/impl/geotoolkit.controls.js';
