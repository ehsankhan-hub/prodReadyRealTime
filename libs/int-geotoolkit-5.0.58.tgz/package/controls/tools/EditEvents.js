/* eslint-disable */

export {lS as EditEvents} from '@int/impl/geotoolkit.controls.js';
