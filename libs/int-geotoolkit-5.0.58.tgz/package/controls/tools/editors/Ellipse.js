/* eslint-disable */

export {Vk as Ellipse} from '@int/impl/geotoolkit.controls.js';
