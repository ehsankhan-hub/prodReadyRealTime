/* eslint-disable */

export {VH as BaseEditor} from '@int/impl/geotoolkit.controls.js';
