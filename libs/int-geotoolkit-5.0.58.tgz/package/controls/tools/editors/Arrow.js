/* eslint-disable */

export {mk as Arrow} from '@int/impl/geotoolkit.controls.js';
