/* eslint-disable */

export {tG as AbstractPointSetEditor} from '@int/impl/geotoolkit.controls.js';
