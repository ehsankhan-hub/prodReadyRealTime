/* eslint-disable */

export {vS as DragPoint} from '@int/impl/geotoolkit.controls.js';
