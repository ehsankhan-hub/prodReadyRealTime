/* eslint-disable */

export {MS as AddSegment} from '@int/impl/geotoolkit.controls.js';
