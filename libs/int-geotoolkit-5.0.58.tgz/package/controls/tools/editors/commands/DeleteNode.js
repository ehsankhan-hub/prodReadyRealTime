/* eslint-disable */

export {jS as DeleteNode} from '@int/impl/geotoolkit.controls.js';
