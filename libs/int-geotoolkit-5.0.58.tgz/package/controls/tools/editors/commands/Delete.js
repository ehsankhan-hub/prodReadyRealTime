/* eslint-disable */

export {eq as Delete} from '@int/impl/geotoolkit.controls.js';
