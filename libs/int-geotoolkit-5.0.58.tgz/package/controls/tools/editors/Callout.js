/* eslint-disable */

export {Ck as Callout} from '@int/impl/geotoolkit.controls.js';
