/* eslint-disable */

export {OR as DragAndDropEventArgs} from '@int/impl/geotoolkit.controls.js';
