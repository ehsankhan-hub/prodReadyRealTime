/* eslint-disable */

export {yN as CrossHairEventArgs} from '@int/impl/geotoolkit.controls.js';
