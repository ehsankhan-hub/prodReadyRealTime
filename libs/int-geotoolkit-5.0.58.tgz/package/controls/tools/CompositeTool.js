/* eslint-disable */

export {cM as CompositeTool} from '@int/impl/geotoolkit.controls.js';
