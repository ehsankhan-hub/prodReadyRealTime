/* eslint-disable */

export {qv as BaseEventArgs} from '@int/impl/geotoolkit.controls.js';
