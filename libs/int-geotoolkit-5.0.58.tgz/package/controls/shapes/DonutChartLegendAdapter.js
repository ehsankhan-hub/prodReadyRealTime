/* eslint-disable */

export {gT as DonutChartLegendAdapter} from '@int/impl/geotoolkit.controls.js';
