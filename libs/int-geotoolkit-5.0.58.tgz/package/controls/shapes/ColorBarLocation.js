/* eslint-disable */

export {WR as ColorBarLocation} from '@int/impl/geotoolkit.controls.js';
