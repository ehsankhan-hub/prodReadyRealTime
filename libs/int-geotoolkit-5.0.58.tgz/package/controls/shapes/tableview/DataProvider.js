/* eslint-disable */

export {sH as DataProvider} from '@int/impl/geotoolkit.controls.js';
