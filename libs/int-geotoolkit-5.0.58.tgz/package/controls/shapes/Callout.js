/* eslint-disable */

export {DS as Callout} from '@int/impl/geotoolkit.controls.js';
