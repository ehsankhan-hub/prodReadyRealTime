/* eslint-disable */

export {pY as AnchoredHandle} from '@int/impl/geotoolkit.controls.js';
