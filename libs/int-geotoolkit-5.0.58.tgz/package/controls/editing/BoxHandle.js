/* eslint-disable */

export {bY as BoxHandle} from '@int/impl/geotoolkit.controls.js';
