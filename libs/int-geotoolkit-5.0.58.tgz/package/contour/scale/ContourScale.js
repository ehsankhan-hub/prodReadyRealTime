/* eslint-disable */

export {YPt as ContourScale} from '@int/impl/geotoolkit.contour.js';
