/* eslint-disable */

export {fPt as AbstractContourDataSource} from '@int/impl/geotoolkit.contour.js';
