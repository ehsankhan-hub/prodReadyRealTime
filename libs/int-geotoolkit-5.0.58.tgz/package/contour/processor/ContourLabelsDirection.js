/* eslint-disable */

export {wJt as ContourLabelsDirection} from '@int/impl/geotoolkit.contour.js';
