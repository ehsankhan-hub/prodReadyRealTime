/* eslint-disable */

export {JPt as AbstractProjection} from '@int/impl/geotoolkit.contour.js';
