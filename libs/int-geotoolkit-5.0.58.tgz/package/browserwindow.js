export {$window, $document} from '@int/impl/browserwindow.js';
