/* eslint-disable */

export {pW as AbstractInterpolator} from '@int/impl/geotoolkit.gridding.js';
