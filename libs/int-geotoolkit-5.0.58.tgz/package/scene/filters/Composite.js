/* eslint-disable */

export {xm as Composite} from '@int/impl/geotoolkit.base.js';
