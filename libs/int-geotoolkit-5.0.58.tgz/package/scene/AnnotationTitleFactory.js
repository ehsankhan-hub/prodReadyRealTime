/* eslint-disable */

export {vp as AnnotationTitleFactory} from '@int/impl/geotoolkit.base.js';
