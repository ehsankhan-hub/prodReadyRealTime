/* eslint-disable */

export {Rp as ChildrensBoundsModelLimitsStrategy} from '@int/impl/geotoolkit.base.js';
