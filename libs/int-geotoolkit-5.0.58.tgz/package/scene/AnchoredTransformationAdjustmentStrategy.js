/* eslint-disable */

export {Bp as AnchoredTransformationAdjustmentStrategy} from '@int/impl/geotoolkit.base.js';
