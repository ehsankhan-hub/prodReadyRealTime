/* eslint-disable */

export {Vm as Document} from '@int/impl/geotoolkit.base.js';
