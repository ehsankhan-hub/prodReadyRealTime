/* eslint-disable */

export {zd as CustomPaperFormat} from '@int/impl/geotoolkit.base.js';
