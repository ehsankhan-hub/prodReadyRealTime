/* eslint-disable */

export {Vd as AbstractPaperFormat} from '@int/impl/geotoolkit.base.js';
