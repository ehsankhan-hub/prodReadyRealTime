/* eslint-disable */

export {Jm as DocumentElement} from '@int/impl/geotoolkit.base.js';
