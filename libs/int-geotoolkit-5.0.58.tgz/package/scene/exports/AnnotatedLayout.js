/* eslint-disable */

export {zm as AnnotatedLayout} from '@int/impl/geotoolkit.base.js';
