/* eslint-disable */

export {Td as CompositeDocumentElement} from '@int/impl/geotoolkit.base.js';
