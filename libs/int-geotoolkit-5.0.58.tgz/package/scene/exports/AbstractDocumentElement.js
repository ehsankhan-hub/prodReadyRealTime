/* eslint-disable */

export {Gd as AbstractDocumentElement} from '@int/impl/geotoolkit.base.js';
