/* eslint-disable */

export {cm as Ellipse} from '@int/impl/geotoolkit.base.js';
