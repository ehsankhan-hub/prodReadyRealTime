/* eslint-disable */

export {bm as ColoredPolyline} from '@int/impl/geotoolkit.base.js';
