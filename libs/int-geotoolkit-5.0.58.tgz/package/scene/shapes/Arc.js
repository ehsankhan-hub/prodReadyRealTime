/* eslint-disable */

export {Sm as Arc} from '@int/impl/geotoolkit.base.js';
