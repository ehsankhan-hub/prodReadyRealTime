/* eslint-disable */

export {Wm as AbstractCancellationStrategy} from '@int/impl/geotoolkit.tiledshape.js';
