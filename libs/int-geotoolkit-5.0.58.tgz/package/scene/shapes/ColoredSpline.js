/* eslint-disable */

export {wm as ColoredSpline} from '@int/impl/geotoolkit.base.js';
