/* eslint-disable */

export {Gm as AnnulusArc} from '@int/impl/geotoolkit.base.js';
