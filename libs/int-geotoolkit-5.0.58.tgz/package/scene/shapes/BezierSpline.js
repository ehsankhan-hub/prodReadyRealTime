/* eslint-disable */

export {Qr as BezierControlPoints} from '@int/impl/geotoolkit.base.js';
