/* eslint-disable */

export {DD as Dry} from '@int/impl/geotoolkit.base.js';
