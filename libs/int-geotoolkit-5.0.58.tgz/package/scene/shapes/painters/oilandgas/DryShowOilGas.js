/* eslint-disable */

export {bD as DryShowOilGas} from '@int/impl/geotoolkit.base.js';
