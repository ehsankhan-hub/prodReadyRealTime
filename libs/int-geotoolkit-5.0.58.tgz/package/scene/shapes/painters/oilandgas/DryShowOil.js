/* eslint-disable */

export {vD as DryShowOil} from '@int/impl/geotoolkit.base.js';
