/* eslint-disable */

export {jy as DiamondPainter} from '@int/impl/geotoolkit.base.js';
