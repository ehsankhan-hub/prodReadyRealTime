/* eslint-disable */

export {Vy as EmptyPainter} from '@int/impl/geotoolkit.base.js';
