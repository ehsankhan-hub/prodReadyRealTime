/* eslint-disable */

export {Xy as ArrowPainter} from '@int/impl/geotoolkit.base.js';
