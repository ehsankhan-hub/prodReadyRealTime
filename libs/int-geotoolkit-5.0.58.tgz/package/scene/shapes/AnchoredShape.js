/* eslint-disable */

export {Xc as AnchoredShape} from '@int/impl/geotoolkit.base.js';
