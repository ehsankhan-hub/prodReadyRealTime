/* eslint-disable */

export {bI as Border, II as BorderStyle} from '@int/impl/geotoolkit.base.js';
