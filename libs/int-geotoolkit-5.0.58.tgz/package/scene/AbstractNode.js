/* eslint-disable */

export {Fa as AbstractNode} from '@int/impl/geotoolkit.base.js';
