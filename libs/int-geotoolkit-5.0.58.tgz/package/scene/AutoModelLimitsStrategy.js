/* eslint-disable */

export {MI as AutoModelLimitsStrategy} from '@int/impl/geotoolkit.base.js';
