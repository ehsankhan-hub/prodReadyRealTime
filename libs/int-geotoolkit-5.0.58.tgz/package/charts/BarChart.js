/* eslint-disable */

export {ZJ as BarChart} from '@int/impl/geotoolkit.charts.js';
