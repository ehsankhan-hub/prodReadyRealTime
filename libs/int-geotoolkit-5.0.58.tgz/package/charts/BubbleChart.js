/* eslint-disable */

export {RP as BubbleChart} from '@int/impl/geotoolkit.charts.js';
