/* eslint-disable */

export {uP as AxisType} from '@int/impl/geotoolkit.charts.js';
