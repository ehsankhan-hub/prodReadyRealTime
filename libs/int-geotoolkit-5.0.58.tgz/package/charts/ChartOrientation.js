/* eslint-disable */

export {oq as ChartOrientation} from '@int/impl/geotoolkit.charts.js';
