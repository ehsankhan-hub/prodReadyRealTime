/* eslint-disable */

export {Fq as AxisDimensionType} from '@int/impl/geotoolkit.charts.js';
