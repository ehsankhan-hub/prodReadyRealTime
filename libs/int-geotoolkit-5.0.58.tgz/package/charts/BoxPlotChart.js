/* eslint-disable */

export {LP as BoxPlotChart} from '@int/impl/geotoolkit.charts.js';
