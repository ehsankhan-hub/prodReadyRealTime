/* eslint-disable */

export {kq as DataSource, yq as DataType} from '@int/impl/geotoolkit.charts.js';
