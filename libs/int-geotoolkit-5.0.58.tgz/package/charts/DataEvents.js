/* eslint-disable */

export {rq as DataEvents} from '@int/impl/geotoolkit.charts.js';
