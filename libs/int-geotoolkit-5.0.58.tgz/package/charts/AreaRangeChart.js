/* eslint-disable */

export {MP as AreaRangeChart} from '@int/impl/geotoolkit.charts.js';
