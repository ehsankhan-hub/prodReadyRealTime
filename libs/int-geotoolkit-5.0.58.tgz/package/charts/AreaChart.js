/* eslint-disable */

export {vP as AreaChart} from '@int/impl/geotoolkit.charts.js';
