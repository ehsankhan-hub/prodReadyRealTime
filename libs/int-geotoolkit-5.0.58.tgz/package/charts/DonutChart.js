/* eslint-disable */

export {AJ as DonutChart} from '@int/impl/geotoolkit.charts.js';
