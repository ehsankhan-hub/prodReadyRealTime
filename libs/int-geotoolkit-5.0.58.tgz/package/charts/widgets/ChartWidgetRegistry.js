/* eslint-disable */

export {OP as ChartWidgetRegistry} from '@int/impl/geotoolkit.charts.js';
