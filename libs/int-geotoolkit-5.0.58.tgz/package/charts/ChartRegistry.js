/* eslint-disable */

export {TP as ChartRegistry} from '@int/impl/geotoolkit.charts.js';
