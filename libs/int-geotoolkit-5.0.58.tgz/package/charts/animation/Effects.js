/* eslint-disable */

export {lq as Effects} from '@int/impl/geotoolkit.charts.js';
