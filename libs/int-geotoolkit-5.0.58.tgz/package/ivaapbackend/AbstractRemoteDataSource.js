/* eslint-disable */

export {blt as AbstractRemoteDataSource} from '@int/impl/geotoolkit.ivaapbackend.js';
