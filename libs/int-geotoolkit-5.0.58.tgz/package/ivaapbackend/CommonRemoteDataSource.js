/* eslint-disable */

export {klt as CommonRemoteDataSource} from '@int/impl/geotoolkit.ivaapbackend.js';
