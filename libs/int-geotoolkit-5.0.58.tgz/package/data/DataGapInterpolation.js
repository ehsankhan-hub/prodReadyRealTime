/* eslint-disable */

export {AW as DataGapInterpolation} from '@int/impl/geotoolkit.data.js';
