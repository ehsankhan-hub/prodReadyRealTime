/* eslint-disable */

export {Kz as DataWrapInterpolation} from '@int/impl/geotoolkit.data.js';
