/* eslint-disable */

export {pz as AbstractScaledData} from '@int/impl/geotoolkit.data.js';
