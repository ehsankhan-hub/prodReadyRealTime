/* eslint-disable */

export {VU as CalculatedDataSeries} from '@int/impl/geotoolkit.data.js';
