/* eslint-disable */

export {Tz as DiscreteDataMap, Uz as MapType} from '@int/impl/geotoolkit.data.js';
