/* eslint-disable */

export {Hz as DataValueArray} from '@int/impl/geotoolkit.data.js';
