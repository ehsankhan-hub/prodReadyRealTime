/* eslint-disable */

export {zU as AbstractDataTable} from '@int/impl/geotoolkit.data.js';
