/* eslint-disable */

export {gW as DataClipInterpolation} from '@int/impl/geotoolkit.data.js';
