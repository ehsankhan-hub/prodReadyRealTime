/* eslint-disable */

export {Jz as DataStepInterpolation, qz as InterpolationType} from '@int/impl/geotoolkit.data.js';
