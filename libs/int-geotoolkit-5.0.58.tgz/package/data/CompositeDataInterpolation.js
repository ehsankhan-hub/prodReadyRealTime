/* eslint-disable */

export {CW as CompositeDataInterpolation} from '@int/impl/geotoolkit.data.js';
