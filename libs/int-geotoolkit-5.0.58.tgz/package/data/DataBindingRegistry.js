/* eslint-disable */

export {dW as DataBindingRegistry} from '@int/impl/geotoolkit.data.js';
