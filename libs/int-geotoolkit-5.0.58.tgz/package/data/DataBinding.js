/* eslint-disable */

export {fW as DataBinding} from '@int/impl/geotoolkit.data.js';
