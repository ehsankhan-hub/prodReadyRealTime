/* eslint-disable */

export {nW as DataLimitsInterpolation, tW as InterpolationEdge} from '@int/impl/geotoolkit.data.js';
