/* eslint-disable */

export {Wz as DataSeriesUtil} from '@int/impl/geotoolkit.data.js';
