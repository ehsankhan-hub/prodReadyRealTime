/* eslint-disable */

export {$z as DataSample} from '@int/impl/geotoolkit.data.js';
