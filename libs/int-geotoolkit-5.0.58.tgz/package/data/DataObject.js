/* eslint-disable */

export {mG as DataObject, pG as Events} from '@int/impl/geotoolkit.data.js';
