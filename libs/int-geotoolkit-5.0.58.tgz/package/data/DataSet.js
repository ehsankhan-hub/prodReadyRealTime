/* eslint-disable */

export {_z as DataSet} from '@int/impl/geotoolkit.data.js';
