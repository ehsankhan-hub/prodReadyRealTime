/* eslint-disable */

export {lW as DataGapFillInterpolation, hW as CutoffMode} from '@int/impl/geotoolkit.data.js';
