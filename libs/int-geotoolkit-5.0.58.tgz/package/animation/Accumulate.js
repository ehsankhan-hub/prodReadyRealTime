/* eslint-disable */

export {Pn as Accumulate} from '@int/impl/geotoolkit.base.js';
