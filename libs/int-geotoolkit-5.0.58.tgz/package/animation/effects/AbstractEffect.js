/* eslint-disable */

export {GA as AbstractEffect} from '@int/impl/geotoolkit.base.js';
