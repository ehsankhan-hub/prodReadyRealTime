/* eslint-disable */

export {On as AbstractProcessor} from '@int/impl/geotoolkit.base.js';
