/* eslint-disable */

export {zr as ClipStyle} from '@int/impl/geotoolkit.base.js';
