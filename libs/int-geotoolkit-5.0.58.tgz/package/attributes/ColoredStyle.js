/* eslint-disable */

export {Yl as ColoredStyle} from '@int/impl/geotoolkit.base.js';
