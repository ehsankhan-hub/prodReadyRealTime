/* eslint-disable */

export {Vr as AnimationStyle, Pr as Events} from '@int/impl/geotoolkit.base.js';
