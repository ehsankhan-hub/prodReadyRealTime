/* eslint-disable */

export {fAi as Band} from '@int/impl/geotoolkit.crosssection.js';
