/* eslint-disable */

export {ZQt as CompositeLogCurveHeader} from '@int/impl/geotoolkit.welllog.js';
