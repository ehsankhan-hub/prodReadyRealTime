/* eslint-disable */

export {_Qt as CompositeLog2DVisualHeader} from '@int/impl/geotoolkit.welllog.js';
