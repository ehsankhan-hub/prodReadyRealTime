/* eslint-disable */

export {vwt as EmptyDecimationStrategy} from '@int/impl/geotoolkit.welllog.js';
