/* eslint-disable */

export {vQt as AverageDecimationStrategy} from '@int/impl/geotoolkit.welllog.js';
