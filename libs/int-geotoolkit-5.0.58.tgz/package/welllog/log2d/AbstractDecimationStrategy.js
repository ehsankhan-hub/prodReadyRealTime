/* eslint-disable */

export {bwt as AbstractDecimationStrategy} from '@int/impl/geotoolkit.welllog.js';
