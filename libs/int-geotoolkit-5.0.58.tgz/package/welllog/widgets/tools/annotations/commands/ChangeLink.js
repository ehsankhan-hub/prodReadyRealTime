/* eslint-disable */

export {Cbt as ChangeLink} from '@int/impl/geotoolkit.welllog.widgets.js';
