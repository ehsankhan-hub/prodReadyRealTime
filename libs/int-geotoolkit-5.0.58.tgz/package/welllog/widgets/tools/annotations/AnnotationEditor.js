/* eslint-disable */

export {dbt as AnnotationEditor} from '@int/impl/geotoolkit.welllog.widgets.js';
