/* eslint-disable */

export {IDt as CurveDataObject} from '@int/impl/geotoolkit.welllog.widgets.js';
