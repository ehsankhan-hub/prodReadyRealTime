/* eslint-disable */

export {Amt as DepthMarkerShape} from '@int/impl/geotoolkit.welllog.widgets.js';
