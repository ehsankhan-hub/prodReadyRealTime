/* eslint-disable */

export {gDt as AnnotationOverlay} from '@int/impl/geotoolkit.welllog.widgets.js';
