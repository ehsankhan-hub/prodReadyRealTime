/* eslint-disable */

export {dut as BorderStrategy} from '@int/impl/geotoolkit.welllog.js';
