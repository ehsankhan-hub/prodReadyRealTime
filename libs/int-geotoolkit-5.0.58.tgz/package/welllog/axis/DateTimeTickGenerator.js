/* eslint-disable */

export {aEt as DateTimeTickGenerator} from '@int/impl/geotoolkit.welllog.js';
