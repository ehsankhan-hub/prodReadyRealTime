/* eslint-disable */

export {gwt as AbstractDataRow} from '@int/impl/geotoolkit.welllog.js';
