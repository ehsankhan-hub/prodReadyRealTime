/* eslint-disable */

export {hEt as ApparentDipData} from '@int/impl/geotoolkit.welllog.js';
