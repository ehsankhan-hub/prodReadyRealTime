/* eslint-disable */

export {tgt as CompositeLogCurve} from '@int/impl/geotoolkit.welllog.js';
