/* eslint-disable */

export {dMt as CorrelationBehavior} from '@int/impl/geotoolkit.welllog.multiwell.js';
