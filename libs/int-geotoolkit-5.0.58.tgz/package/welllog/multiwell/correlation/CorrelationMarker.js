/* eslint-disable */

export {HNt as CorrelationMarker} from '@int/impl/geotoolkit.welllog.multiwell.js';
