/* eslint-disable */

export {SNt as CompositeCorrelation} from '@int/impl/geotoolkit.welllog.multiwell.js';
