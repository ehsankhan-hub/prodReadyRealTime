/* eslint-disable */

export {KNt as CorrelationRange} from '@int/impl/geotoolkit.welllog.multiwell.js';
