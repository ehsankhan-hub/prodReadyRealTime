/* eslint-disable */

export {vvt as Correlation} from '@int/impl/geotoolkit.welllog.multiwell.js';
