/* eslint-disable */

export {jvt as AbstractWellTrackFactory} from '@int/impl/geotoolkit.welllog.multiwell.js';
