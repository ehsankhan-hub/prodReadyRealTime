/* eslint-disable */

export {MNt as AnnotationOverlay} from '@int/impl/geotoolkit.welllog.multiwell.js';
