/* eslint-disable */

export {pNt as AbstractDistanceStrategy} from '@int/impl/geotoolkit.welllog.multiwell.js';
