/* eslint-disable */

export {Gvt as CorrelationTrack} from '@int/impl/geotoolkit.welllog.multiwell.js';
