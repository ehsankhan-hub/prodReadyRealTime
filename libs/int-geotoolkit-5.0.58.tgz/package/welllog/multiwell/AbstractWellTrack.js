/* eslint-disable */

export {cvt as AbstractWellTrack} from '@int/impl/geotoolkit.welllog.multiwell.js';
