/* eslint-disable */

export {Wvt as CorrelationHeader} from '@int/impl/geotoolkit.welllog.multiwell.js';
