/* eslint-disable */

export {PA as ClipOperation} from '@int/impl/geotoolkit.base.js';
