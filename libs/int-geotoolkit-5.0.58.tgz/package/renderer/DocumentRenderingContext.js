/* eslint-disable */

export {ig as DocumentRenderingContext} from '@int/impl/geotoolkit.base.js';
