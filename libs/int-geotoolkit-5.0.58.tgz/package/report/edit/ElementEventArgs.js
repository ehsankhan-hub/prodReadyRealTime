/* eslint-disable */

export {mli as ElementEventArgs} from '@int/impl/geotoolkit.report.builder.js';
