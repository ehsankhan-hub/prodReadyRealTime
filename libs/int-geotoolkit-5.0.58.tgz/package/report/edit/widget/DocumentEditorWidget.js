/* eslint-disable */

export {yoi as DocumentEditorWidget, foi as Events} from '@int/impl/geotoolkit.report.builder.js';
