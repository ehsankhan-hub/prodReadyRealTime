/* eslint-disable */

export {Xli as DragAndDropEventArgs} from '@int/impl/geotoolkit.report.builder.js';
