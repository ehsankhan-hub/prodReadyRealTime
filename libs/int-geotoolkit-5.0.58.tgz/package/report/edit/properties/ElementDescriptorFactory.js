/* eslint-disable */

export {eoi as ElementDescriptorFactory} from '@int/impl/geotoolkit.report.builder.js';
