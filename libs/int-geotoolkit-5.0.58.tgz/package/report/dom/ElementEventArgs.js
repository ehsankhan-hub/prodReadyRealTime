/* eslint-disable */

export {d$ as ElementEventArgs} from '@int/impl/geotoolkit.report.js';
