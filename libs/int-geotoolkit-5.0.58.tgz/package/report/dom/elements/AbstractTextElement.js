/* eslint-disable */

export {$_ as AbstractTextElement} from '@int/impl/geotoolkit.report.js';
