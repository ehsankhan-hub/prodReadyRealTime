/* eslint-disable */

export {Y2 as Body} from '@int/impl/geotoolkit.report.js';
