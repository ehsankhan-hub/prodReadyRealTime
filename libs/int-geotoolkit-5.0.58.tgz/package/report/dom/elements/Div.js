/* eslint-disable */

export {K2 as Div} from '@int/impl/geotoolkit.report.js';
