/* eslint-disable */

export {v$ as Document, b$ as DocumentEvents} from '@int/impl/geotoolkit.report.js';
