/* eslint-disable */

export {GX as CollectionEventArgs, kX as CollectionChangesType} from '@int/impl/geotoolkit.report.js';
