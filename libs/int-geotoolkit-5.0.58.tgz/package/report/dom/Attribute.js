/* eslint-disable */

export {bX as Attribute} from '@int/impl/geotoolkit.report.js';
