/* eslint-disable */

export {B5 as Document} from '@int/impl/geotoolkit.report.js';
