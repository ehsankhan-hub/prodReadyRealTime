/* eslint-disable */

export {Q5 as DOMParser} from '@int/impl/geotoolkit.report.js';
