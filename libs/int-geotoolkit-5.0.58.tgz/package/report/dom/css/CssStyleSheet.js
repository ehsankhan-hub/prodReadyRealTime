/* eslint-disable */

export {C5 as CssStyleSheet} from '@int/impl/geotoolkit.report.js';
