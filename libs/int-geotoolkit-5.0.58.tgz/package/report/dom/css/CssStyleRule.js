/* eslint-disable */

export {a5 as CssStyleRule} from '@int/impl/geotoolkit.report.js';
