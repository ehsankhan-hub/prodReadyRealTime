/* eslint-disable */

export {A5 as CssRule} from '@int/impl/geotoolkit.report.js';
