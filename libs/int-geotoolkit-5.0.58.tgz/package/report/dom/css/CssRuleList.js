/* eslint-disable */

export {c5 as CssRuleList} from '@int/impl/geotoolkit.report.js';
