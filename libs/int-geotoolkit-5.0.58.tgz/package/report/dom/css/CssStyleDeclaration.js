/* eslint-disable */

export {u5 as CssStyleDeclaration} from '@int/impl/geotoolkit.report.js';
