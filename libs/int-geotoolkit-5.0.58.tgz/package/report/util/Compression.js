/* eslint-disable */

export {p3 as Compression} from '@int/impl/geotoolkit.report.js';
