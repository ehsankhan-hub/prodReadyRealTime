/* eslint-disable */

export {I3 as DocumentViewWidget, g3 as Events} from '@int/impl/geotoolkit.report.js';
