/* eslint-disable */

export {M$ as ElementParser} from '@int/impl/geotoolkit.report.js';
