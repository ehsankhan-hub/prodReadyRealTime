/* eslint-disable */

export {R5 as ContentView} from '@int/impl/geotoolkit.report.js';
