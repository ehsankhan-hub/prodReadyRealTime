/* eslint-disable */

export {s3 as Events} from '@int/impl/geotoolkit.report.js';
