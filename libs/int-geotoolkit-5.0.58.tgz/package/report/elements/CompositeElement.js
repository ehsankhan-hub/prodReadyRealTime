/* eslint-disable */

export {r0 as CompositeElement} from '@int/impl/geotoolkit.report.js';
