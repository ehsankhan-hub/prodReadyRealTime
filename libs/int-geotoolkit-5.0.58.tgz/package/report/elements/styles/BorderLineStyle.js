/* eslint-disable */

export {t_ as Style} from '@int/impl/geotoolkit.report.js';
