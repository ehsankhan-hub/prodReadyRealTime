/* eslint-disable */

export {KZ as ElementStyle} from '@int/impl/geotoolkit.report.js';
