/* eslint-disable */

export {y_ as BorderStyle} from '@int/impl/geotoolkit.report.js';
