/* eslint-disable */

export {M5 as Document} from '@int/impl/geotoolkit.report.js';
