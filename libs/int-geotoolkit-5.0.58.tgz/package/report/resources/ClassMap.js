/* eslint-disable */

export {m5 as ClassMap} from '@int/impl/geotoolkit.report.js';
