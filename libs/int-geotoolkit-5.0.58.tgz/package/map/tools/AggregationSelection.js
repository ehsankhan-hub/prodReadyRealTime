/* eslint-disable */

export {wrt as AggregationSelection} from '@int/impl/geotoolkit.map.js';
