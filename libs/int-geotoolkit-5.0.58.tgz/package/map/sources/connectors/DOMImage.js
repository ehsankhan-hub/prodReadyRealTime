/* eslint-disable */

export {Iet as DOMImage} from '@int/impl/geotoolkit.map.js';
