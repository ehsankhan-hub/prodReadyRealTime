/* eslint-disable */

export {XAt as Bing} from '@int/impl/geotoolkit.map.js';
