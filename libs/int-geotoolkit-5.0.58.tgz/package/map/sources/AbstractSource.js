/* eslint-disable */

export {Vit as AbstractSource} from '@int/impl/geotoolkit.map.js';
