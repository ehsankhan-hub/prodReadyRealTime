/* eslint-disable */

export {Bst as AbstractLoader} from '@int/impl/geotoolkit.map.js';
