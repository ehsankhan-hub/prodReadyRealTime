/* eslint-disable */

export {Ynt as ArcGISTile} from '@int/impl/geotoolkit.map.js';
