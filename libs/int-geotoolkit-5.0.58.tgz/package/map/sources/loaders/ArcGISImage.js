/* eslint-disable */

export {pnt as ArcGISImage} from '@int/impl/geotoolkit.map.js';
