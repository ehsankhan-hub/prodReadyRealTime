/* eslint-disable */

export {wnt as ArcGISFeature} from '@int/impl/geotoolkit.map.js';
