/* eslint-disable */

export {ZAt as Bing} from '@int/impl/geotoolkit.map.js';
