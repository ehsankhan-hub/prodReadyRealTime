/* eslint-disable */

export {xnt as ArcGISImage} from '@int/impl/geotoolkit.map.js';
