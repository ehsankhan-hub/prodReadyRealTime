/* eslint-disable */

export {Ktt as AxisDirection} from '@int/impl/geotoolkit.map.js';
