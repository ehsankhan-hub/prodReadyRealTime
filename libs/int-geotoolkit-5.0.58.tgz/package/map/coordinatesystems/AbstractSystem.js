/* eslint-disable */

export {ptt as AbstractSystem} from '@int/impl/geotoolkit.map.js';
