/* eslint-disable */

export {grt as BarScaleLabelMode} from '@int/impl/geotoolkit.map.js';
