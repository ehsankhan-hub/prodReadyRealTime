/* eslint-disable */

export {elt as BiggestGeometry} from '@int/impl/geotoolkit.map.js';
