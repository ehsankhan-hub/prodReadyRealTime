/* eslint-disable */

export {hlt as AnnotationFit} from '@int/impl/geotoolkit.map.js';
