/* eslint-disable */

export {ist as BaseConverter} from '@int/impl/geotoolkit.map.js';
