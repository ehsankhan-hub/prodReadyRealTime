/* eslint-disable */

export {Bit as Aggregation} from '@int/impl/geotoolkit.map.js';
