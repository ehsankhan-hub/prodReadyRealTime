/* eslint-disable */

export {Fst as Edge} from '@int/impl/geotoolkit.map.js';
