/* eslint-disable */

export {git as AbstractFeature} from '@int/impl/geotoolkit.map.js';
