/* eslint-disable */

export {Yst as AnnotationByRule} from '@int/impl/geotoolkit.map.js';
