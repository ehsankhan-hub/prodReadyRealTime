/* eslint-disable */

export {Zrt as AnnotationByAttribute} from '@int/impl/geotoolkit.map.js';
