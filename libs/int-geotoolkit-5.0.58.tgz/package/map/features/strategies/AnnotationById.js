/* eslint-disable */

export {lst as AnnotationById} from '@int/impl/geotoolkit.map.js';
