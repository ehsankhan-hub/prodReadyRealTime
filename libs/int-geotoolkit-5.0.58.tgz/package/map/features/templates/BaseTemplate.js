/* eslint-disable */

export {tst as BaseTemplate} from '@int/impl/geotoolkit.map.js';
