/* eslint-disable */

export {Yet as Aggregation} from '@int/impl/geotoolkit.map.js';
