/* eslint-disable */

export {wj as AnnotatedWidget, fj as Events} from '@int/impl/geotoolkit.widgets.js';
