/* eslint-disable */

export {O9 as Column} from '@int/impl/geotoolkit.widgets.js';
