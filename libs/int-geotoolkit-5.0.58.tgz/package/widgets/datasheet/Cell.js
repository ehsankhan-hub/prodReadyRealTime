/* eslint-disable */

export {P9 as Cell} from '@int/impl/geotoolkit.widgets.js';
