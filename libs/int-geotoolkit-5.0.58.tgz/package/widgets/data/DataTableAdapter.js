/* eslint-disable */

export {A7 as DataTableAdapter} from '@int/impl/geotoolkit.widgets.js';
