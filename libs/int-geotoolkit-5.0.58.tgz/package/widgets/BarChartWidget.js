/* eslint-disable */

export {T6 as BarChartWidget} from '@int/impl/geotoolkit.widgets.js';
