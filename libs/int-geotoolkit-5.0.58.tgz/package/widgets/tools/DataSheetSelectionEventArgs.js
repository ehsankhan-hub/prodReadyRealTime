/* eslint-disable */

export {K6 as DataSheetSelectionEventArgs} from '@int/impl/geotoolkit.widgets.js';
