/* eslint-disable */

export {tO as BaseWidget} from '@int/impl/geotoolkit.widgets.js';
