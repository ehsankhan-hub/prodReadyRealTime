/* eslint-disable */

export {E9 as AnnotationEventArgs} from '@int/impl/geotoolkit.widgets.js';
