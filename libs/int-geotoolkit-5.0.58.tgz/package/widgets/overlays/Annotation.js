/* eslint-disable */

export {S9 as Annotation} from '@int/impl/geotoolkit.widgets.js';
