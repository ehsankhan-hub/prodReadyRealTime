/* eslint-disable */

export {p6 as CrossPlot} from '@int/impl/geotoolkit.widgets.js';
