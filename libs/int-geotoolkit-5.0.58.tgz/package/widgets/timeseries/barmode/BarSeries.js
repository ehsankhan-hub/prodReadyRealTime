/* eslint-disable */

export {H4 as BarSeries} from '@int/impl/geotoolkit.widgets.js';
