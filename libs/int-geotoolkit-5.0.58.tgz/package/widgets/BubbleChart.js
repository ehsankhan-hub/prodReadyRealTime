/* eslint-disable */

export {S6 as BubbleChart} from '@int/impl/geotoolkit.widgets.js';
