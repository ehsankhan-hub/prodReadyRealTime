/* eslint-disable */

export {DX as CgmExport} from '@int/impl/geotoolkit.cgm.js';
