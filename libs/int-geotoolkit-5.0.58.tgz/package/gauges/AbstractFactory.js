/* eslint-disable */

export {O7 as AbstractFactory} from '@int/impl/geotoolkit.gauges.js';
