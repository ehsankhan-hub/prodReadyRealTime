/* eslint-disable */

export {L7 as AxisGauge} from '@int/impl/geotoolkit.gauges.js';
