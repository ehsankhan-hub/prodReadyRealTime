/* eslint-disable */

export {P7 as CircularGauge} from '@int/impl/geotoolkit.gauges.js';
