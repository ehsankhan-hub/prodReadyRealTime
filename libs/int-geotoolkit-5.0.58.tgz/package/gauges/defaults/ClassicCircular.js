/* eslint-disable */

export {X7 as ClassicCircular} from '@int/impl/geotoolkit.gauges.js';
