/* eslint-disable */

export {j7 as AnnotatedFillGauge} from '@int/impl/geotoolkit.gauges.js';
