/* eslint-disable */

export {W7 as BandCircular} from '@int/impl/geotoolkit.gauges.js';
