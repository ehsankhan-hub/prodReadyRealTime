/* eslint-disable */

export {_7 as DoubleAxisCircular} from '@int/impl/geotoolkit.gauges.js';
