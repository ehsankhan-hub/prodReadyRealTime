/* eslint-disable */

export {ttt as EllipseFillGauge} from '@int/impl/geotoolkit.gauges.js';
