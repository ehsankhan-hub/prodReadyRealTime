/* eslint-disable */

export {Z7 as CoveredNeedleCircular} from '@int/impl/geotoolkit.gauges.js';
