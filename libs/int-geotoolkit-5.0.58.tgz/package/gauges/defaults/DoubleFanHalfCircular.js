/* eslint-disable */

export {$7 as DoubleFanHalfCircular} from '@int/impl/geotoolkit.gauges.js';
