/* eslint-disable */

export {J7 as CircularAxis} from '@int/impl/geotoolkit.gauges.js';
