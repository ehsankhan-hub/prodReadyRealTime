/* eslint-disable */

export {x7 as Axis, G7 as Events} from '@int/impl/geotoolkit.gauges.js';
