/* eslint-disable */

export {Q7 as Alarm} from '@int/impl/geotoolkit.gauges.js';
