/* eslint-disable */

export {eI as DateTimeTickGenerator, qf as LabelMode} from '@int/impl/geotoolkit.base.js';
