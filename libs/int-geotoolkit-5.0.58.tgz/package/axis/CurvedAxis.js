/* eslint-disable */

export {KB as CurvedAxis} from '@int/impl/geotoolkit.base.js';
