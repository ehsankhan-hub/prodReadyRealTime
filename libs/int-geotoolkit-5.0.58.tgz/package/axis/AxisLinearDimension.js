/* eslint-disable */

export {JB as AxisLinearDimension} from '@int/impl/geotoolkit.base.js';
