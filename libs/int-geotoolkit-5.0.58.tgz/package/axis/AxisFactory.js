/* eslint-disable */

export {ew as AxisFactory} from '@int/impl/geotoolkit.base.js';
