/* eslint-disable */

export {sQ as AdaptiveDateTimeTickGenerator} from '@int/impl/geotoolkit.base.js';
