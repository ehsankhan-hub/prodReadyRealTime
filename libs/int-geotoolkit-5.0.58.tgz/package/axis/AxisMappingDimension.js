/* eslint-disable */

export {qB as AxisMappingDimension} from '@int/impl/geotoolkit.base.js';
