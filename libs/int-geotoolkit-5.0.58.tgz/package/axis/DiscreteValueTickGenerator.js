/* eslint-disable */

export {Kf as DiscreteValueTickGenerator} from '@int/impl/geotoolkit.base.js';
