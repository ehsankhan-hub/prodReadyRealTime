/* eslint-disable */

export {WD as Base64} from '@int/impl/geotoolkit.base.js';
