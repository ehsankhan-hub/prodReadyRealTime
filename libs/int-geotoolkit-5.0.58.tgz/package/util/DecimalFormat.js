/* eslint-disable */

export {qg as DecimalFormat} from '@int/impl/geotoolkit.base.js';
