/* eslint-disable */

export {Wg as DateUtil} from '@int/impl/geotoolkit.base.js';
