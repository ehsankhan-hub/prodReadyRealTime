/* eslint-disable */

export {eh as ColorUtil, sh as KnownColors} from '@int/impl/geotoolkit.base.js';
