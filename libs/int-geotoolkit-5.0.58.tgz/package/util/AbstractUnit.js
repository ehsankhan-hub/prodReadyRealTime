/* eslint-disable */

export {gh as AbstractUnit} from '@int/impl/geotoolkit.base.js';
