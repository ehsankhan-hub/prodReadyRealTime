/* eslint-disable */

export {eu as DiscreteGradientColorProvider} from '@int/impl/geotoolkit.base.js';
