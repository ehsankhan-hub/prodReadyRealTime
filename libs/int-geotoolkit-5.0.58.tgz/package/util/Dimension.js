/* eslint-disable */

export {Ah as Dimension} from '@int/impl/geotoolkit.base.js';
