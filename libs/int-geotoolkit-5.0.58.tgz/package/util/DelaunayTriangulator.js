/* eslint-disable */

export {Tb as DelaunayTriangulator} from '@int/impl/geotoolkit.base.js';
