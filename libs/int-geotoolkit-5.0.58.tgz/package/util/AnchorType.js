/* eslint-disable */

export {HA as AnchorType} from '@int/impl/geotoolkit.base.js';
