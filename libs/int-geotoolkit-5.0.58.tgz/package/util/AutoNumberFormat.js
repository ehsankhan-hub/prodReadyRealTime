/* eslint-disable */

export {Jg as AutoNumberFormat} from '@int/impl/geotoolkit.base.js';
