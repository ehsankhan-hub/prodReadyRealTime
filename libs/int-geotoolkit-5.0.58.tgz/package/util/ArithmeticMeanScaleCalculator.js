/* eslint-disable */

export {Pb as ArithmeticMeanScaleCalculator} from '@int/impl/geotoolkit.base.js';
