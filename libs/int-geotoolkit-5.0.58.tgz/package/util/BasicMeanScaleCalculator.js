/* eslint-disable */

export {Jb as BasicMeanScaleCalculator} from '@int/impl/geotoolkit.base.js';
