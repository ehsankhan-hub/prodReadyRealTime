/* eslint-disable */

export {gA as BrowserInfo} from '@int/impl/geotoolkit.base.js';
