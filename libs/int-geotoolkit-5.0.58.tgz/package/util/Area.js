/* eslint-disable */

export {KA as Area} from '@int/impl/geotoolkit.base.js';
