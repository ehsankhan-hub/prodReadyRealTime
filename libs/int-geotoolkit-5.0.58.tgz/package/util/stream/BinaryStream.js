/* eslint-disable */

export {hv as BinaryStream} from '@int/impl/geotoolkit.base.js';
