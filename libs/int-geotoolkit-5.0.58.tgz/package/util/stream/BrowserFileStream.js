/* eslint-disable */

export {Av as BrowserFileStream} from '@int/impl/geotoolkit.base.js';
