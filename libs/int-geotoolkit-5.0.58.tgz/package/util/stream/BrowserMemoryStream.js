/* eslint-disable */

export {nv as BrowserMemoryStream} from '@int/impl/geotoolkit.base.js';
