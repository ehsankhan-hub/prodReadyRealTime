/* eslint-disable */

export {nX as BufferAttribute} from '@int/impl/geotoolkit.base.js';
