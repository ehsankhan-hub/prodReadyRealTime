/* eslint-disable */

export {qc as AnnotationLocation} from '@int/impl/geotoolkit.base.js';
