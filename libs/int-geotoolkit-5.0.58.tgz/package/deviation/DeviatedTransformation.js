/* eslint-disable */

export {kIt as DeviatedTransformation} from '@int/impl/geotoolkit.deviation.js';
