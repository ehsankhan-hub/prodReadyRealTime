/* eslint-disable */

export {hvt as DeviatedValueTransformer} from '@int/impl/geotoolkit.deviation.js';
