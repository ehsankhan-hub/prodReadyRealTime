/* eslint-disable */

export {evt as DeviatedHeader} from '@int/impl/geotoolkit.deviation.js';
