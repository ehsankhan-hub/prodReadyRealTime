/* eslint-disable */

export {ZHt as AbstractLegendItemInfoProvider} from '@int/impl/geotoolkit.schematics.js';
