/* eslint-disable */

export {Uqt as DualSchematicsWidget} from '@int/impl/geotoolkit.schematics.js';
