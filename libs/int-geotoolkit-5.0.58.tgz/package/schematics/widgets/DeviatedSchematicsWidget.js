/* eslint-disable */

export {Tqt as DeviatedSchematicsWidget} from '@int/impl/geotoolkit.schematics.js';
