/* eslint-disable */

export {mUt as ComponentUtils} from '@int/impl/geotoolkit.schematics.js';
