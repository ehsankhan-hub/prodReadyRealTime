/* eslint-disable */

export {LYt as BoundsCalculationRegistry} from '@int/impl/geotoolkit.schematics.js';
