/* eslint-disable */

export {zUt as DefaultAliases} from '@int/impl/geotoolkit.schematics.js';
