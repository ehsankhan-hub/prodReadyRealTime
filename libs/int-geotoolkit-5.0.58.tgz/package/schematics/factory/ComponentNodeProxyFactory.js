/* eslint-disable */

export {XUt as ComponentNodeProxyFactory} from '@int/impl/geotoolkit.schematics.js';
