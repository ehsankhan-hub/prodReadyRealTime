/* eslint-disable */

export {pYt as DefaultMap} from '@int/impl/geotoolkit.schematics.js';
