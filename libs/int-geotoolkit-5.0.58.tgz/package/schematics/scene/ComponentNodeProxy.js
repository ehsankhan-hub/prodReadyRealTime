/* eslint-disable */

export {TUt as ComponentNodeProxy} from '@int/impl/geotoolkit.schematics.js';
