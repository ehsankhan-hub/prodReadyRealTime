/* eslint-disable */

export {EHt as DeviatedWellBoreWithLabels} from '@int/impl/geotoolkit.schematics.js';
