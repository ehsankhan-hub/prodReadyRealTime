/* eslint-disable */

export {SYt as CompressedViewModeBuilder} from '@int/impl/geotoolkit.schematics.js';
