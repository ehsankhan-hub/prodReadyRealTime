/* eslint-disable */

export {eHt as DefaultLabelingStrategy} from '@int/impl/geotoolkit.schematics.js';
