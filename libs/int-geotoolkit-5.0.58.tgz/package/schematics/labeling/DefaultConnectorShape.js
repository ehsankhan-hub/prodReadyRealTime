/* eslint-disable */

export {oKt as DefaultConnectorShape} from '@int/impl/geotoolkit.schematics.js';
