/* eslint-disable */

export {bHt as DefaultLabelShape} from '@int/impl/geotoolkit.schematics.js';
