/* eslint-disable */

export {hKt as AlignmentType} from '@int/impl/geotoolkit.schematics.js';
