/* eslint-disable */

export {lKt as ConnectorShape} from '@int/impl/geotoolkit.schematics.js';
