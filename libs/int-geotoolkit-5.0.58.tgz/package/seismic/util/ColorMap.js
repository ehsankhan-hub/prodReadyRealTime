/* eslint-disable */

export {VNt as ColorMap} from '@int/impl/geotoolkit.seismic.js';
