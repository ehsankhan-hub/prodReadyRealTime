/* eslint-disable */

export {CGt as DataConverter} from '@int/impl/geotoolkit.seismic.js';
