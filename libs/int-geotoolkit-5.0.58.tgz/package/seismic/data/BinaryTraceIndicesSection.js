/* eslint-disable */

export {TGt as BinaryTraceIndicesSection} from '@int/impl/geotoolkit.seismic.js';
