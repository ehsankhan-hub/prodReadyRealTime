/* eslint-disable */

export {EGt as BinaryField} from '@int/impl/geotoolkit.seismic.js';
