/* eslint-disable */

export {IFt as DataTransformation} from '@int/impl/geotoolkit.seismic.js';
