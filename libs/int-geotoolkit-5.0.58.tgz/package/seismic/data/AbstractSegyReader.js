/* eslint-disable */

export {qGt as AbstractSegyReader} from '@int/impl/geotoolkit.seismic.js';
