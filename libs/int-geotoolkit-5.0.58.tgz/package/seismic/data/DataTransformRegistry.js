/* eslint-disable */

export {XGt as DataTransformRegistry} from '@int/impl/geotoolkit.seismic.js';
