/* eslint-disable */

export {yGt as ByteOrder} from '@int/impl/geotoolkit.seismic.js';
