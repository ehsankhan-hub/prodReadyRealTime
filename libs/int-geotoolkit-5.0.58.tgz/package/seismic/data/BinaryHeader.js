/* eslint-disable */

export {DGt as BinaryHeader} from '@int/impl/geotoolkit.seismic.js';
