/* eslint-disable */

export {dSt as DataFormatType} from '@int/impl/geotoolkit.seismic.js';
