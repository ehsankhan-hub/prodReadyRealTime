/* eslint-disable */

export {$Gt as Decompress} from '@int/impl/geotoolkit.seismic.js';
