/* eslint-disable */

export {LGt as DataConverterFactory} from '@int/impl/geotoolkit.seismic.js';
