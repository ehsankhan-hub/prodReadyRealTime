/* eslint-disable */

export {mGt as DataHeader} from '@int/impl/geotoolkit.seismic.js';
