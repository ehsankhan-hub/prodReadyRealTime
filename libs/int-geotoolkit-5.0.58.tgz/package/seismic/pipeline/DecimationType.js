/* eslint-disable */

export {ikt as DecimationType} from '@int/impl/geotoolkit.seismic.js';
