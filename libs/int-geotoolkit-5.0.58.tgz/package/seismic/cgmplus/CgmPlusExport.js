/* eslint-disable */

export {GLt as CgmPlusExport} from '@int/impl/geotoolkit.seismic.js';
