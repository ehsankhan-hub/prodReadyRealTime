/* eslint-disable */

export {Fxt as Comparator} from '@int/impl/geotoolkit.seismic.js';
