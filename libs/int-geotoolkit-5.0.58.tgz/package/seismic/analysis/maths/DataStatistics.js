/* eslint-disable */

export {FLt as DataStatistics} from '@int/impl/geotoolkit.seismic.js';
