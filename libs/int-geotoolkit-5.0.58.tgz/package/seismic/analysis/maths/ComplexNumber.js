/* eslint-disable */

export {VLt as ComplexNumber} from '@int/impl/geotoolkit.seismic.js';
