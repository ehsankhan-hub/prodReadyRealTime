/* eslint-disable */

export {TLt as DataPadding} from '@int/impl/geotoolkit.seismic.js';
