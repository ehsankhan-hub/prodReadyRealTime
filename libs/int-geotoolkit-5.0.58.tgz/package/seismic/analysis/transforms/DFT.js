/* eslint-disable */

export {OLt as DFT} from '@int/impl/geotoolkit.seismic.js';
