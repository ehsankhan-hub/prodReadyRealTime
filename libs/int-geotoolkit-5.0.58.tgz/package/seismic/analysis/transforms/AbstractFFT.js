/* eslint-disable */

export {KLt as AbstractFFT} from '@int/impl/geotoolkit.seismic.js';
