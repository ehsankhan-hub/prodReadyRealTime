/* eslint-disable */

export {xot as DiagramTool} from '@int/impl/geotoolkit.flowcharts.js';
