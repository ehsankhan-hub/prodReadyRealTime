/* eslint-disable */

export {Yot as DiagramWidget} from '@int/impl/geotoolkit.flowcharts.js';
