/* eslint-disable */

export {Aot as DiagramVisual} from '@int/impl/geotoolkit.flowcharts.js';
