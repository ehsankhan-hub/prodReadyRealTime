/* eslint-disable */

export {Kot as DefaultComponents} from '@int/impl/geotoolkit.flowcharts.js';
