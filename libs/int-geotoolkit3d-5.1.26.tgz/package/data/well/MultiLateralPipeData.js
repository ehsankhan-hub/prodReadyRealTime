/* eslint-disable */

export {c4t as MultiLateralPipeData} from '@int/impl/geotoolkit3d.js';
