/* eslint-disable */

export {b5t as MultiLateralWellData} from '@int/impl/geotoolkit3d.js';
