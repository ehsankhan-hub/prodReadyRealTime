/* eslint-disable */

export {w2t as AbstractLoader} from '@int/impl/geotoolkit3d.js';
