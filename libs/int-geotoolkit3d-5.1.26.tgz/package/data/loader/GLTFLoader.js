/* eslint-disable */

export {I2t as GLTFLoader} from '@int/impl/geotoolkit3d.js';
