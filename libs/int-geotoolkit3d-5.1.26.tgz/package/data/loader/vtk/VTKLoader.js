/* eslint-disable */

export {G3t as VTKLoader} from '@int/impl/geotoolkit3d.js';
