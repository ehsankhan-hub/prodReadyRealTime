import { AbstractSurfaceData } from '@int/geotoolkit3d/data/surface/AbstractSurfaceData';
import { GridTriangulator } from '@int/geotoolkit3d/util/surface/GridTriangulator';
/**
 * Surface data made of a vertices grid that can be triangulated.<br>
 * <br>
 * The grid is expected to have column first:<br>
 * <pre>
 * [(0,0), (1,0), (2,0), (3,0), (0,1), (1,1), (2,1), (3,1), [...], (0,3), (1,3), (2,3), (3,3)]
 * </pre>
 * <br>
 * X and Y values are optionals:<br>
 * If only elevations are provided, X and Y values will be determined from the xmin, xstep, ymin, and ystep values.<br>
 * If both xvalues and yvalues arrays are provided, they should be in the same layout as the elevation array.<br>
 * @throws {Error} if the Surface Data is not compliant and compromise the creation of the surface.
 * @throws {Error} SurfaceData is empty after triangulation
 */
export declare class GridSurfaceData extends AbstractSurfaceData {
    constructor(options: GridSurfaceData.Options);
    /**
     * Returns the GridSurfaceData attributes.
     */
    getAttributes(): GridSurfaceData.Attributes;
}
export declare namespace GridSurfaceData {
    /**
     * The options
     */
    type Options = Omit<GridTriangulator.Options, 'data'> & {
        /**
         * The data options
         */
        data: GridTriangulator.Data & {
            /**
             * optional Values to associate to each point/elevation in the Grid data.
             */
            values?: number[];
        };
    };
    type GridProperties = {
        /**
         * The number of vertices of the heightmap Mesh on its local X axis.<br>
         * More vertices means a more detailed heightmap surface. Default to 256.
         */
        width: number;
        /**
         * The number of vertices of the heightmap Mesh on its local Y axis.<br>
         * More vertices means a more detailed heightmap surface. Default to 256.
         */
        height: number;
    };
    /**
     * The HeightMap attributes.
     */
    type Attributes = AbstractSurfaceData.Attributes & GridProperties;
}
