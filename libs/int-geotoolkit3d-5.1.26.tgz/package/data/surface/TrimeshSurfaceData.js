/* eslint-disable */

export {EZt as TrimeshSurfaceData} from '@int/impl/geotoolkit3d.js';
