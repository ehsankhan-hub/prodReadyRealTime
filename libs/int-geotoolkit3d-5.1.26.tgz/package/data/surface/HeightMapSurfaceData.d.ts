import { AbstractSurfaceData } from '@int/geotoolkit3d/data/surface/AbstractSurfaceData';
import type { Texture } from 'three';
import { GridTriangulator } from '@int/geotoolkit3d/util/surface/GridTriangulator';
import type { GridSurfaceData } from '@int/geotoolkit3d/data/surface/GridSurfaceData';
/**
 * Surface data using a heightmap.<br>
 * <br>
 * This surface data object implements a {@link https://en.wikipedia.org/wiki/Heightmap heightmap}.<br>
 * Elevations are stored as normalized values into the given 2D texture.
 */
export declare class HeightMapSurfaceData extends AbstractSurfaceData {
    constructor(options: HeightMapSurfaceData.Options);
    /**
     * Returns the HeightMap surface attributes
     */
    getAttributes(): HeightMapSurfaceData.Attributes;
}
export declare namespace HeightMapSurfaceData {
    type HeightMapData = GridSurfaceData.GridProperties & {
        /**
         * The elevation map texture.<br>
         * Note that it's assumed to be greyscale.<br>
         * This parameter is optional, and the heightmap can be set later via server data, using {@link @int/geotoolkit3d/scene/surface/Surface~Surface}'s geometry option.
         */
        heightmap?: Texture;
        /**
         * A nullvalue that filter elevation map texture values only. Elevations matching this value will not be rendered.<br>
         * To filter propertie values exclusively, please instead use Surface.Options.data.nullvalue.
         * Default value is Number.NaN.
         */
        elevationnullvalue?: number;
    };
    /**
     * The options
     */
    type Options = Omit<GridTriangulator.Options, 'data'> & {
        /**
         * The HeightMap data options.
         */
        data?: Partial<HeightMapData>;
    };
    /**
     * The HeightMap attributes.
     */
    type Attributes = AbstractSurfaceData.Attributes & HeightMapData;
}
