import { AbstractSurfaceData } from '@int/geotoolkit3d/data/surface/AbstractSurfaceData';
import { DelaunayTriangulator } from '@int/geotoolkit/util/DelaunayTriangulator';
/**
 * A Surface data class created from raw vertices (non-indexed set of 3D points).<br>
 * This class triangulate the given vertices using Delaunay algorithms, to produce a valid Surface.
 * @throws {Error} if the Surface Data is not compliant and compromise the creation of the surface.
 * @throws {Error} SurfaceData is empty after triangulation
 */
export declare class SurfaceData extends AbstractSurfaceData {
    constructor(options: SurfaceData.Options);
}
export declare namespace SurfaceData {
    /**
     * The options
     */
    type Options = Omit<TriangulateOptions, 'data'> & {
        /**
         * The data options
         */
        data: {
            /**
             * The X values to triangulate
             */
            x: number[];
            /**
             * The Y values to triangulate
             */
            y: number[];
            /**
             * The Z values to triangulate
             */
            z: number[];
            /**
             * The value representing a non-value elevation
             */
            nullvalue?: number;
            /**
             * optional Value array to instantiate
             */
            values?: number[];
        };
    };
    type TriangulateOptions = {
        data: {
            x: number[];
            y: number[];
            z: number[];
        };
        /**
         * optional. options for triangulation of unordered surface points.
         */
        unorderedtriangulation: Omit<DelaunayTriangulator.TriangulateSurface, 'nullvalue'> & {
            /**
             * optional. Try changing this value if experiencing artifacts on the rendered surface.
             * If true, use the default triangulation algorithm for non-ordered (random) point sets.
             * If false, use an alternative triangulation algorithm for already ordered point sets. The alternative triangulation is much slower, and works better for pointsets ordered in row/columns, in this case only will it produce more accurate results.
             */
            enable?: boolean;
        };
    };
}
