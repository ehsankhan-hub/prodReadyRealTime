/* eslint-disable */

export {yZt as AbstractSurfaceData} from '@int/impl/geotoolkit3d.js';
