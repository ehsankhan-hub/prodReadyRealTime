/* eslint-disable */

export {j1t as SurfaceData} from '@int/impl/geotoolkit3d.js';
