import type { Box3 } from 'three';
/**
 * Parent class for reservoir and grid data
 */
export declare abstract class AbstractReservoirData {
    /**
     * Returns the metadata of the grid
     */
    abstract getMetaData(): AbstractReservoirData.MetaData;
    /**
     * Returns the total number of cells in the grid, includes NaN and nullvalues cells.
     * @returns cellcount
     */
    abstract getNumberOfCells(): number;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace AbstractReservoirData {
    /**
     * The Grid meta data, common to all Grid data structures.
     */
    type MetaData = {
        /**
         * The Grid boundaries, in the grid local coordinates.
         */
        boundingbox: Box3;
        /**
         * The grid total cell count, includes NaN and nullvalues cells.
         */
        cellcount: number;
    };
}
