/* eslint-disable */

export {b6t as ReservoirData} from '@int/impl/geotoolkit3d.js';
