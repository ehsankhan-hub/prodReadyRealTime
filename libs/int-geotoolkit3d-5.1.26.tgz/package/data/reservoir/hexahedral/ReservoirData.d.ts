import { AbstractReservoirData } from '@int/geotoolkit3d/data/reservoir/AbstractReservoirData';
import { IJKIndex } from '@int/geotoolkit3d/scene/reservoir/IJKIndex';
import type { TypedArray } from '@int/geotoolkit/util/TypedArray';
/**
 * This class host the Reservoir data using hexahedral (8 corner per cell) cell structure.<br>
 * One value per cell can be added for both filtering and render coloration purpose.<br>
 * Additionally, multiple additional data can be defined per cell to be used along user-defined filters,
 * allowing for very customizable cell filtering.<br>
 * The cell data format expected by the ReservoirData constructor:<ul>
 * <li>The reservoir data format require 8 vertices per cell.</li>
 * <li>Cells do not need to be cubes or have parallel faces.</li>
 * <li>Neighboring cells do not need to share the same corners (useful to represent faults).</li>
 * </ul>
 * The geometrical data are expected in a regular order, see example<br>
 * x values are [xA, xB, xC, xD, xE, xF, xG, xH],<br>
 * y values are [yA, ..., yH]<br>
 * and z values are [zA, ..., zH]<br>
 * @example
 *
 * I |------>
 *
 * A ------- B            __
 * |\        |\            \
 * | \       | \            \  J
 * |  C ------- D     _      v
 * E -|----- F  |     |
 *  \ |       \ |     | K
 *   \|        \|     |
 *    G ------- H     v
 */
export declare class ReservoirData extends AbstractReservoirData {
    constructor(options: ReservoirData.Options);
    getMetaData(): ReservoirData.ReservoirMetaData;
    /**
     * Return the sequence of point indices to draw the cell triangles.<br>
     * Will return an array of 36 indices (6 faces * 2 triangle * 3points) where each index is a number between 0 and 7 which
     * correspond to the cell corners from A to H.
     * @example
     * 0 ------- 1
     * |\        |\
     * | \       | \
     * |  2 ------- 3
     * 4 -|----- 5  |
     *  \ |       \ |
     *   \|        \|
     *    6 ------- 7
     */
    getCellTriangleIndices(): number[];
    /**
     * Define the vertices repartition for turning a cell into individual convex tetrahedrons.<br>
     * Divide the cell into 6 tetrahedrons and return the indices, used for intersections.
     * @example
     * 0 ------- 1
     * |\        |\
     * | \       | \
     * |  2 ------- 3
     * 4 -|----- 5  |
     *  \ |       \ |
     *   \|        \|
     *    6 ------- 7
     */
    getCellTetrahedronIndices(): number[][];
    /**
     * Returns the index for the reservoir cell based on the given i j k index
     * @returns index for this i j k cell (null if the cell doesn't exist)
     */
    getIndexForCell(i: number, j: number, k: number): number | null;
    /**
     * Return the IJK index of the cell identified by the given position in the reservoir.
     * @param index the cell index in the reservoir. Index start at 0, and must be inferior to the total number of cells.
     */
    getCellIJKbyIndex(index: number): [
        i: number,
        j: number,
        k: number
    ];
    /**
     * Return true if the given cell index match an existing cell, false if not. Ignore user filters.
     * @param index the cell index to check the validity of.
     * @returns true if the cell index is valid, false if the index is out of bounds.
     */
    isCellIndexValid(index: number): boolean;
    /**
     * This utility will check for duplicate IJK indices in the reservoirData.<br>
     * Each cell must have an identical IJK index, this tool is made to verify this.<br>
     * Depending on the number of cells this can be VERY slow, so please use only when debugging.
     * @param ijk the IJK typed array.
     */
    static checkDuplicateIJK(ijk: ReservoirData.IJKArray): void;
    /**
     * Returns the number of cells in the data object.
     * @returns number of cells
     */
    getNumberOfCells(): number;
    /**
     * Returns the Cell Data from the given IJK index.
     * @param ijk the ijk position of the cell data to retrieve.
     * @returns the cell data, or null if the cell is not found.
     */
    getCellData(ijk: IJKIndex | number[]): ReservoirData.CellData | null;
    /**
     * Returns the Cell Data from the given cell index.
     * @param index the index of the cell data to retrieve.
     * @returns the cell data, or null if the cell is not found.
     */
    getCellDataByIndex(index: number): ReservoirData.CellData | null;
    /**
     * Returns the ijk count for this reservoir data.
     */
    getIJKCount(): IJKIndex;
    /**
     * Compute the reservoir cells volume, and enable volume data in {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#getCellData}() method.
     */
    computeCellsVolume(): void;
    /**
     * Returns the total volume measure of this reservoir.<br>
     * Computed by the sum of the volume of every cells, filters are ignored.<br>
     * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
     * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
     */
    getReservoirFullVolume(): number;
    /**
     * Dispose this reservoir data to allow for garbage collection.
     */
    dispose(): void;
}
export declare namespace ReservoirData {
    type Options = {
        /**
         * The structure holding the cells data (xyz coordinates, ijk indices, and optional values).<br>
         * This is the recommended format to provide cells data, as providing cells in typed array is
         * much more efficient from a memory/performance perspective than the legacy structure.
         */
        cellsdata: CellsDataArrays;
        /**
         * If true, precompute the cells volume. Can be computed later using {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#computeCellsVolume}().<br>
         * Volume can then be obtained using {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#getReservoirFullVolume}(),
         * or per cell through {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#getCellData}(cellIndex).volume.
         */
        computecellsvolume?: boolean;
        /**
         * The value to be used when a cell has no value, default is -999.25.
         */
        nullvalue?: number;
        /**
         * If true, inverts the cell faces triangle splits, for the top and bottom faces. This change the diagonal of the face's quad.<br>
         * Default is false.
         */
        invertfacesplit?: boolean;
    };
    type ReservoirMetaData = AbstractReservoirData.MetaData & {
        /**
         * The number of I, J and K layers this reservoir possess.
         */
        numijk: IJKIndex;
        /**
         * The minimum cell property value currently stored in this reservoir data.
         */
        minvalue: number;
        /**
         * The maximum cell property value currently stored in this reservoir data.
         */
        maxvalue: number;
        /**
         * The minimum I index of this reservoir.
         */
        mini: number;
        /**
         * The maximum I index of this reservoir.
         */
        maxi: number;
        /**
         * The minimum J index of this reservoir.
         */
        minj: number;
        /**
         * The maximum J index of this reservoir.
         */
        maxj: number;
        /**
         * The minimum K index of this reservoir.
         */
        mink: number;
        /**
         * The maximum K index of this reservoir.
         */
        maxk: number;
        /**
         * The value to be used when a cell has no value, default is -999.25.
         */
        nullvalue: number;
        /**
         * If true, inverts the cell faces triangle splits, for the top and bottom faces. This change the diagonal of the face's quad.<br>
         * Default is false.
         */
        invertfacesplit: boolean;
    };
    /**
     * This object contains the cell geometric values.
     */
    type CellPosition = {
        /**
         * The ijk index of the cell.
         */
        ijk: number[];
        /**
         * The x values of the 8 cell corners.
         */
        x: number[];
        /**
         * The y values of the 8 cell corners.
         */
        y: number[];
        /**
         * The z values of the 8 cell corners.
         */
        z: number[];
    };
    /**
     * The cell data format expected by the ReservoirData constructor:<ul>
     * <li>The reservoir data format require 8 vertices per cell.</li>
     * <li>Cells do not need to be cubes or have parallel faces.</li>
     * <li>Neighboring cells do not need to share the same corners (useful to represent faults).</li>
     * </ul>
     * The geometrical data are expected in a regular order, see example<br>
     * x values are [xA, xB, xC, xD, xE, xF, xG, xH],<br>
     * y values are [yA, ..., yH]<br>
     * and z values are [zA, ..., zH]<br>
     * @example
     *
     * I |------>
     *
     * A ------- B            __
     * |\        |\            \
     * | \       | \            \  J
     * |  C ------- D     _      v
     * E -|----- F  |     |
     *  \ |       \ |     | K
     *   \|        \|     |
     *    G ------- H     v
     */
    type CellsDataArrays = {
        /**
         * The X coordinates of each cell vertices, stored in a typed array.<br>
         * There must be 8 contiguous X coordinates for each cell in the reservoir.
         */
        x: Float32Array;
        /**
         * The Y coordinates of each cell vertices, stored in a typed array.<br>
         * There must be 8 contiguous Y coordinates for each cell in the reservoir.
         */
        y: Float32Array;
        /**
         * The Z coordinates of each cell vertices, stored in a typed array.<br>
         * There must be 8 contiguous Z coordinates for each cell in the reservoir.
         */
        z: Float32Array;
        /**
         * The IJK indices of each cell, stored in a typed array.<br>
         * There must be 3 contiguous values (i, j and k) for each cell in the reservoir.
         */
        ijk: IJKArray;
        /**
         * The value of each cell, stored in a typed array.<br>
         * This array is optional and can be added later through the ReservoirGrid.<br>
         * If defined, there must be one value for each cell in the reservoir, even if the cell has no value (see nullvalue).
         */
        values?: Float32Array;
        /**
         * Additional cell properties, which can be used together with user-defined Reservoir filter.<br>
         * Each additional property consist of a named field containing an Arraylike object (Javascript array, TypedArray, etc).<br>
         * Each of these array should have one value for each cell, in the correct order.<br>
         * We suggest using TypedArrays such as (but not limited to) Float32Array when using very large reservoirs, to reduce the memory footprint.
         */
        additionalcelldata?: Record<string, any[] | TypedArray>;
    };
    /**
     * The structure for setting cells values.<br>
     * Must at least contain either values or additional data.
     */
    type CellsValues = {
        /**
         * The values of each cell to update, in a typed array.<br>
         * Must include either:<ul>
         * <li>All values of each cells in the same order the cells were created ("ijk" must not be specified).</li>
         * <li>Only the necessary values to update ("ijk" field is required)</li></ul>
         */
        values?: Float32Array;
        /**
         * The IJK indices of the cells to update the values of.<br>
         * Contains the indices in a contiguous typed array in this fashion: [i1, j1, k1, i2, j2, k2,...]<br>
         * Only necessary if the "values" field or "additionalcelldata" is not in the same order the cells were created originally, or if only a subset of cells are updated.
         */
        ijk?: IJKArray;
        /**
         * Additional cell properties, which can be used together with user-defined Reservoir filter.<br>
         * Each additional property consist of a named field containing an Arraylike object (either a regular array or Typed array).<br>
         * As with the values option, if IJKs are not provided, additionaldata array is expected to match the size and order of existing cells.<br>
         * We advise using TypedArrays such as Float32Array or even Uint 16/8 bit when possible when using very large reservoirs, to reduce the memory footprint.
         */
        additionalcelldata?: Record<string, any[] | TypedArray>;
    };
    /**
     * The object holding the cell data, or null if the cell is not found.
     */
    type CellData = CellPosition & {
        /**
         * The ijk index which was given as parameter to {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#getCellData}().
         */
        index: IJKIndex | number[];
        /**
         * The volume of the cell, based on the cell xyz coordinates, if the volume has been calculated.
         * (Will be undefined if the Reservoir volume has not been computed yet! See {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#computeCellsVolume}()).<br>
         * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
         * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
         */
        volume?: number;
        /**
         * The [minx, miny, minz, maxx, maxy, maxz] boundaries of this cell. These boundaries will be in Reservoir local coordinates.
         */
        bound: number[];
        /**
         * The ijk index of the cell.
         */
        ijk: number[];
        /**
         * The value of the cell.
         */
        value: number;
        /**
         * Additional cell data(s) defined by the user, for custom filtering.
         */
        additionalcelldata?: Record<string, any>;
    };
    type IJKArray = Int16Array | Uint16Array | Uint32Array;
}
