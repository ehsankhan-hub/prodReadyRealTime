/**
 * Iterator to iterate over each cell IJK indices in a voxel grid.
 * Because grid can contain million of cells, this iterator cannot fully implement geotoolkit/util/iterator
 */
export declare class CellIJKIterator {
    /**
     * Constructor
     * @param iCount the grid size on the I axis.
     * @param jCount the grid size on the J axis.
     * @param kCount the grid size on the K axis.
     */
    constructor(iCount: number, jCount: number, kCount: number);
    /**
     * Reset this iterator back to the first cell.
     */
    reset(): this;
    /**
     * Returns true if the iterator has another cell to iterate on.
     * @returns true if the iterator has another cell to iterate on.
     */
    hasNext(): boolean;
    /**
     * Iterate over the next cell, and provide the cell indices. The absolute index is a unique index number allocated
     * to each cell, start from 0 and goes up to sizeI * sizeJ * sizeK.<br>
     * Please note this iterator might provide indices for cells with nullvalues/NaN values, please verify the value for the resulting cell.
     * @returns the Cell IJK indices
     */
    next(): CellIJKIterator.CellIndices;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace CellIJKIterator {
    /**
     * The cell absolute index and IJK indices
     */
    type CellIndices = [
        /**
         * The cell I index, goes from 0 to sizeI - 1
         */
        i: number,
        /**
         * The cell J index, goes from 0 to sizeJ - 1
         */
        j: number,
        /**
         * The cell K index, goes from 0 to sizeK - 1
         */
        k: number,
        /**
         * The cell absolute index, a unique number that start from 0 and goes up to sizeI * sizeJ * sizeK - 1.
         */
        index: number
    ];
}
