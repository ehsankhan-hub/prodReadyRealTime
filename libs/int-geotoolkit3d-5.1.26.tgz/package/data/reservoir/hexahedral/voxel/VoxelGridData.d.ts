/**
 * @module geotoolkit3d/data/reservoir/hexahedral/voxel/VoxelGridData
 */
import { AbstractReservoirData } from '@int/geotoolkit3d/data/reservoir/AbstractReservoirData';
import { IJKIndex } from '@int/geotoolkit3d/scene/reservoir/IJKIndex';
import { Euler, Vector3 } from 'three';
import type { TypedArray } from '@int/geotoolkit/util/TypedArray';
import { CellIJKIterator } from '@int/geotoolkit3d/data/reservoir/hexahedral/voxel/CellIJKIterator';
/**
 * Define which compression is used for the related Array.
 * @readonly
 * @enum
 */
export declare enum ArrayCompression {
    /**
     * No compression, the array of values is provided as-is.
     */
    NoCompression = "NoCompression",
    /**
     * Run-Length Encoding, see {@link https://en.wikipedia.org/wiki/Run-length_encoding Run-length encoding on wikipedia}
     */
    RLE = "RLE"
}
/**
 * This class host the VoxelGrid data using hexahedral vector cell structure. Each cell has the same shape within the grid, defined by 3 vectors.<br>
 * One value per cell can be added for both filtering and render coloration purpose.<br>
 * Additionally, multiple additional data can be defined per cell to be used along user-defined filters,
 * allowing for very customizable cell filtering.<br>
 * The cell data format expected by the VoxelGridData constructor:<ul>
 * <li>The voxel cell data format require 3 vectors to define the general cell shape.</li>
 * <li>Cells do not need to be cubes, but opposite faces must be parallel.</li>
 * <li>Cell values need to be passed as a contiguous 3D array, but it is possible to define empty cells by setting its value to NaN or a defined nullvalue.</li>
 * </ul>
 * The cells values are expected in the IJK order, see example<br>
 * @example
 * I |------>
 *
 * A ------- B            __
 * |\        |\            \
 * | \       | \            \  J
 * |  C ------- D     _      v
 * E -|----- F  |     |
 *  \ |       \ |     | K
 *   \|        \|     |
 *    G ------- H     v
 */
export declare class VoxelGridData extends AbstractReservoirData {
    constructor(options: VoxelGridData.VolumeData);
    /**
     * Return a cell iterator for this grid structure, conveniently iterating over each cell index and providing the relevant I,J & K indices.
     * @returns the Cell iterator
     */
    getCellIJKIterator(): CellIJKIterator;
    /**
     * Return this VoxelGrid's metadata
     */
    getMetaData(): VoxelGridData.GridMetaData;
    /**
     * Returns the index for the cell based on the given i j k index
     * @returns index for this i j k cell (null if the cell doesn't exist)
     */
    getIndexForCell(i: number, j: number, k: number): number | null;
    /**
     * Return the IJK index of the cell identified by the given position in the grid, in the format [i, j, k].
     * @param index the cell index in the grid. Index start at 0, and must be inferior to the total number of cells.
     * @param targetIJK the optional array to contain the resulting i, j, k indices, to avoid new object creation.
     */
    getCellIJKbyIndex(index: number, targetIJK?: number[]): number[];
    /**
     * Return true if the given cell index match an existing cell with a valid value, false if not. Ignore user filters.<br>
     * The cell must belong in the grid ijk bounds, and must be a valid value (must be a finite number different from the user-defined nullvalue)
     * @param index the cell index to check the validity of.
     * @returns true if the cell index is valid, false if not.
     */
    isCellIndexValid(index: number): boolean;
    /**
     * Returns the number of cells in the data object. This also includes cells with NaN and nullvalues.
     * @returns number of cells
     */
    getNumberOfCells(): number;
    /**
     * Returns the ijk count for this VoxelGridData.
     */
    getIJKCount(): IJKIndex;
    /**
     * Returns the total volume measure of this grid.<br>
     * Computed by the sum of the volume of every valid cells, ignoring current user filters.<br>
     * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
     * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
     */
    getGridFullVolume(): number;
    /**
     * Dispose this grid data to allow for garbage collection.
     */
    dispose(): void;
}
export declare namespace VoxelGridData {
    type VolumeData = CellsValues & {
        /**
         * The subVolume dimensions in local coordinates, along its i, j and k axes.
         */
        volumesize: Vector3;
        /**
         * The position of the center of the subvolume.
         */
        centerposition: Vector3;
        /**
         * The rotation of the subvolume compared to standard XYZ unix axes, in degree.<br>
         * Either this rotation, or the rotation in radian need to be defined.
         */
        rotationdegree?: Euler;
        /**
         * The rotation of the subvolume compared to standard XYZ unix axes, in radian.<br>
         * Either this rotation, or the rotation in degree need to be defined.
         */
        rotationradian?: Euler;
        /**
         * The dimensions of the subgrid (in cells) in the i, j and k axes.
         */
        ijkcount: Vector3;
        /**
         * The measured depth at the start of this subvolume.
         */
        startmd: number;
        /**
         * The measured depth at the end of this subvolume.<br>
         * If not specified, this value will be automatically set to starMD + volume length.
         */
        endmd?: number;
        /**
         * The value to be used when a cell has no value, default is -999.25.
         */
        nullvalue?: number;
    };
    type GridMetaData = AbstractReservoirData.MetaData & {
        /**
         * The number of I, J and K layers this grid possess.
         */
        numijk: IJKIndex;
        /**
         * The minimum cell property value currently stored in this grid data.
         */
        cellminvalue: number;
        /**
         * The maximum cell property value currently stored in this grid data.
         */
        cellmaxvalue: number;
        /**
         * The value to be used when a cell has no value, default is -999.25.
         */
        nullvalue: number;
        /**
         * The minimum cell measured depth (MD) inside this voxel grid.
         */
        cellstartmd: number;
        /**
         * The maximum cell measured depth (MD) inside this voxel grid.
         */
        cellendmd: number;
        /**
         * The maximum radius for this sub grid, radius is measured between the central I axis and the center of cells.
         */
        gridmaxradius: number;
        /**
         * The volume origin corner, also used as a translation to improve accuracy in rendering.
         */
        origin: Vector3;
        /**
         * The length in local coordinates of the volume on its own IJK axes.
         */
        volumesize: Vector3;
        /**
         * The rotation of the volume IJK axes, compared to standard XYZ axis, in degrees.
         */
        rotationdeg: Euler;
        /**
         * The rotation of the volume IJK axes, compared to standard XYZ axis, in radians.
         */
        rotationrad: Euler;
        /**
         * The vector of the full I axis span of this volume.
         */
        volumei: Vector3;
        /**
         * The vector of the full J axis span of this volume.
         */
        volumej: Vector3;
        /**
         * The vector of the full K axis span of this volume.
         */
        volumek: Vector3;
        /**
         * The vector of a single cell size on the I axis.<br>
         * I, J and K cell vectors forms the cell parallelepiped.
         */
        celli: Vector3;
        /**
         * The vector of a single cell size on the J axis.<br>
         * I, J and K cell vectors forms the cell parallelepiped.
         */
        cellj: Vector3;
        /**
         * The vector of a single cell size on the K axis.<br>
         * I, J and K cell vectors forms the cell parallelepiped.
         */
        cellk: Vector3;
        /**
         * The volume of a single cell. All cells share an identical shape and volume.
         */
        cellvolume: number;
        /**
         * The current valid cell count, based on the currently active cell property values. NaN and nullvalue cells are
         * not considered valid and will not be rendered.
         */
        validcellcount: number;
    };
    /**
     * The structure for setting cells property values.<br>
     * Must at least contain either values or additional data.
     */
    type CellsValues = {
        /**
         * The SubVolume values. The given array must be of size i * j * k (if compressed, only the decompressed array must conform to that size).
         * Values are stored in 'i' first, then 'j' then 'k' order.
         * Usage of Float32Array is recommended for optimal memory footprint.<br>
         * See the parameter `compression` to handle how the array should be treated by this class.
         */
        values?: Float32Array | number[];
        /**
         * Additional cell properties, which can be used together with user-defined grid filter.<br>
         * Each additional property consist of a named field containing an Arraylike object (either a regular array or Typed array).<br>
         * The given arrays must be of size i * j * k (if compressed, only the decompressed array must conform to that size).
         * See the parameter `compression` to handle how the array should be treated by this class.
         */
        additionalcelldata?: Record<string, TypedArray>;
        /**
         * The compression algorithm used to compress the values array.
         */
        compression: ArrayCompression;
    };
}
