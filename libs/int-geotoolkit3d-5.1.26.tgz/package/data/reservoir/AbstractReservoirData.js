/* eslint-disable */

export {p6t as AbstractReservoirData} from '@int/impl/geotoolkit3d.js';
