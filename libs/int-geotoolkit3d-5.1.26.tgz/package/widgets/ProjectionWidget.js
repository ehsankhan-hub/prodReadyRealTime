/* eslint-disable */

export {X6t as ProjectionWidget} from '@int/impl/geotoolkit3d.js';
