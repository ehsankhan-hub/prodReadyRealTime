import { AbstractGestureTool } from '@int/geotoolkit3d/tool/AbstractGestureTool';
import { Color, Vector3 } from 'three';
import { LineSegments } from '@int/geotoolkit3d/scene/LineSegments';
import type { AbstractDeviceSupport } from '@int/geotoolkit3d/tool/devicesupport/AbstractDeviceSupport';
import type { AbstractTool } from '@int/geotoolkit3d/tool/AbstractTool';
import type { AbstractPicking } from '@int/geotoolkit3d/picking/AbstractPicking';
/**
 * Event types
 * @enum
 * @readonly
 */
export declare enum Events {
    /**
     * DistanceChanged
     * @deprecated since 4.1, use MeasuringTool.Events.PositionChanged instead
     */
    DistanceChanged = "DistanceChanged",
    /**
     * PositionChanged event.<br>
     * When this event is fired, the callback parameter "args" will contain the following fields:<ul>
     * <li>pointerposition: Vector3, The Pointer position.</li>
     * <li>anchorposition: Vector3, The Anchor position.</li>
     * <li>distance: number, The distance between the Pointer and Anchor positions.</li>
     * </ul>
     */
    PositionChanged = "PositionChanged"
}
/**
 * A tool that implements selection mechanism.<br>
 * <br>
 * This tool will perform a picking operation on click/tap using {@link @int/geotoolkit3d/picking/RendererPicking~RendererPicking}.<br>
 * Then it will notify the attached listeners about what has been picked.<br>
 * <br>
 * Note that if the picking found nothing, the listeners will be notified that nothing has been picked too.<br>
 * <br>
 * The selection tool can be configured to pick an area instead of a single pixel.<br>
 * In that case it may propagate a selection containing more than one object.<br>
 */
export declare class MeasuringTool extends AbstractGestureTool {
    constructor(options?: MeasuringTool.Options);
    on<E extends keyof MeasuringTool.EventMap>(type: E, callback: (eventType: E, sender: this, args: MeasuringTool.EventMap[E]) => void): this;
    off<E extends keyof MeasuringTool.EventMap>(type?: E, callback?: (eventType: E, sender: this, args: MeasuringTool.EventMap[E]) => void): this;
    notify<E extends keyof MeasuringTool.EventMap>(type: E, source: MeasuringTool, args?: MeasuringTool.EventMap[E]): this;
    /**
     * sets the visibility of this tool visuals (Handles and line, which are children of this object).
     * @param visible to set the visibility of the visuals.
     */
    setChildrenVisibility(visible: boolean): this;
    /**
     * Set options
     */
    setOptions(options: MeasuringTool.Options): this;
    /**
     * Set the Anchor new position. Can be set to null if desired, which will make the measure line and the Anchor visuals disappears.
     * @param position the Anchor position.
     */
    setAnchorPosition(position: Vector3 | null): this;
    /**
     * Get the Anchor position. Can return null if set/reset to null by the user.
     */
    getAnchorPosition(): Vector3 | null;
    /**
     * Set the Pointer new position. Can be set to null if desired, which will make the measure line and the Pointer visuals disappears.
     * @param position the Pointer position.
     */
    setPointerPosition(position: Vector3 | null): this;
    /**
     * Get the Pointer position. Can return null if set/reset to null by the user.
     */
    getPointerPosition(): Vector3 | null;
    /**
     * Define the handles default position, and reset the position if desired.<br>
     * If the position is set to null, the handles and line will not be visible until the MeasuringTool is operated to find new positions.
     * @param position new handles position, can be null if desired.
     * @param resetPosition if true, pointer and anchor positions will be reset.
     */
    setDefaultPosition(position: Vector3 | null, resetPosition?: boolean): this;
    /**
     * Get the default position for handles, by which the handles position are replaced when calling resetPosition().
     */
    getDefaultPosition(): Vector3 | null;
    /**
     * Reset the handles to the default position.<br>
     * If the default position was set to null, the handles will be hidden and getters for pointer, anchor and distance
     * will return null until updated by the tool operation.
     */
    resetPosition(): this;
    getOptions(): Required<Omit<MeasuringTool.Options, 'resetposition'>>;
    onCursorMove(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onTap(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Function to get the current distance of the two points from the tool.
     * @returns distance between the two points, or null if one of the two point is null.
     */
    getDistance(): number | null;
    onKeyStart(event: KeyboardEvent): void;
    onKey(event: KeyboardEvent): void;
    onKeyEnd(event: KeyboardEvent): void;
    onDoubleTap(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onMouseWheel(event: WheelEvent): void;
    onPinchStart(event: AbstractGestureTool.MovePointerEvent): void;
    onPinch(event: AbstractGestureTool.MovePointerEvent): void;
    onPinchEnd(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onDragStart(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onDrag(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onDragEnd(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onSlideStart' event has occurred
     * @param event the native event with plot coordinates added
     */
    onSlideStart(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onSlide' event has occurred
     * @param event the native event with plot coordinates added
     */
    onSlide(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onSlideEnd' event has occurred
     * @param event the native event with plot coordinates added
     */
    onSlideEnd(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onVisibilityGained' event has occurred
     * @param event the native event with plot coordinates added
     */
    onVisibilityGained(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onVisibilityLost' event has occurred
     * @param event the native event with plot coordinates added
     */
    onVisibilityLost(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Dispose measuring tool
     */
    dispose(): void;
}
export declare namespace MeasuringTool {
    /**
     * See {@link @int/geotoolkit3d/tool/AbstractGestureTool~AbstractGestureTool} for inherited options
     */
    type Options = AbstractGestureTool.Options & {
        /**
         * The status of this tool. When disabled, the MeasuringTool will not respond to mouse events.
         */
        enabled?: boolean;
        /**
         * The color of the anchor point of the ruler.
         */
        anchorcolor?: string | Color;
        /**
         * The size of the anchor point of the ruler.
         */
        anchorsize?: number;
        /**
         * The color of the pointer of the ruler.
         */
        pointercolor?: string | Color;
        /**
         * The size of the pointer of the ruler.
         */
        pointersize?: number;
        /**
         * The ruler line options.
         */
        lineoptions?: Omit<LineSegments.Options, 'data'>;
        /**
         * Picking class, that will be used for picking objects
         */
        picking?: PickingClass;
        /**
         * Define the default Anchor and Pointer positions on tool start, or after resetPosition() is called.<br>
         * Can be null. If set to null and resetPosition() is called, the MeasuringTool line and points will not be visible,
         * and methods getAnchorPosition(), getPointerPosition() will also return null.<br>
         * As long as either Anchor or Pointer are null, the line will remain hidden and getDistance() will return null.
         */
        defaultposition?: Vector3 | null;
        /**
         * The Pointer position in Business coordinates (world coordinates without the Plot Scale applied).<br>
         * Can be set to null.<br>
         * As long as either Anchor or Pointer are null, the line will remain hidden and getDistance() will return null.
         */
        pointerposition?: Vector3 | null;
        /**
         * The Anchor position in Business coordinates (world coordinates without the Plot Scale applied).<br>
         * Can be set to null.<br>
         * As long as either Anchor or Pointer are null, the line will remain hidden and getDistance() will return null.
         */
        anchorposition?: Vector3 | null;
        /**
         * True, if need to reset anchor and pointer to default position
         */
        resetposition?: boolean;
    };
    type EventMap = AbstractTool.EventMap & {
        /**
         * On distance changed.<br>
         * Contain the distance between the Anchor and Pointer position, in Business coordinates (world coordinates without the Plot Scale applied).
         * @deprecated since 4.1, please use MeasuringTool.Events.PositionChanged instead.
         */
        [Events.DistanceChanged]?: number;
        [Events.PositionChanged]?: {
            /**
             * The Anchor position in Business coordinates (world coordinates without the Plot Scale applied).<br>
             * Since the pointer is the first to be updated, the Anchor might still be null, if it was previously set to null.
             */
            anchorposition: Vector3 | null;
            /**
             * The Pointer position in Business coordinates (world coordinates without the Plot Scale applied).
             */
            pointerposition: Vector3;
            /**
             * The distance between the Anchor and Pointer position, in Business coordinates (world coordinates without the Plot Scale applied).<br>
             * If the Anchor was previously set to null and is still null, the distance will be returned as null as well.
             */
            distance: number | null;
        };
    };
}
type PickingClass = typeof AbstractPicking;
export {};
