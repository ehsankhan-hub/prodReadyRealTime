/* eslint-disable */

export {jOt as BasicPickingMaterial} from '@int/impl/geotoolkit3d.js';
