import { AbstractShaderPickingMaterial } from '@int/geotoolkit3d/picking/pickingrenderer/AbstractShaderPickingMaterial';
import type { Mesh, ShaderMaterialParameters } from 'three';
/**
 * Material used to do renderer picking on an instanced PointSet.<br>
 * @see {@link @int/geotoolkit3d/picking/pickingrenderer/BasicPickingMaterial~BasicPickingMaterial} For details about picking-material.
 * @see {@link @int/geotoolkit3d/picking/RendererPicking~RendererPicking} For details about picking-renderer.
 */
export declare class DefaultPointSetPickingMaterial extends AbstractShaderPickingMaterial {
    constructor(options: DefaultPointSetPickingMaterial.Options);
}
export declare namespace DefaultPointSetPickingMaterial {
    /**
     * The constructor options for this PointSet picking material.
     */
    type Options = ShaderMaterialParameters & {
        /**
         * The base Material to use for this custom picking material.
         */
        material: AbstractShaderPickingMaterial.PointMaterial;
        /**
         * The Three.js Point object this material is linked to.
         */
        object: Mesh;
    };
}
