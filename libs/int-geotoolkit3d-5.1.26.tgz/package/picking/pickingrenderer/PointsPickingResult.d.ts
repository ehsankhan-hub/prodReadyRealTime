import type { AbstractPicking } from '@int/geotoolkit3d/picking/AbstractPicking';
/**
 * The base picking result format for PointSet and PointCloud visuals.
 */
export type PointsPickingResult = AbstractPicking.PickingResult & {
    /**
     * The point index in the picked pointCloud.
     */
    pointindex: number;
};
