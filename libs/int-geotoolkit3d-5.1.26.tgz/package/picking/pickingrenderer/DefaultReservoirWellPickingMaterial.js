/* eslint-disable */

export {K1t as DefaultReservoirWellPickingMaterial} from '@int/impl/geotoolkit3d.js';
