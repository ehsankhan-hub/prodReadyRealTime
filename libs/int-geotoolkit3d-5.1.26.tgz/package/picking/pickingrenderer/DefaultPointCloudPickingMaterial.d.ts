import { AbstractShaderPickingMaterial } from '@int/geotoolkit3d/picking/pickingrenderer/AbstractShaderPickingMaterial';
import type { Points, Vector2 } from 'three';
/**
 * Material used to do renderer picking on a PointCloud.<br>
 * @see {@link @int/geotoolkit3d/picking/pickingrenderer/BasicPickingMaterial~BasicPickingMaterial} For details about picking-material.
 * @see {@link @int/geotoolkit3d/picking/RendererPicking~RendererPicking} For details about picking-renderer.
 */
export declare class DefaultPointCloudPickingMaterial extends AbstractShaderPickingMaterial {
    constructor(options: DefaultPointCloudPickingMaterial.Options);
    setPlotResolution(resolution: Vector2): void;
    setRenderResolution(resolution: Vector2): void;
}
export declare namespace DefaultPointCloudPickingMaterial {
    /**
     * The constructor options for this PointCloud picking material.
     */
    type Options = AbstractShaderPickingMaterial & {
        /**
         * The base Material to use for this custom picking material.
         */
        material: AbstractShaderPickingMaterial.PointMaterial;
        /**
         * The Three.js Point object this material is linked to.
         */
        object: Points;
    };
}
