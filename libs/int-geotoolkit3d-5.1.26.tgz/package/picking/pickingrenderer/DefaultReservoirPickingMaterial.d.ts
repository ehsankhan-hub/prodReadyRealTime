import { AbstractShaderPickingMaterial } from '@int/geotoolkit3d/picking/pickingrenderer/AbstractShaderPickingMaterial';
import type { InstancedBufferGeometry, Mesh, ShaderMaterialParameters } from 'three';
import type { MeshColorMapBasicMaterial } from '@int/geotoolkit3d/scene/MeshColorMapBasicMaterial';
import type { IReservoirPickingGeometry } from '@int/geotoolkit3d/picking/geometry/IReservoirPickingGeometry';
/**
 * Material used to do renderer picking on a Reservoir mesh.<br>
 * @see {@link @int/geotoolkit3d/picking/pickingrenderer/BasicPickingMaterial~BasicPickingMaterial} For details about picking-material.
 * @see {@link @int/geotoolkit3d/picking/RendererPicking~RendererPicking} For details about picking-renderer.
 */
export declare class DefaultReservoirPickingMaterial extends AbstractShaderPickingMaterial {
    constructor(options: DefaultReservoirPickingMaterial.Options);
    isDisposed(): boolean;
    dispose(): void;
}
export declare namespace DefaultReservoirPickingMaterial {
    /**
     * The constructor options for the ReservoirGrid picking material.
     */
    type Options = ShaderMaterialParameters & {
        /**
         * The material used for picking
         */
        material: MeshColorMapBasicMaterial;
        /**
         * The picked object
         */
        object: Mesh & {
            geometry: InstancedBufferGeometry & IReservoirPickingGeometry;
        };
    };
    type PickingCellData = {
        /**
         * The cell index in the picked reservoir
         */
        index: number;
        /**
         * The cell 8 corners coordinates
         */
        positions: {
            x?: number[];
            y?: number[];
            z?: number[];
        };
        /**
         * The cell value, if applicable
         */
        value?: number;
        /**
         * The cell ijk index position, if picking succeed
         */
        ijk?: IJK;
    };
    /**
     * A IJK structure which represent a value for each I,J, K axes
     */
    type IJK = {
        i: number;
        j: number;
        k: number;
    };
}
