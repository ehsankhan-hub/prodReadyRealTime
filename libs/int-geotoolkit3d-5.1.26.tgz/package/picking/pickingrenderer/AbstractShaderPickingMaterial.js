/* eslint-disable */

export {zOt as AbstractShaderPickingMaterial} from '@int/impl/geotoolkit3d.js';
