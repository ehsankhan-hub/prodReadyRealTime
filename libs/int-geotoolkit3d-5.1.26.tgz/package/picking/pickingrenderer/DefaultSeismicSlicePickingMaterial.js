/* eslint-disable */

export {z1t as DefaultSeismicSlicePickingMaterial} from '@int/impl/geotoolkit3d.js';
