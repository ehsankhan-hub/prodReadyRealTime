/* eslint-disable */

export {_Ot as DefaultSpritePickingMaterial} from '@int/impl/geotoolkit3d.js';
