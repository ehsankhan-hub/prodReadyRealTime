import { PointsMaterial } from 'three';
import { AbstractShaderPickingMaterial } from '@int/geotoolkit3d/picking/pickingrenderer/AbstractShaderPickingMaterial';
import type { BasicPickingMaterial } from '@int/geotoolkit3d/picking/pickingrenderer/BasicPickingMaterial';
/**
 * Material used to do renderer picking on a THREE.JS Points.<br>
 * Note that this implementation ignores any transparency in the points and does picking on the whole area covered by the points.<br>
 * @see {@link @int/geotoolkit3d/picking/pickingrenderer/AbstractShaderPickingMaterial~AbstractShaderPickingMaterial} For details about picking-material.
 * @see {@link @int/geotoolkit3d/picking/RendererPicking~RendererPicking} For details about picking-renderer.
 */
export declare class DefaultPointsPickingMaterial extends PointsMaterial {
    constructor(options: BasicPickingMaterial.Options);
    /**
     * Set picking options, note that this setOptions expects all mandatory parameters to be set
     * @param options The picking options
     * @throws Error if no object has been selected
     * @returns this
     */
    setOptions(options: AbstractShaderPickingMaterial.Options): this;
}
