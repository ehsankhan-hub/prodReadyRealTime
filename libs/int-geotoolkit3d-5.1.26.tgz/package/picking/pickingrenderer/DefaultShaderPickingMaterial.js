/* eslint-disable */

export {KOt as DefaultShaderPickingMaterial} from '@int/impl/geotoolkit3d.js';
