import type { Plot } from '@int/geotoolkit3d/Plot';
import type { Object3D as ThreeObject3D, Vector2, Vector3 } from 'three';
/**
 * Parent class for picking algorithms.<br>
 * Subclasses should implement 3D picking (pixel to worldcoordinate).<br>
 * Builtin implementation include raytracing and renderer-picking.<br>
 */
export declare class AbstractPicking {
    /**
     * Pick the object(s) at the given plot coordinates
     * @param plot The target plot
     * @param x The x coordinate in plot device space (in pixels)
     * @param y The y coordinate in plot device space (in pixels)
     * @param width The picking width in pixels
     * @param height The picking height in pixels
     * @param filter Optional custom filter to decide which object to exclude for picking.
     * @returns An array of jsons containing the intersecting object3d(s)
     */
    static pick(plot: Plot, x: number, y: number, width?: number, height?: number, filter?: AbstractPicking.FilterFunction): AbstractPicking.PickingResult[];
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace AbstractPicking {
    /**
     * PickingResult can be expanded by ExtraPickingModeCallback
     */
    type PickingResult = {
        /**
         * The picked object
         */
        object: ThreeObject3D;
        /**
         * The picking position in 3D world coordinates
         */
        point: Vector3;
        /**
         * The picking position on the screen/device, in pixels coordinates
         */
        pointdevice?: Vector2;
        /**
         * Plot root
         */
        root?: ThreeObject3D;
    } & Record<string, any>;
    /**
     * A function that can filter the pickable shape, takes the object to filter and it's current pickable status as parameter.
     * Note that this filtering occurs prior to picking. As a result, if an object A is hidden by an object B, object A can still be picked if a filter is set to exclude object B.
     * (see {@link @int/geotoolkit3d/picking/RendererPicking~RendererPicking filtering} documentation)
     * @param object The object the filter should decide if it can be picked or not.
     * @param pickable Define if the object to filter is currently pickable.
     * @returns True if the object can be picked, or false if the object (and its children) cannot be picked.
     */
    type FilterFunction = (object: ThreeObject3D, pickable: boolean) => boolean;
}
