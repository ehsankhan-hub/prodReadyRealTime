/**
 * Define an interface for 3D Reservoir Geometries common methods.
 * @interface
 */
export declare abstract class IReservoirPickingGeometry {
    /**
     * Return the current number of Cells being rendered by the reservoir. Used in picking to encode/decode picked cell index.
     */
    abstract getPickingCellCount(): number;
    static getClassName(): string;
    getClassName(): string;
}
