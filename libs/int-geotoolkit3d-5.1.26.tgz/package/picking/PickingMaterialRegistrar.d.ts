import type { ObjectWithMaterial } from '@int/geotoolkit3d/scene/ObjectWithMaterial';
import type { Material } from 'three';
import { ShaderMaterial } from 'three';
export declare class PickingMaterialRegistrar {
    /**
     * Register the picking material class to be used for picking for a given material.<br>
     * The picking renderer requires custom implementation of materials that write information instead of pixels.<br>
     * To customize the picking for a given object, one should implement the corresponding material and register it.<br>
     * @param materialClassName The picked material's classname to replace
     * @param pickingMaterialConstructor The picking material's constructor
     * @see {@link @int/geotoolkit3d/picking/pickingrenderer/AbstractShaderPickingMaterial~AbstractShaderPickingMaterial}
     */
    static setPickingMaterial(materialClassName: string, pickingMaterialConstructor: PickingMaterialRegistrar.MaterialClass): void;
    static getClassName(): string;
}
export declare namespace PickingMaterialRegistrar {
    /**
     * The material class to register as picking material.
     */
    type MaterialClass = {
        new (options: {
            material: ShaderMaterial;
            object: ObjectWithMaterial;
        }): Material;
    };
}
