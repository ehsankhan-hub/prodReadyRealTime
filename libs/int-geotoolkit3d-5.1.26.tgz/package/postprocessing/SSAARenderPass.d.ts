/**
 * @module geotoolkit3d/postprocessing/SSAARenderPass
 */
import type { WebGLRenderer } from 'three';
import { WebGLRenderTarget } from 'three';
import { AbstractPass } from '@int/geotoolkit3d/postprocessing/AbstractPass';
/**
 * This render pass class implements super-sampling anti-aliasing.<br>
 * This solution perform multiple render to gather multiple sample on each pixel, each sample have a slight offset.<br>
 * While this solution can produce the best result (at high sample count), it is also very costly and is not compatible
 * with DepthPeeling rendering, forbidding accurate transparency rendering.
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare class SSAARenderPass extends AbstractPass {
    constructor(options: SSAARenderPass.Options);
    setOptions(options?: SSAARenderPass.OptionsBase): this;
    setSize(width: number, height: number): this;
    render(renderer: WebGLRenderer, writeBuffer?: WebGLRenderTarget, readBuffer?: WebGLRenderTarget, deltaTime?: number, maskActive?: boolean): void;
}
export declare namespace SSAARenderPass {
    type SSAARenderOptions = {
        antialias?: AbstractPass.AntialiasOptions & {
            /**
             * Alternative sample weight calculation for SuperSampling AA:<br>
             * Each sample receive a weight by which the samples are composited together.<br>
             * But since this weight is a float, for which the max precision vary per GPU implementation,
             * the total sum of all the weight might not be exactly 1.<br>
             * By varying the sampleWeight per sample so that it is uniformly distributed across a range of values whose
             * rounding errors cancel each other out, "unbiased" weights should be closer to sum as 1.0, ensuring better color fidelity.
             */
            unbiased?: boolean;
            /**
             * The number of sample per pixels.<br>
             * More samples means higher quality AntiAliasing, but also more time rendering (and slower performances).<br>
             * Accepted values are [0, 1, 2, 3, 4, 5]. They respectively stand for 1, 2, 4, 8, 16 and 32 samples per pixels.
             * Default is 2 (4 samples).
             */
            samplelevel?: number;
        };
    };
    /**
     * The SSAARenderPass constructor options.
     */
    type Options = AbstractPass.RenderPassOptions & SSAARenderOptions;
    /**
     * The SSAARenderPass options used when calling setOptions.
     */
    type OptionsBase = Partial<AbstractPass.RenderPassOptions> & SSAARenderOptions & AbstractPass.MainRenderPassOptions;
    /**
     * The SSAARenderPass options returned when calling getOptions.
     */
    type OptionsBaseOut = Required<Omit<Options, 'clearcolor' | 'clearcoloralpha'>>;
}
