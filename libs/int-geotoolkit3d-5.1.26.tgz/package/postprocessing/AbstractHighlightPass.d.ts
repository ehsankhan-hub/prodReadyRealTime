/**
 * @module geotoolkit3d/postprocessing/AbstractHighlightPass
 */
import { AbstractPass } from '@int/geotoolkit3d/postprocessing/AbstractPass';
import type { Object3D as ThreeObject3D } from 'three';
/**
 * Base class for highlight passes
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare abstract class AbstractHighlightPass extends AbstractPass {
    protected constructor();
    /**
     * Clears highlighted objects
     */
    clearSelectedObjects(): void;
    protected getSelectedObjects(): ThreeObject3D[];
    protected removeSelectedObject(object: ThreeObject3D): void;
    /**
     * Get the objects to be highlighted, including objects that have custom highlighting behaviors
     */
    protected getObjectToHighlight(object: ThreeObject3D): ThreeObject3D[];
    /**
     * Add new objects to highlight
     * @param object objects to highlight
     */
    addSelectedObjects(object: ThreeObject3D): void;
}
