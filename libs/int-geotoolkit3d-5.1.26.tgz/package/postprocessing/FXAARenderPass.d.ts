import { ShaderPass } from '@int/geotoolkit3d/postprocessing/ShaderPass';
import type { Plot } from '@int/geotoolkit3d/Plot';
/**
 * This class implements fast approximate anti-aliasing.<br>
 * This solution is the fastest AA method (aside no AA at all).<br>
 * It works by smoothing the image when sharp contrast differences are detected.<br>
 * This can induce a slight bluriness in the image.
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare class FXAARenderPass extends ShaderPass {
    constructor();
    setOptions(options?: Plot.AdvancedRenderingOptions & ShaderPass.BaseOptions): this;
}
