/**
 * @module geotoolkit3d/postprocessing/OutlinePass
 */
import type { Texture, WebGLRenderer } from 'three';
import { Color, Vector2, WebGLRenderTarget } from 'three';
import { AbstractHighlightPass } from '@int/geotoolkit3d/postprocessing/AbstractHighlightPass';
import type { AbstractPass } from '@int/geotoolkit3d/postprocessing/AbstractPass';
/**
 * A outline pass that can be used in postprocessing.<br>
 * This pass implements a general purpose outline effect, by rendering the shape to highlight a second time and drawing its outline using shaders.
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare class OutlinePass extends AbstractHighlightPass {
    constructor(options: OutlinePass.Options);
    setOptions(options: OutlinePass.OptionsBase): this;
    setSize(width: number, height: number): this;
    render(renderer: WebGLRenderer, writeBuffer?: WebGLRenderTarget, readBuffer?: WebGLRenderTarget, deltaTime?: number, maskActive?: boolean): void;
}
export declare namespace OutlinePass {
    type OutlinePassOptions = {
        /**
         * The Highlight options
         */
        highlight?: {
            /**
             * Enable or disable the highlight effect.
             */
            enabled?: boolean;
            /**
             * The color for visible edge
             */
            visiblecolor?: Color;
            /**
             * The color for hidden edge
             */
            hiddencolor?: Color;
            /**
             * The time interval of a pulse effect
             */
            pulseperiod?: number;
            /**
             * If true, show hidden outline in area that other objects clipped the selected object
             */
            hiddenline?: boolean;
            /**
             * The edge thickness
             */
            edgethickness?: number;
            /**
             * Factor for edge strength
             */
            edgestrength?: number;
            /**
             * Factor for glow effect
             */
            edgeglow?: number;
            /**
             * Texture to use as pattern for the highlight effect.
             */
            patterntexture?: Texture;
        };
    };
    /**
     * The OutlinePass setOptions options.
     */
    type OptionsBase = Partial<AbstractPass.RenderPassOptions> & OutlinePassOptions;
    /**
     * The OutlinePass constructor Options
     */
    type Options = AbstractPass.RenderPassOptions & OptionsBase & {
        /**
         * Specific constructor highlight options.
         */
        highlight: {
            /**
             * Define the pixel resolution of the highlight detection.
             */
            resolution?: Vector2;
        };
    };
}
