/**
 * @module geotoolkit3d/postprocessing/DepthPeelingPass
 */
import type { WebGLRenderer } from 'three';
import { WebGLRenderTarget } from 'three';
import { AbstractPass } from '@int/geotoolkit3d/postprocessing/AbstractPass';
/**
 * A render pass class that can be used as the first pass in the rendering pipeline.<br>
 * This class is able to render a scene with correct transparency,
 * To be precise, depth peeling offer correct transparency at the fragment level, up to a certain number of consecutive
 * transparency on each fragment. For example, depth peeling with N passes will allow up to N transparent fragment to
 * render and blend properly on the same pixel element.<br>
 *
 * Additionally, this render pass allow Super-Resolution Anti-Aliasing.<br>
 * This antialiasing solution produce a good result for a decent performance cost.<br>
 * It works by rendering the entire image at x2 scale (both horizontally and vertically) then scale down the result
 * to fit in the desired plot view.<br>
 * The benefit of this technique is it's simplicity, and compatibility with DepthPeeling rendering.
 *
 * This render pass require WebGL2, a version check is included in the shader code below.
 * @public
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare class DepthPeelingPass extends AbstractPass {
    constructor(options: DepthPeelingPass.Options);
    /**
     * Set the DepthPeelingPass options.
     */
    setOptions(options?: DepthPeelingPass.OptionsBase): this;
    /**
     * Get the DepthPeelingPass options
     */
    getOptions(): DepthPeelingPass.OptionsBaseOut;
    /**
     * Set size for render target
     */
    setSize(width: number, height: number): this;
    /**
     * This render function will be called every time in animation loop.
     * @param renderer the WebGLRenderer
     * @param [writeBuffer] the WebGL render target to write
     * @param [readBuffer] the WebGL render target to read
     * @param [deltaTime] delta time
     * @param [maskActive] the flag for stencil buffer in renderer
     */
    render(renderer: WebGLRenderer, writeBuffer: WebGLRenderTarget, readBuffer: WebGLRenderTarget, deltaTime?: number, maskActive?: boolean): void;
}
export declare namespace DepthPeelingPass {
    type DepthPeelingPassOptions = {
        /**
         * The depth peeling renderer options.
         */
        depthpeeling?: {
            /**
             * The number of depth peeling pass (min 2), more passes means more transparent objects can overlap with correct transparency.
             */
            peelinglevel?: number;
            /**
             * Enable the depth peeling rendering for correct transparency.
             */
            enabled?: boolean;
        };
        /**
         * The antialiasing options.
         */
        antialias?: AbstractPass.AntialiasOptions;
    };
    /**
     * The DepthPeelingPass constructor options.
     */
    type Options = AbstractPass.RenderPassOptions & DepthPeelingPassOptions;
    /**
     * The DepthPeelingPass options used when calling setOptions.
     */
    type OptionsBase = Partial<AbstractPass.RenderPassOptions> & DepthPeelingPassOptions & AbstractPass.MainRenderPassOptions;
    /**
     * The DepthPeelingPass options returned when calling getOptions.
     */
    type OptionsBaseOut = Required<Omit<Options, 'clearcolor' | 'clearcoloralpha'>>;
}
