/**
 * @module geotoolkit3d/postprocessing/ShaderPass
 */
import { AbstractPass } from '@int/geotoolkit3d/postprocessing/AbstractPass';
import type { IUniform, WebGLRenderer, WebGLRenderTarget } from 'three';
import { ShaderMaterial } from 'three';
/**
 * This class uses shader program as a renderpass.<br>
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare class ShaderPass extends AbstractPass {
    constructor(options: ShaderPass.Options);
    setOptions(options?: ShaderPass.BaseOptions): this;
    setSize(width: number, height: number): this;
    render(renderer: WebGLRenderer, writeBuffer?: WebGLRenderTarget, readBuffer?: WebGLRenderTarget, deltaTime?: number, maskActive?: boolean): void;
}
export declare namespace ShaderPass {
    export type BaseOptions = {};
    /**
     * the ShaderPass options
     */
    export type Options = BaseOptions & {
        /**
         * The Shader to use for this pass.
         */
        shader: ShaderMaterial | Shader;
    };
    type Shader = {
        uniforms?: Record<string, IUniform>;
        defines?: Record<string, any>;
        vertexShader: string;
        fragmentShader: string;
    };
    export {};
}
