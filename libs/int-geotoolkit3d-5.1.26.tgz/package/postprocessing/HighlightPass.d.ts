/**
 * @module geotoolkit3d/postprocessing/HighlightPass
 */
import { AbstractHighlightPass } from '@int/geotoolkit3d/postprocessing/AbstractHighlightPass';
import type { Object3D as ThreeObject3D, WebGLRenderer, WebGLRenderTarget } from 'three';
/**
 * Implementation of highlight meshes with edges. Mainly used for Surfaces.
 * @deprecated since 4.1, this class is not meant to be public.
 */
export declare class HighlightPass extends AbstractHighlightPass {
    constructor(options?: HighlightPass.Options);
    /**
     * Set options
     */
    setOptions(options?: HighlightPass.Options): this;
    /**
     * Get options
     */
    getOptions(): Required<HighlightPass.Options>;
    /**
     * Clears highlighted objects
     */
    clearSelectedObjects(): void;
    /**
     * Add new objects to highlight
     * @param object object to highlight
     */
    addSelectedObjects(object: ThreeObject3D): void;
    render(renderer: WebGLRenderer, writeBuffer?: WebGLRenderTarget, readBuffer?: WebGLRenderTarget, deltaTime?: number, maskActive?: boolean): void;
    setSize(width: number, height: number): this;
}
export declare namespace HighlightPass {
    type Options = {
        /**
         * The highlight options
         */
        highlight?: {
            /**
             * Enable or disable the highlight pass.
             */
            enabled?: boolean;
        };
    };
}
