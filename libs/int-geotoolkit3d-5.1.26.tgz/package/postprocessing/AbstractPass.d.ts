/**
 * @module geotoolkit3d/postprocessing/AbstractPass
 */
import type { AnyRecord } from '@int/geotoolkit/base';
import type { ColorRepresentation, OrthographicCamera, PerspectiveCamera, Scene, TextureDataType, WebGLRenderer, WebGLRenderTarget } from 'three';
import type { AntiAliasing } from '@int/geotoolkit3d/Constants';
/**
 * Abstract rendering pass class using the THREE.js Pass interface, from
 * https://github.com/mrdoob/three.js/blob/dev/examples/jsm/postprocessing/Pass.js
 * The passes added to the Plot must inherit from this class.<br>
 * Check out three.js examples for more information at https://github.com/mrdoob/three.js/blob/dev/examples/jsm/postprocessing/
 */
export declare abstract class AbstractPass {
    protected constructor();
    /**
     * Set size for render target
     * @param width the width of render target
     * @param height the height of render target
     */
    abstract setSize(width: number, height: number): this;
    /**
     * Dispose resources in this pass
     */
    dispose(): void;
    /**
     * Return whether this pass has been disposed or not.
     */
    isDisposed(): boolean;
    /**
     * This render function will be called every time in animation loop
     * @param renderer the webGLrender
     * @param [writeBuffer] the WebGL render target to write
     * @param [readBuffer] the WebGL render target to read
     * @param [deltaTime] delta time
     * @param [maskActive] the flag for stencil buffer in renderer
     */
    abstract render(renderer: WebGLRenderer, writeBuffer?: WebGLRenderTarget, readBuffer?: WebGLRenderTarget, deltaTime?: number, maskActive?: boolean): void;
    setOptions(options?: AnyRecord): this;
    /**
     * Get the type of the class
     * @deprecated since 4.1. Use getClassName() instead.
     */
    getType(): string;
    /**
     * Return true if this pass is enabled.
     */
    isEnabled(): boolean;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace AbstractPass {
    /**
     * The base options used in main render passes.
     * @deprecated since 4.1
     */
    type BaseRenderPassOptions = {
        /**
         * The base color used as background in the 3D Plot.
         * @deprecated since 4.1. Please use the Plot option 'option.renderer.clearcolor' instead.
         */
        clearcolor?: ColorRepresentation;
        /**
         * The base color opacity used as background in the 3D Plot.
         * Transparent background color can be used to overlay the Plot over some visuals.
         * @deprecated since 4.1. Please use the Plot option 'option.renderer.clearcoloralpha' instead.
         */
        clearcoloralpha?: number;
    };
    /**
     * The options used in main render passes constructor.
     */
    type RenderPassOptions = BaseRenderPassOptions & {
        /**
         * scene.
         */
        scene: Scene;
        /**
         * camera.
         */
        camera: OrthographicCamera | PerspectiveCamera;
    };
    /**
     * The base options for RenderPasses supporting forms of Anti-Aliasing.
     */
    type AntialiasOptions = {
        /**
         * Enable anti-aliasing.
         */
        enabled?: boolean;
        /**
         * Choose the antialiasing mode, among FXAA, SSAA, SRAA, or AUTO
         * Default value is AUTO.<br>
         */
        mode?: AntiAliasing;
        /**
         * The number of samples per pixel for SSAA or MSAA.
         * More samples means higher quality AntiAliasing, but also more time rendering (and slower performances).<br>
         * For SSAA, accepted values are [0, 1, 2, 3, 4, 5]. They respectively stand for 1, 2, 4, 8, 16 and 32 samples per pixels.
         * For MSAA, accepted values are [0, 2, 4]. They represent 2 and 4 samples per pixel.
         * The default value is 2.
         */
        samplelevel?: number;
    };
    /**
     * Options common to main render passes (e.g. DepthPeeling pass, SSAA render pass).
     */
    type MainRenderPassOptions = {
        /**
         * The framebuffer texture format, used in the WebGLRenderTarget. Affects the rendering color precision.
         * To be able to use advanced post processing like three.js ToneMapping, it is required to use half-float precision at least.
         */
        framebuffertexturetype?: TextureDataType;
    };
}
