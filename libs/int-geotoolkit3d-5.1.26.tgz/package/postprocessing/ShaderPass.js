/* eslint-disable */

export {nUt as ShaderPass} from '@int/impl/geotoolkit3d.js';
