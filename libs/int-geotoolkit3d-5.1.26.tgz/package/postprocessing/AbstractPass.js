/* eslint-disable */

export {lPt as AbstractPass} from '@int/impl/geotoolkit3d.js';
