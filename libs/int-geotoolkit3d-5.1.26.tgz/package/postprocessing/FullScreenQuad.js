/* eslint-disable */

export {aPt as FullScreenQuad} from '@int/impl/geotoolkit3d.js';
