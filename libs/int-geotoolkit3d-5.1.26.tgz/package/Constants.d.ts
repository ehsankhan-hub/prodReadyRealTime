/**
 * @module geotoolkit3d/Constants
 */
/**
 * Seismic display mode enum.<br>
 * <br>
 * This enum is used to determine how to transform Index coordinates when rendering Seismic related objects.<br>
 * @readonly
 * @enum
 */
export declare enum SeismicModes {
    /**
     * Display mode for Inline-crossline, ij, index.
     */
    ij = "IJ",
    /**
     * Display mode for Inline-crossline, ij, index with the I coordinate flipped
     */
    ijflipped = "IJFLIPPED",
    /**
     * Display mode for XY
     */
    xy = "XY"
}
/**
 * Enum for the different interpretation modes of the heightmap texture colors.
 * @enum
 * @readonly
 */
export declare enum HeightMapElevationValueMode {
    /**
     * Black and white value mode:<br>
     * the texture has only grayscale colors, black - 0.0, white - 1.0
     */
    BlackAndWhite = 0,
    /**
     * Terrarium value mode:<br>
     * the texture colors are in the Terrarium format (see https://www.mapzen.com/blog/elevation/ File formats section)<br>
     * (Decoding RGB colors as (red * 256 + green + blue / 256) - 32768  (in meters, projection EPSG:3857).
     */
    Terrarium = 1,
    /**
     * Normal value mode:<br>
     * color on canvas depends on alpha-channel (see https://www.mapzen.com/blog/elevation/ File formats section)
     */
    Normal = 2
}
/**
 * Enum for the different interpretation modes of the heightmap texture colors.
 * @deprecated since 4.1, please use HeightMapElevationValueMode instead.
 * @enum
 * @readonly
 */
export declare enum HeightMapColorBarValueMode {
    /**
     * Black and white value mode:<br>
     * the texture has only grayscale colors, black - 0.0, white - 1.0
     */
    BlackAndWhite = 0,
    /**
     * Terrarium value mode:<br>
     * the texture colors are in the Terrarium format (see https://www.mapzen.com/blog/elevation/ File formats section)<br>
     * (Decoding RGB colors as (red * 256 + green + blue / 256) - 32768  (in meters, projection EPSG:3857).
     */
    Terrarium = 1,
    /**
     * Normal value mode:<br>
     * color on canvas depends on alpha-channel (see https://www.mapzen.com/blog/elevation/ File formats section)
     */
    Normal = 2
}
/**
 * Builtin picking modes.<br>
 * <br>
 * This is used to tell the GPU which picking phase is currently occurring.<br>
 * It will be use din the picking shaders to choose which information to encode in the picked pixel.<br>
 * @readonly
 * @enum
 */
export declare enum PickingModes {
    /**
     * ID mode, shader will encode the shape unique id.
     */
    Id = 0,
    /**
     * X mode, shader will encode the picked point x coordinate.
     */
    X = 10,
    /**
     * ID mode, shader will encode the picked point y coordinate.
     */
    Y = 20,
    /**
     * ID mode, shader will encode the picked point z coordinate.
     */
    Z = 30
}
/**
 * Grid axis anchor
 * @readonly
 * @enum
 */
export declare enum Anchor {
    start = "start",
    end = "end"
}
/**
 * Anti-aliasing mode
 * <br>
 * Anti-aliasing (AA) is a technique to eliminate jaggies (pixelated edges) that appear in 3D plot.
 * Each AA technique has different visual result and consumes different resources.<br>
 * Pixel scale (determined by monitor resolution) affects the AA quality.
 * The default AA for retina and 2K (2560x1440) and above monitor is fast approximate AA (FXAA), and super-resolution AA (SRAA) for lower resolution.
 * @readonly
 * @enum
 */
export declare enum AntiAliasing {
    /**
     * Super-Sampling Anti-Aliasing.<br>
     * This solution perform multiple render to gather multiple sample on each pixel, each sample have a slight offset.<br>
     * While this solution can produce the best result (at high sample count), it is also very costly and is not compatible
     * with DepthPeeling rendering, forbidding accurate transparency rendering.
     */
    SSAA = "ssaa",
    /**
     * Fast Approximate Anti-Aliasing.<br>
     * This solution is the fastest AA method (aside no AA at all).<br>
     * It works by smoothing the image when sharp contrast differences are detected.<br>
     * This can induce a slight blurriness in the image.
     */
    FXAA = "fxaa",
    /**
     * Super-Resolution Anti-Aliasing.<br>
     * This solution produce a good result for a decent performance cost.<br>
     * It works by rendering the entire image at x2 scale (both horizontally and vertically) then scale down the result
     * to fit in the desired plot view.<br>
     * The benefit of this technique is it's simplicity, and compatibility with DepthPeeling rendering, which provide accurate transparency rendering.
     */
    SRAA = "sraa",
    /**
     * Multi-Sample Anti-Aliasing. <br>
     * This solution is similar to SSAA but only targets on polygon edges. <br>
     * It runs faster than the SSAA, and it is compatible with depth peeling. However, when it comes to complex scenes with a large number of triangles,
     * there will be a drop in performance. <br>
     */
    MSAA = "msaa",
    /**
     * Default option, if set to this mode, the plot will decide of the best AA technique for the current situation,
     * taking into account the plot view size, pixel scale, and if the device is a mobile device.<br>
     * The main principle is that mobile devices and larger plot view will default to a lower performance cost AA technique.
     */
    AUTO = "auto",
    /**
     * Disable any form of anti aliasing.<br>
     * This can be desired if the most performance is required and/or if no AA technique is deemed satisfactory.
     */
    OFF = "off"
}
/**
 * Highlight mode for objects made of multiple panels, such as Seismic Fences and PlaneCurtains.<br>
 * @enum
 */
export declare enum MultiPanelHighlightMode {
    /**
     * SinglePanel mode highlights only one selected panel
     */
    SinglePanel = "singlepanel",
    /**
     * AllPanels mode highlights all panels included in the object.
     */
    AllPanels = "allpanels"
}
