/* eslint-disable */

export {i8t as ExpandedAnnotationLayout} from '@int/impl/geotoolkit3d.js';
