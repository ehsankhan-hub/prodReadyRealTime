/* eslint-disable */

export {s8t as DefaultAnnotationLayout} from '@int/impl/geotoolkit3d.js';
