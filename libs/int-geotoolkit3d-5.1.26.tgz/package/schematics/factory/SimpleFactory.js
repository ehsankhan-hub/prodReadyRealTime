/* eslint-disable */

export {n8t as SimpleFactory} from '@int/impl/geotoolkit3d.js';
