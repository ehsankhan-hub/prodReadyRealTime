/* eslint-disable */

export {Nzt as XYCoordinates} from '@int/impl/geotoolkit3d.js';
