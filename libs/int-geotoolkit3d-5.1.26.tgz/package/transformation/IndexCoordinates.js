/* eslint-disable */

export {FJt as IndexCoordinates} from '@int/impl/geotoolkit3d.js';
