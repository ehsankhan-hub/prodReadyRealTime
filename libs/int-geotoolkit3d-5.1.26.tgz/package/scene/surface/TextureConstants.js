/* eslint-disable */

export {$Wt as TextureType, tXt as TextureCoordinateMode} from '@int/impl/geotoolkit3d.js';
