/**
 * @module geotoolkit3d/scene/surface/SurfaceConstants
 */
/**
 * Define the Surface highlight effect mode when the object is selected.
 * @enum
 * @readonly
 */
export declare enum HighlightMode {
    /**
     * Perform a post-process "halo" effect around the Surface visual. The halo will appear on the limits of the objects
     * as perceived on screen. This halo might not always follow the actual surface edges based on camera orientation.
     */
    HaloHighlight = "HaloHighlight",
    /**
     * Generate a Line visual that borders the limits of the Surface mesh, effectively highlighting the actual physical
     * edges of the surface, as opposed to the on-screen perceived limits of the surface from the halo effect.
     */
    ContourHighlight = "ContourHighlight"
}
