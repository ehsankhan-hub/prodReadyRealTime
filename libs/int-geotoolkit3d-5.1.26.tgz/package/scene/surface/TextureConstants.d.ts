/**
 * @module geotoolkit3d/scene/surface/TextureConstants
 */
/**
 * The texture type to use in a Surface.
 * @enum
 * @readonly
 */
export declare enum TextureType {
    /**
     * Will be used for diffuse color.
     */
    MaterialType = "MaterialType",
    /**
     * Will be used for heightmap displacement and values.
     */
    GeometryType = "GeometryType"
}
/**
 * The texture coordinate mapping types.<br>
 * Define if the Texture offset and rotation should be relative to the Surface's own offset and rotation, or should be 'absolute'.
 * @enum
 * @readonly
 */
export declare enum TextureCoordinateMode {
    /**
     * The texture size, offset and rotation will be relative to the surface transformation.<br>
     * If the Surface and texture have the same dimensions, it is recommended to use this mode.<br>
     * The surface transformation WILL affect the texture mapping.<br>
     * (ex: rotating/translating the surface will rotate/translate the texture as well, they will move together)
     */
    SurfaceRelative = "SurfaceRelative",
    /**
     * The texture size, offset and rotation will be relative to the scene origin.<br>
     * This mode is recommended if the texture need specific coordinate mapping.<br>
     * The surface transformation WILL NOT affect the texture mapping.<br>
     * (ex: rotating/translating the surface will not affect the texture world position and orientation)
     */
    OriginRelative = "OriginRelative"
}
