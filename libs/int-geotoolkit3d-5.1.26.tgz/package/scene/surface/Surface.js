/* eslint-disable */

export {yXt as Surface, BXt as PropertyTypes} from '@int/impl/geotoolkit3d.js';
