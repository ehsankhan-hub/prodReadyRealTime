/* eslint-disable */

export {m2t as Fault} from '@int/impl/geotoolkit3d.js';
