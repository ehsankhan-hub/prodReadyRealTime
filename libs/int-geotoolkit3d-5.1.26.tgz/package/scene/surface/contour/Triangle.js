/* eslint-disable */

export {eXt as Triangle} from '@int/impl/geotoolkit3d.js';
