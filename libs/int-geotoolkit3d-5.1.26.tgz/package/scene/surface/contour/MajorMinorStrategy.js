/* eslint-disable */

export {v2t as MajorMinorStrategy} from '@int/impl/geotoolkit3d.js';
