/**
 * @module geotoolkit3d/scene/surface/AbstractSurface
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { MeshColorMapLambertMaterial } from '@int/geotoolkit3d/scene/MeshColorMapLambertMaterial';
import type { AbstractSurfaceData } from '@int/geotoolkit3d/data/surface/AbstractSurfaceData';
import type { Texture, Vector2 } from 'three';
import type { TextureCoordinateMode } from '@int/geotoolkit3d/scene/surface/TextureConstants';
/**
 * Base class for geotoolkit3d.scene.surface <br>
 */
export declare abstract class AbstractSurface extends Object3D {
    protected constructor(options: Object3D.Options);
}
export declare namespace AbstractSurface {
    export namespace Geometry {
        type Options = {
            /**
             * The data constructor options
             */
            data: Data & {
                /**
                 * The surface geometry coordinates
                 */
                surface: AbstractSurfaceData;
            };
        };
        type DataOut = {
            /**
             * Surface attribute values, if available
             */
            values?: Float32Array;
        };
        type Data = {
            /**
             * The Surface attribute values.
             * Texture as value map is only supported for HeightMap.
             */
            values?: Float32Array | number[] | Texture;
        };
    }
    export namespace Material {
        type Options = Shader.Options & MeshColorMapLambertMaterial.Options;
        type OptionsBase = Shader.Options & MeshColorMapLambertMaterial.OptionsBase;
        type OptionsBaseOut = Shader.OptionsOut & MeshColorMapLambertMaterial.OptionsBaseOut;
    }
    export namespace Shader {
        type Options = Partial<CommonShaderOptions> & {
            data?: {
                /**
                 * The surface nullvalue. Default is -999.25
                 */
                nullvalue?: number;
            };
        };
        type OptionsOut = CommonShaderOptions & {
            data: {
                /**
                 * The surface nullvalue. Default is -999.25
                 */
                nullvalue: number;
            };
        };
    }
    type CommonShaderOptions = {
        /**
         * If this surface should render in wireframe mode. Default is false.
         */
        wireframe: boolean;
        /**
         * How smooth the shading of the surface should be.
         * On a scale of 1 to 0, 1 being 100% smooth, 0 being flat-shaded.
         * Using 1 for 100% smooth shading might be faster on very large surfaces, due to using precomputed normals exclusively.
         * Default is 1.
         */
        smoothshadingfactor: number;
        /**
         * True to use offset preventing Z-fighting/occlusion when overlaying other objects.<br>
         * Default is false.
         */
        polygonoffset: boolean;
        /**
         * Factor for polygon offset, > 0 will make surface closer to camera, < 0 will make it farther.<br>
         * Default is 1.
         */
        polygonoffsetfactor: number;
        /**
         * Set false to disable the lighting and shading effect of the surface.<br>
         * Default is true.
         */
        enableshading: boolean;
    };
    export type TextureOptionsOut = {
        /**
         * The diffuse color texture, to paint on the surface.<br>
         * Will be undefined if not previously defined.
         */
        texture?: Texture;
        /**
         * Transformation options to use on the diffuse color texture.<br>
         * (No effect if option.texture has not been set yet)
         */
        textureoptions: Required<TextureOptions>;
    };
    export type TextureOptionsIn = {
        /**
         * The diffuse color texture, to paint on the surface.<br>
         * Only supported by Heightmap surface and GridSurface.
         */
        texture?: Texture;
        /**
         * Transformation options to use on the diffuse color texture.<br>
         * (No effect if option.texture has not been set yet)
         */
        textureoptions?: TextureOptions;
    };
    /**
     * Texture options for the surface.<br>
     * Only supported by Heightmap surface and GridSurface.
     */
    export type TextureOptions = {
        /**
         * Enable or disable (show or hide) the texture, for convenience.
         */
        enable?: boolean;
        /**
         * The texture opacity, default is 1.0 (opaque)
         */
        opacity?: number;
        /**
         * The texture rotation around the origin point, in radian.<br>
         * Default value is 0.
         */
        rotation?: number;
        /**
         * The position of the Texture origin (the bottom left corner of the image, assuming X increase on the right and Y increase upward).<br>
         * Default value is Vector2(0, 0)
         */
        offset?: Vector2;
        /**
         * The position of the Texture origin (the bottom left corner of the image, assuming X increase on the right and Y increase upward).<br>
         * Default is set to the local size of the Surface (ex: surface.boundingBox.size()), meaning the texture will cover the entire Surface boundaries.
         */
        size?: Vector2;
        /**
         * Scale the texture X/Y axis using scalar values. Will multiply with the texture size.<br>
         * Conveniently allow to modify the texture scale when computing the size is too complex (ex: using Patterns).<br>
         * Default value is Vector2(1, 1)
         */
        scale?: Vector2;
        /**
         * Mirror the texture on its own horizontal axis (U axis in UV mapping terms).
         */
        fliphorizontal?: boolean;
        /**
         * Mirror the texture on its own vertical axis (V axis in UV mapping terms).
         */
        flipvertical?: boolean;
        /**
         * The texture coordinate mapping type.<br>
         * Determine how the texture size, offset and rotation are interpreted.<br>
         * Default is TextureCoordinateMode.Local
         */
        coordinatemode?: TextureCoordinateMode;
        /**
         * If enabled, the textured area will be limited to the texture size.<br>
         * By default is true (to allow OpenGL texture repeating outside of range, this need to be set to false)
         */
        clipoutofrange?: boolean;
    };
    export {};
}
