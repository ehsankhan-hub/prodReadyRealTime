/* eslint-disable */

export {_Wt as AbstractSurface} from '@int/impl/geotoolkit3d.js';
