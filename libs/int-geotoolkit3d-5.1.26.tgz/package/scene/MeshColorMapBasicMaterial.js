/* eslint-disable */

export {aHt as MeshColorMapBasicMaterial} from '@int/impl/geotoolkit3d.js';
