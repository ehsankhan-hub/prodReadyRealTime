/**
 * @enum
 * This enum defines the cause of the current limitation in visual capabilities.
 */
export declare enum Limitation {
    /**
     * This visual capability is limited by the specified RAM memory.
     */
    RAM = "ram",
    /**
     * This visual capability is limited by the specified VRAM (video) memory.
     */
    VRAM = "vram",
    /**
     * This visual capability is limited by the current implementation of the visual, coupled with this browser maximum ArrayBuffer size allocation.<br>
     * Maximum JS ArrayBuffer size can depend between devices and browsers, but also depend on available memory at the moment of testing.<br>
     * This maximum ArrayBuffer size is tested the first time the user ask for a visual capabilities, and should make sure that enough memory is available for a correct measurement.
     */
    IMPLEMENTATION = "implementation"
}
