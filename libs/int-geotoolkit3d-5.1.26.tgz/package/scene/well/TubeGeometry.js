/* eslint-disable */

export {B5t as TubeGeometry} from '@int/impl/geotoolkit3d.js';
