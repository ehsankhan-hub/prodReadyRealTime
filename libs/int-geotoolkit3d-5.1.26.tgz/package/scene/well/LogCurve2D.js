/* eslint-disable */

export {i4t as LogCurve2D} from '@int/impl/geotoolkit3d.js';
