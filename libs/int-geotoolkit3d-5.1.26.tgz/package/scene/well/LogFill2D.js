/* eslint-disable */

export {J5t as LogFill2D} from '@int/impl/geotoolkit3d.js';
