import { BufferGeometry } from 'three';
/**
 * Base class for Well object's geometry.
 */
export declare abstract class AbstractWellGeometry extends BufferGeometry {
    protected constructor();
    /**
     * Compute geometry expanded local bounding box.<br>
     */
    computeBoundingBox(): void;
    /**
     * Compute geometry expanded local bounding sphere.<br>
     */
    computeBoundingSphere(): void;
    static getClassName(): string;
    getClassName(): string;
}
