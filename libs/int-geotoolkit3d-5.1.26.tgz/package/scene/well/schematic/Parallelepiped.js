/* eslint-disable */

export {v4t as Parallelepiped} from '@int/impl/geotoolkit3d.js';
