/**
 * @module geotoolkit3d/scene/well/schematic/Cube
 */
import { SchematicBase } from '@int/geotoolkit3d/scene/well/schematic/SchematicBase';
import { BoxGeometry } from 'three';
/**
 * Creates a cube three.js.
 */
export declare class Cube extends SchematicBase {
    constructor(options: Cube.OptionsBase);
    /**
     * Set this Schematic Cube options.
     */
    setOptions(options?: Partial<Cube.OptionsBase>): this;
    /**
     * Get this Schematic Cube options, font, color, etc...
     */
    getOptions(): Cube.OptionsBaseOut;
    getGeometry(): BoxGeometry;
}
export declare namespace Cube {
    /**
     * The options
     */
    type Options = {
        /**
         * 2 points required, the first one is the localisation and the second provide the direction to tend to.
         */
        data: {
            /**
             * The x deviation values
             */
            x: number[];
            /**
             * The y deviation values
             */
            y: number[];
            /**
             * The elevation values
             */
            z: number[];
        };
        /**
         * Size of the cube in model space.<br>
         * Default is 50.
         */
        width?: number;
        /**
         * Number of segmented faces along the width of the sides.<br>
         * Default is 1.
         */
        widthsegments?: number;
    };
    type OptionsBase = Options & SchematicBase.OptionsBase;
    type OptionsBaseOut = Required<Options> & SchematicBase.OptionsBaseOut;
}
