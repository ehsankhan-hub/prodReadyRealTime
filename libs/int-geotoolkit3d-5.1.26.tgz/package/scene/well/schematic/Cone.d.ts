/**
 * @module geotoolkit3d/scene/well/schematic/Cone
 */
import { SchematicBase } from '@int/geotoolkit3d/scene/well/schematic/SchematicBase';
import { CylinderGeometry } from 'three';
/**
 * Creates a cone three.js.
 */
export declare class Cone extends SchematicBase {
    constructor(options: Cone.OptionsBase);
    /**
     * Set this Schematic Cone options.
     */
    setOptions(options?: Partial<Cone.OptionsBase>): this;
    /**
     * Get this Schematic Cone options, font, color, etc...
     */
    getOptions(): Cone.OptionsBaseOut;
    getGeometry(): CylinderGeometry;
}
export declare namespace Cone {
    /**
     * The options
     */
    type Options = {
        /**
         * 2 points required; the first one is the localisation and the second provide the direction to tend to.
         */
        data: {
            /**
             * The x deviation values
             */
            x: number[];
            /**
             * The y deviation values
             */
            y: number[];
            /**
             * The elevation values
             */
            z: number[];
        };
        /**
         * Radius of the cylinder at the top.<br>
         * Default is 0.
         */
        radiustop?: number;
        /**
         * Radius of the cylinder at the bottom.<br>
         * Default is 50.
         */
        radiusbottom?: number;
        /**
         * Height of the cylinder.<br>
         * Default is 50
         */
        height?: number;
        /**
         * Number of segmented faces around the circumference of the cylinder.<br>
         * Default is 28.
         */
        radiussegments?: number;
        /**
         * Number of rows of faces along the height of the cylinder.<br>
         * Default is 1.
         */
        heightsegments?: number;
        /**
         * A Boolean indicating whether the ends of the cylinder are open or capped.<br>
         * Default is false.
         */
        openended?: boolean;
    };
    type OptionsBase = Options & SchematicBase.OptionsBase;
    type OptionsBaseOut = Required<Options> & SchematicBase.OptionsBaseOut;
}
