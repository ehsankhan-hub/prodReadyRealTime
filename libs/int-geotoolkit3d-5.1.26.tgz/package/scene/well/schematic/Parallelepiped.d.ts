/**
 * @module geotoolkit3d/scene/well/schematic/Parallelepiped
 */
import { SchematicBase } from '@int/geotoolkit3d/scene/well/schematic/SchematicBase';
import { BoxGeometry } from 'three';
import { TubeGeometry } from '@int/geotoolkit3d/scene/well/TubeGeometry';
/**
 * A 3D parallelepiped schematic object.
 */
export declare class Parallelepiped extends SchematicBase {
    constructor(options: Parallelepiped.OptionsBase);
    /**
     * Set this Schematic Parallelepiped options.
     */
    setOptions(options?: Partial<Parallelepiped.OptionsBase>): this;
    /**
     * Get this Schematic Parallelepiped options, font, color, etc...
     */
    getOptions(): Parallelepiped.OptionsBaseOut;
    getGeometry(): TubeGeometry | BoxGeometry;
}
export declare namespace Parallelepiped {
    /**
     * The options
     */
    type Options = {
        /**
         * 2 points minimum required; if 2 points are provided the first one is the localisation
         * and the second provide the direction to tend to. If more than 2 points are provided then the points are actual
         * trajectory points around which a 4 side tube will be created.
         */
        data: {
            /**
             * The x deviation values
             */
            x: number[];
            /**
             * The y deviation values
             */
            y: number[];
            /**
             * The elevation values
             */
            z: number[];
        };
        /**
         * The width of the parallelepiped in modelspace (x axis).<br>
         * Default is 50.
         */
        width?: number;
        /**
         * The height of the parallelepiped in modelspace (y axis).<br>
         * Default is 50.
         */
        height?: number;
        /**
         * The length of the parallelepiped in modelspace (used if there is only 2 points in the given path) (z axis).
         */
        depth?: number;
        /**
         * Number of segmented faces along the width of the sides.<br>
         * Default is 1.
         */
        widthsegments?: number;
        /**
         * Number of segmented faces along the height of the sides.<br>
         * Default is 1.
         */
        heightsegments?: number;
        /**
         * Number of segmented faces along the depth of the sides.<br>
         * Default is 1.
         */
        depthsegments?: number;
    };
    type OptionsBase = Options & SchematicBase.OptionsBase;
    type OptionsBaseOut = Required<Options> & SchematicBase.OptionsBaseOut;
}
