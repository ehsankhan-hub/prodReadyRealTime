/* eslint-disable */

export {b4t as SchematicBase} from '@int/impl/geotoolkit3d.js';
