/* eslint-disable */

export {M4t as Cube} from '@int/impl/geotoolkit3d.js';
