/**
 * @module geotoolkit3d/scene/well/schematic/Sphere
 */
import { SchematicBase } from '@int/geotoolkit3d/scene/well/schematic/SchematicBase';
import { SphereGeometry } from 'three';
/**
 * Creates a Sphere three.js.
 */
export declare class Sphere extends SchematicBase {
    constructor(options: Sphere.OptionsBase);
    /**
     * Set this Schematic Sphere options.
     */
    setOptions(options?: Partial<Sphere.OptionsBase>): this;
    /**
     * Get this Schematic Sphere options, font, color, etc...
     */
    getOptions(): Sphere.OptionsBaseOut;
    getGeometry(): SphereGeometry;
}
export declare namespace Sphere {
    /**
     * The options
     */
    type Options = {
        /**
         * 2 points required; the first one is the localisation and the second provide the direction to tend to.
         */
        data: {
            /**
             * The x deviation values
             */
            x: number[];
            /**
             * The y deviation values
             */
            y: number[];
            /**
             * The elevation values
             */
            z: number[];
        } | {
            /**
             * The x deviation values
             */
            x: number;
            /**
             * The y deviation values
             */
            y: number;
            /**
             * The elevation values
             */
            z: number;
        };
        /**
         * The sphere radius<br>
         * Default is 50.
         */
        radius?: number;
        /**
         * The number of horizontal segments. Minimum value is 3.<br>
         * Default is 28.
         */
        widthsegments?: number;
        /**
         * The number of vertical segments. Minimum value is 2.<br>
         * Default is 14.
         */
        heightsegments?: number;
        /**
         * The specify horizontal starting angle.<br>
         * Default is 0.
         */
        phistart?: number;
        /**
         * The specify horizontal sweep angle size.<br>
         * Default is PI * 2.
         */
        philength?: number;
        /**
         * The specify vertical starting angle.<br>
         * Default is 0.
         */
        thetastart?: number;
        /**
         * The specify vertical sweep angle size.<br>
         * Default is PI.
         */
        thetalength?: number;
    };
    type OptionsBase = Options & SchematicBase.OptionsBase;
    type OptionsBaseOut = Required<Options> & SchematicBase.OptionsBaseOut;
}
