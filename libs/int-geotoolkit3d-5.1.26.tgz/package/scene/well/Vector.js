/* eslint-disable */

export {y5t as Vector} from '@int/impl/geotoolkit3d.js';
