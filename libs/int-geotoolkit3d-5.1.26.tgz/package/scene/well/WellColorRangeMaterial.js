/* eslint-disable */

export {A5t as WellColorRangeMaterial} from '@int/impl/geotoolkit3d.js';
