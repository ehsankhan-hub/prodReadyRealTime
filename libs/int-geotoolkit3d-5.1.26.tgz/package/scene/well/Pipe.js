/* eslint-disable */

export {V5t as Pipe} from '@int/impl/geotoolkit3d.js';
