import { MeshColorMapLambertMaterial } from '@int/geotoolkit3d/scene/MeshColorMapLambertMaterial';
import type { ColorMapShaderMaterial } from '@int/geotoolkit3d/scene/ColorMapShaderMaterial';
import { Range } from '@int/geotoolkit/util/Range';
/**
 * Base material for wells, that supports differents color layers depending depths ranges
 */
export declare class WellColorRangeMaterial extends MeshColorMapLambertMaterial {
    constructor(options: WellColorRangeMaterial.Options);
    setOptions(options?: WellColorRangeMaterial.Options): this;
    getOptions(): WellColorRangeMaterial.OptionsOut;
}
export declare namespace WellColorRangeMaterial {
    /**
     * Color layers information colorprovider to specified depths range
     */
    type ColorRanges = ColorMapShaderMaterial.MultiColorMap.ColorMapsBaseType & {
        /**
         * Depths range, that should be colored using specified colorprovider
         */
        range?: Range;
    };
    type Options = MeshColorMapLambertMaterial.Options & ColorRangeOptions;
    type OptionsOut = MeshColorMapLambertMaterial.OptionsBaseOut & ColorRangeOptions;
    type ColorRangeOptions = {
        /**
         * Color layers to paint tube parts in different colors
         */
        colorlayers?: ColorRanges[];
    };
}
