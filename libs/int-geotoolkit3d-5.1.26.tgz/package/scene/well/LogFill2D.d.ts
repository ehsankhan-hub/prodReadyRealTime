/**
 * @module geotoolkit3d/scene/well/LogFill2D
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { OffsetMode } from '@int/geotoolkit3d/util/well/Well';
import type { Color } from 'three';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
/**
 * A log fill displayed as a 2D shape along a wellpath.<br>
 * <br>
 * This class will create the required geometry and material to represent a fill going from the given curve to the other curve.<br>
 * Like a regular LogFill, this also supports reference values instead of curves.<br>
 * Note that the resulting geometry may contain extra vertex to deal with curves intersection.<br>
 *
 * This class renders a LogCurve along a trajectory in a similar way of what the WellLogJS toolkit does.<br>
 * In order for the user to see the 2D curve it's always projected toward the camera.<br>
 * Which means that when the user moves the camera the log will try to adapt its representation to be as much visible as possible.<br>
 * However that also means that some camera angles will not be ideal to look at the log.<br>
 * Typically when the camera and the trajectory path are aligned.<br>
 * This algorithm is implemented at the shader level to ensure the best performances.<br>
 * <br>
 * Note that curvemin&curvemax options are not supported for dual curve fill (if both values1 and values2 are curves).
 */
export declare class LogFill2D extends Object3D {
    constructor(options?: LogFill2D.Options);
    /**
     * Set options, the given json will be merged with the object's state so that only the given options will be changed.<br>
     * @param [options] The options
     * @returns this
     */
    setOptions(options?: LogFill2D.Options): this;
    /**
     * Get options
     * (see {@link @int/geotoolkit3d/scene/well/LogFill2D~LogFill2D.setOptions} for more info)
     * @returns options
     */
    getOptions(): LogFill2D.OptionsOut;
}
export declare namespace LogFill2D {
    /**
     * The options
     */
    export type Options = Object3D.Options & {
        /**
         * The trajectory data.
         */
        data?: Data;
        /**
         * The lower normalization limit. Any value less than this will be clamped.<br>
         * Default is Number.POSITIVE_INFINITY when no curvevalues are provided.
         * Else it is the minimum between the curvevalues1 and curvevalues2.
         */
        curvemin?: number;
        /**
         * The upper normalization limit. Any value greater than this will be clamped.<br>
         * Default is Number.NEGATIVE_INFINITY when no curvevalues are provided.
         * Else it is the maximum between the curvevalues1 and curvevalues2.
         */
        curvemax?: number;
        /**
         * The radius factor to apply. This will increase the fill amplitude on screen.<br>
         * Default is 1.
         */
        radius?: number;
        /**
         * An offset value to shift the fill location by 'n' times the radius. Use a negative value to display the fill on the left of the path.<br>
         * Default is 1.
         */
        offset?: number;
        /**
         * Defines the curve behavior when offset is negative. See {@link @int/geotoolkit3d/util/well/Well~OffsetMode}.<br>
         * Default is OffsetMode.Mirror.
         */
        offsetmode?: OffsetMode;
        /**
         * A single color in CSS format (Used if no positive/negative color is set).<br>
         * Default is 'blue'.
         */
        colorprovider?: ColorProvider | Color | string;
        /**
         * The color for the positive log curve, if provided.<br>
         * Default is undefined.
         */
        positivecolor?: Color | string;
        /**
         * The color for the negative log curve, if provided.<br>
         * Default is undefined.
         */
        negativecolor?: Color | string;
    };
    export type OptionsOut = Omit<Required<Options>, 'data'>;
    type Data = {
        /**
         * The x deviation values
         */
        x: number[];
        /**
         * The y deviation values
         */
        y: number[];
        /**
         * The elevation values
         */
        z: number[];
        /**
         * The log curve1 values or a reference value in range [0,1]
         */
        curvevalues1?: number[] | number;
        /**
         * The curvevalues1's nullvalue
         */
        nullvalue1?: number;
        /**
         * The log curve2 values or a reference value in range [0,1]
         */
        curvevalues2?: number[] | number;
        /**
         * The curvevalues2's nullvalue
         */
        nullvalue2?: number;
        /**
         * Optional attribute used for coloring the trajectory per vertex
         */
        colorvalues?: number[] | number;
        /**
         * The values's nullvalue
         */
        nullvalue?: number;
    };
    export {};
}
