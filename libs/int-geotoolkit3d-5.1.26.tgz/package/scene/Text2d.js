/* eslint-disable */

export {Izt as Text2d} from '@int/impl/geotoolkit3d.js';
