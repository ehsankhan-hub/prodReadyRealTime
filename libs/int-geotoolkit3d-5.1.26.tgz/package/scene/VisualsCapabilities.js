/* eslint-disable */

export {KHt as Limitation} from '@int/impl/geotoolkit3d.js';
