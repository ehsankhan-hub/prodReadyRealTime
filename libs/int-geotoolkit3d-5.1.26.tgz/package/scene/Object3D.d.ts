/**
 * @module geotoolkit3d/scene/Object3D
 */
import type { Camera, EulerOrder, Scene, WebGLRenderer } from 'three';
import { Object3D as BASEObject3D } from 'three';
import { Event } from '@int/geotoolkit3d/Event';
import type { Plot } from '@int/geotoolkit3d/Plot';
import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
/**
 * Object3D Events enumerator
 * @readonly
 * @enum
 */
export declare enum Events {
    /**
     * Event type fired when a shape is modified and requires a render cycle to be done
     */
    Invalidate = "Invalidate",
    /**
     * Event type fired when a shape is added as a child to another shape
     */
    ChildAdded = "ChildAdded",
    /**
     * Event type fired when a shape is removed from another shape children.
     */
    ChildRemoved = "ChildRemoved",
    /**
     * Visibility is changed
     */
    VisibilityChanged = "VisibilityChanged",
    /**
     * Node tree structure changed (children added/removed/order changed)
     */
    NodeTreeChanged = "NodeTreeChanged",
    /**
     * Node parent has been changed
     */
    ParentChanged = "ParentChanged",
    /**
     * This Event is fired when the property was changed
     */
    PropertyChanged = "PropertyChanged",
    /**
     * Called when the object has been Disposed.
     */
    Disposed = "Disposed"
}
/**
 * Base class of Carnac3D objects.<br>
 * <br>
 * This class extends THREE.Object3D to expose some useful functions and add some new features.<br>
 * It is similar to a CarnacJS Group (has children and holds a transformation that applies to its children).<br>
 * <br>
 * To change the location/size/orientation of an Object3D, refer to THREEJS documentation
 */
export declare class Object3D extends BASEObject3D {
    constructor(options?: Object3D.Options);
    /**
     * Attach listener on event that will be called whenever the specified event is delivered to the target
     * <p>
     * If the callback function is already in the list of event listeners for this target,
     * the function is not added a second time.
     * </p>
     * <p>
     * If a particular anonymous function is in the list of event listeners registered for a
     * certain target, and then later in the code, an identical anonymous function is given
     * in an "on" call, the second function will also be added to the list of
     * event listeners for that target.
     * </p>
     * @param type type of event or property
     * @param callback to be called
     * @param [options] options of subscription
     * @returns this
     */
    on(type: string, callback: EventDispatcher.EventListener, options?: EventDispatcher.Options): this;
    on<E extends keyof Object3D.EventMap>(type: E, callback: (eventType: E, sender: this, args: Object3D.EventMap[E]) => void, options?: EventDispatcher.Options): this;
    /**
     * Detach listener on event.
     * Calling .off() with no arguments removes all attached listeners.
     * Calling .off(type) with no callback removes all attached listeners for specific type.
     * @param [type] type of the event
     * @param [callback] function to be called
     * @returns this
     */
    off(type: string, callback?: EventDispatcher.EventListener): this;
    off<E extends keyof Object3D.EventMap>(type: E, callback: (eventType: E, sender: this, args: Object3D.EventMap[E]) => void): this;
    /**
     * * Notify listeners. Parent nodes will also be notified if they are instances of geotoolkit3d.scene.Object3D
     * @param type event types
     * @param source of the event
     * @param [args] arguments of the event
     * @returns this
     */
    notify(type: string, source: any, args?: any): this;
    /**
     * Notifies this object and its parent that this object has been invalidated.<br>
     * If this object is in a Plot, it will be marked as dirty and will trigger a rendering cycle.<br>
     * @param [event] The event to fire
     */
    invalidateObject<T>(event?: Event<T>): this;
    /**
     * This function is called prior to rendering and can update this object's content.<br>
     * <br>
     * It should not trigger any invalidateObject though.<br>
     * Note that it is not necessary nor recommended to explicitly call updateObject on this object's children as updateObject will be called on all nodes present in the scene.<br>
     * <br>
     * This will be executed before the transformations simplification.<br>
     * <br>
     * @see {@link @int/geotoolkit3d/Plot~Plot} for more details on the render steps
     * @param scene The scene
     * @param camera The camera
     */
    updateObject(scene: Scene, camera: Camera): this;
    /**
     * This function is called when the plot has updated performance metric.<br>
     * It will be called every set number of frames.<br>
     * The number of frame is customizable in the plot options advancedrendering.performancemetrics.updateframeperiod and is 100 by default.
     * @param metrics The performance metrics.
     */
    onStatsUpdated(metrics: Plot.PerformanceMetrics): this;
    /**
     * This function is called prior to rendering and can update this object's content.<br>
     * <br>
     * It should not trigger any invalidateObject though.<br>
     * Note that it is not necessary nor recommended to explicitly call beforeRender on this object's children as beforeRender will be called on all nodes present in the scene.<br>
     * <br>
     * This will be executed after the transformations simplification.<br>
     * <br>
     * @see {@link @int/geotoolkit3d/Plot~Plot} for more details on the render steps
     * @param scene The scene
     * @param camera The camera used for this render phase.
     * @param plot The 3D plot
     * @param renderer The renderer
     */
    beforeRender(scene: Scene, camera: Camera, plot: Plot, renderer: WebGLRenderer): this;
    /**
     * This function is called after rendering and can update this object's content.<br>
     * <br>
     * It should not trigger any invalidateObject though.<br>
     * Note that it is not necessary nor recommended to explicitly call afterRender on this object's children as beforeRender will be called on all nodes present in the scene.<br>
     * <br>
     * This will be executed after the transformations simplification.<br>
     * <br>
     * @see {@link @int/geotoolkit3d/Plot~Plot} for more details on the render steps
     * @param scene The scene
     * @param camera The camera used for this render phase.
     * @param plot The 3D plot
     * @param renderer The renderer
     */
    afterRender(scene: Scene, camera: Camera, plot: Plot, renderer: WebGLRenderer): this;
    /**
     * Adds object as child of this object.
     * @param object object
     * @returns this
     */
    add(object: BASEObject3D | BASEObject3D[]): this;
    /**
     * Removes object as child of this object.
     * @param object object
     * @returns this
     */
    remove(object: BASEObject3D | BASEObject3D[]): this;
    /**
     * Returns true if this object make its own highlight effect (like geotoolkit3d.scene.reservoir.hexahedral.ReservoirGrid)
     * This is to prevent unnecessary executions of the costly highlight passes.
     */
    useOwnHighlight(): boolean;
    /**
     * Register object for special processing through a callback function<br>
     * @example
     * geotoolkit3d.util.ObjectProcessor.getDefaultInstance().registerObject(this.getClassName(), callback);
     * @deprecated since 5.0, to allow custom object highlighting, please instead make your Object implement
     * the interface geotoolkit3d/scene/ICustomHighlight.
     */
    static register(): void;
    /**
     * Dispose object
     */
    dispose(): void;
    /**
     * Returns whether this object has been disposed
     */
    isDisposed(): boolean;
    /**
     * Set options
     * @param [options] options object
     * @returns this
     */
    setOptions(options?: Object3D.Options): this;
    /**
     * Get options
     * @returns options object
     */
    getOptions(): Required<Object3D.Options>;
    /**
     * This method is called if visibility is changed.  Send event {@link @int/geotoolkit3d/scene/Object3D~Events.VisibilityChanged}
     */
    protected onVisibilityChanged(): void;
    /**
     * Set visible
     * @param visible true, if object is visible
     * @param [silent] true, if object shouldn't be invalidated
     * @returns this
     */
    setVisible(visible: boolean, silent?: boolean): this;
    /**
     * Get visible
     * @returns true, if object is visible
     */
    getVisible(): boolean;
    /**
     * Return if this object can be picked/selected (see RendererPicking).<br>
     */
    isSelectable(): boolean;
    /**
     * Set if this object can be picked/selected (see RendererPicking).<br>
     * @param selectable if can be selected
     */
    setSelectable(selectable: boolean): void;
    /**
     * Set Object's local position.
     * @param position local position
     * @returns this
     */
    setPosition(position: {
        x?: number;
        y?: number;
        z?: number;
    }): this;
    /**
     * Set Object's local rotation ({@link https://en.wikipedia.org/wiki/Euler_angles | Euler angles}), in radians.
     * @param x x angle
     * @param y y angle
     * @param z z angle
     * @param [order] euler order
     * @returns this
     */
    setRotation(x: number, y: number, z: number, order?: EulerOrder): this;
    getClassName(): string;
    static getClassName(): string;
}
export declare namespace Object3D {
    /**
     * options object
     */
    type Options = {
        /**
         * true to make object visible
         */
        visible?: boolean;
        /**
         * True if this object is allowed to be picked / selected. <br>
         * In some cases, picking can be costly or not desired; this allows to control picking behavior for individual objects.
         */
        isselectable?: boolean;
    };
    type EventMap = EventDispatcher.EventMap & {
        /**
         * Event type fired when a shape is modified and requires a render cycle to be done.
         * The invalidate event will only fire once for each object during the same rendering cycle.
         */
        [Events.Invalidate]: void;
        /**
         * Event type fired when a shape is added as a child to another shape
         */
        [Events.ChildAdded]: void;
        /**
         * Event type fired when a shape is removed from another shape children.
         */
        [Events.ChildRemoved]: void;
        /**
         * Visibility is changed
         */
        [Events.VisibilityChanged]: void;
        /**
         * Node tree structure changed (children added/removed/order changed)
         */
        [Events.NodeTreeChanged]: void;
        /**
         * Node parent has been changed
         */
        [Events.ParentChanged]: void;
        /**
         * This Event is fired when the property was changed
         */
        [Events.PropertyChanged]: string | {
            name: string;
            value: any;
        } | void;
        /**
         * Called when the object has been Disposed.
         */
        [Events.Disposed]: void;
    };
}
