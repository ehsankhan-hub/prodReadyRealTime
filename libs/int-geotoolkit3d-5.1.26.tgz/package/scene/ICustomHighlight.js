/* eslint-disable */

export {eYt as ICustomHighlight} from '@int/impl/geotoolkit3d.js';
