/* eslint-disable */

export {lOt as ColorMapShaderMaterial} from '@int/impl/geotoolkit3d.js';
