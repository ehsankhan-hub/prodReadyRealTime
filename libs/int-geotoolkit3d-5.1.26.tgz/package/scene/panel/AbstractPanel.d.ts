/**
 * @module geotoolkit3d/scene/panel/AbstractPanel
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { IOverlayableObject } from '@int/geotoolkit3d/util/intersection/IOverlayableObject';
import type { Group } from '@int/geotoolkit/scene/Group';
import type { Rect } from '@int/geotoolkit/util/Rect';
import type { Mesh, Vector3 } from 'three';
/**
 * Abstract Panel is a 3D "quad" rectangle which can be used to draw and display 2D toolkit shapes.<br>
 * The rendering options of the shapes are fully customizable (background fillstyle, size, scale).
 */
export declare abstract class AbstractPanel extends Object3D implements IOverlayableObject {
    protected constructor(options?: Object3D.Options);
    /**
     * Return the current 2D Shape group used to render the overlay.
     */
    abstract getOverlay(): Group | null;
    /**
     * Set the current 2D Shape group used to render the overlay.
     */
    abstract setOverlay(group: Group): void;
    /**
     * Return the overlay texture bounds, (unit is in pixel).
     */
    abstract getOverlayTextureBounds(): Rect;
    /**
     * Return the world position of a specific corner of this overlayable (rectangular) object.<br>
     * @param index Index of the corner, from 0 to 3.
     * @param target Optional point Vector3 to avoid unnecessary object creation. Will be updated and returned if provided.
     * @example
     * The indices represent the 4 corners of the overlayable object like so:
     * 0---1
     * |   |
     * 2---3
     */
    abstract getCorner(index: number, target?: Vector3): Vector3;
    /**
     * Return the local position of a specific corner of this overlayable (rectangular) object.<br>
     * @param index Index of the corner, from 0 to 3.
     * @param target Optional point Vector3 to avoid unnecessary object creation. Will be updated and returned if provided.
     * @example
     * The indices represent the 4 corners of the overlayable object like so:
     * 0---1
     * |   |
     * 2---3
     */
    abstract getLocalCorner(index: number, target?: Vector3): Vector3;
    /**
     * Return the Three.js Mesh of this overlayable object.<br>
     * Used in intersections to compute the object boundaries, to generate transformations for the overlay.
     */
    abstract getMesh(): Mesh;
}
