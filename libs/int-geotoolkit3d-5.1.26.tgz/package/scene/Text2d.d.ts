/**
 * @module geotoolkit3d/scene/Text2d
 */
import { TextStyle } from '@int/geotoolkit/attributes/TextStyle';
import { Sprite, Vector2, Vector3 } from 'three';
import { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
/**
 * This class implements text as a 2D sprite.<br>
 * A 2D text is a text that will always face the camera and that is horizontal.<br>
 * Internally it uses a texture created using a regular canvas.<br>
 * <br>
 * It also offers a 'fixed size' mode that force the text to be always the same size on screen.<br>
 * Note that this mode introduces some blurriness as the texture is rescaled by the graphic card on the fly.<br>
 * If outline is set, the original font style might be overwritten.
 */
export declare class Text2d extends Sprite {
    /**
     * Create a Text2d
     * @param [textOrOptions] - text to display or options for Text2d
     */
    constructor(textOrOptions?: string | Text2d.Options);
    /**
     * @param [text] - text to display
     * @param [options] - options for Text2d
     */
    constructor(text: string, options?: Text2d.Options);
    /**
     * Set text outline, or disable outline.
     * @param outlineOpt outline options
     */
    setOutline(outlineOpt: Text2d.OutlineOptions): void;
    /**
     * Gets text
     */
    getText(): string;
    /**
     * Sets text
     * @param text text
     * @returns this
     */
    setText(text: string): this;
    /**
     * Gets text style
     */
    getTextStyle(): TextStyle | null;
    /**
     * Sets text style
     * @param textStyle text style
     * @param [merge] true if you want to merge textStyle with existing attribute, false by default
     * @returns this
     */
    setTextStyle(textStyle: TextStyle.Type, merge?: boolean): this;
    /**
     * The given xyz vector will be used when computing the text location after scaling.<br>
     * It will translate the text in the given direction by half the text size.<br>
     *
     * finalPosition = position + anchorOffsetRatio * (sizeInDevice/2 + offsetInDevice)
     * @param ratio The anchor offset factor to be applied when computing offset
     * @returns this
     */
    setAnchorOffsetRatio(ratio: Vector3): this;
    /**
     * The given xyz vector will be used when computing the text location after scaling.<br>
     * It will be added to the offset value.<br>
     *
     * finalPosition = position + anchorOffsetRatio * (sizeInDevice/2 + offsetInDevice)
     * @param offset The anchor offset in device to be applied when computing offset
     * @returns this
     */
    setAnchorOffset(offset: Vector2): this;
    isDisposed(): boolean;
    /**
     * Dispose this object
     */
    dispose(): void;
}
export declare namespace Text2d {
    /**
     * options object
     */
    type Options = CommonOptions & {
        /**
         * @deprecated
         * Text2d option.font is deprecated since 5.0. Please use the option 'style' instead.
         * Define the font, if the option.style is empty, this option will be used instead
         */
        font?: string;
        /**
         * @deprecated
         * Text2d option.color is deprecated since 5.0. Please use the option 'style' instead.
         * Define the text color, if the option.style is empty, this option will be used instead
         * If the option.outline.enable is true, outline color will be used instead.
         */
        color?: string | RgbaColor;
        /**
         * @deprecated
         * Text2d option.dontmanuallyupdate is deprecated since 5.0. It will be internal in next major version.
         * hidden feature to reduce grid axis texts cost, put a stop to the render
         */
        dontmanuallyupdate?: boolean;
    };
    /**
     * Outline options
     */
    type OutlineOptions = {
        /**
         * Text2d option.outline.enabled (with a d) is deprecated since 5.0 for consistency. Please use the option 'enable' instead.
         * @deprecated
         */
        enabled?: boolean;
        /**
         * Set to false in order to disable the text outline, and ignore outline color settings.
         * If true, outlinecolor will override other TextStyle and text color options.
         */
        enable?: boolean;
        /**
         * Define the inner color for text with outline
         */
        innercolor?: string | CanvasGradient | CanvasPattern;
        /**
         * Define the outline color for text with outline
         */
        outlinecolor?: string | CanvasGradient | CanvasPattern;
        /**
         * Define the outline thickness
         */
        thickness?: number;
    };
    type CommonOptions = {
        /**
         * Define the text to display.
         */
        text?: number | string;
        /**
         * Define the text style (color, font, size and more).
         * If the option.outline.enable is true, outline color will be used instead.
         */
        style?: TextStyle.Type;
        /**
         * Set to true if the text should always be drawn with the same size, no matter of how far it is
         */
        issizeindevice?: boolean;
        /**
         * If provided, text will have outline
         */
        outline?: OutlineOptions;
    };
}
