import type { Blending, BlendingDstFactor, BlendingEquation, BlendingSrcFactor, Color, DepthModes, Plane, ShaderMaterialParameters, Side, WebGLProgramParametersWithUniforms, WebGLRenderer } from 'three';
import { ShaderMaterial } from 'three';
import { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import type { Merge, ToRecord } from '@int/geotoolkit/base';
/**
 * A material similar to THREE.ShaderMaterial, rendered with custom shaders and supports color maps through a texture
 * <br>
 * If the given colorprovider is null then only the single color will be used.<br>
 * <br>
 */
export declare class ColorMapShaderMaterial extends ShaderMaterial {
    constructor(options?: ColorMapShaderMaterial.Options);
    /**
     * Set options, the given json will be merged with the object's state so that only the given options will be changed.<br>
     * @param options The options
     * @returns this
     */
    setOptions(options: ColorMapShaderMaterial.OptionsBase): this;
    /**
     * Get mesh colormap basic material options
     * (see {@link @int/geotoolkit3d/scene/ColorMapShaderMaterial~ColorMapShaderMaterial.setOptions} for more info)
     * @returns options
     */
    getOptions(): ColorMapShaderMaterial.OptionsBaseOut;
    dispose(): void;
    onBeforeCompile(parameters: WebGLProgramParametersWithUniforms, renderer: WebGLRenderer): void;
    setOptionsMultiColorMap(options: ColorMapShaderMaterial.MultiColorMap.Options): this;
    /**
     * Retrieve the color map size
     * @returns current colormap size
     */
    getColormapSize(): number;
    getOptionsMultiColorMap(): ColorMapShaderMaterial.MultiColorMap.OptionsOut;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace ColorMapShaderMaterial {
    export type Options = Merge<ToRecord<ShaderMaterialParameters>, OptionsBase>;
    export type OptionsBase = ColorMap.Options & MultiColorMap.Options & Partial<CommonOptions>;
    export type OptionsBaseOut = ColorMap.OptionsOut & Partial<MultiColorMap.OptionsOut> & CommonOptions;
    type CommonOptions = {
        /**
         * Opacity. Default is 1.
         */
        opacity: number;
        /**
         * Is handled by the rendering passes. Default is true.
         */
        transparent: boolean;
        /**
         * Defines which of the face sides will be rendered - front, back or both.
         * Default is THREE.DoubleSide. Other options are THREE.BackSide and THREE.FrontSide.
         */
        side: Side;
        /**
         * Sets the alpha value to be used when running an alpha test. Default is 0.
         */
        alphaTest: number;
        /**
         * Blending destination. Default is OneMinusSrcAlphaFactor.
         */
        blendDst: BlendingDstFactor;
        /**
         * Blending equation to use when applying blending. Default is AddEquation.
         */
        blendEquation: BlendingEquation;
        /**
         * Which blending to use when displaying objects with this material. Default is NormalBlending.
         */
        blending: Blending;
        /**
         * Blending source. It's one of the blending mode constants defined in Three.js. Default is SrcAlphaFactor.
         */
        blendSrc: BlendingSrcFactor | BlendingDstFactor;
        /**
         * Whether to render the material's color. This can be used in conjunction with a mesh's .renderOrder property to create invisible objects that occlude other objects. Default is true.
         */
        colorWrite: boolean;
        /**
         * Which depth function to use. Default is LessEqualDepth. See the depth mode constants for all possible values. Default is LessEqualDepth.
         */
        depthFunc: DepthModes;
        /**
         * Whether to have depth test enabled when rendering this material. Default is true.
         */
        depthTest: boolean;
        /**
         * Whether rendering this material has any effect on the depth buffer. Default is true.
         * When drawing 2D overlays it can be useful to disable the depth writing in order to layer several things together without creating z-index artifacts.
         */
        depthWrite: boolean;
        /**
         * Whether the material is affected by fog. Default is false.
         */
        fog: boolean;
        /**
         * Defines whether this material is tone mapped according to the renderer's toneMapping setting. Default is true.
         */
        toneMapped: boolean;
        /**
         * Defines whether this material supports clipping. Default is true.
         */
        clipping: boolean;
        /**
         * Defines the clipping planes
         * see {@link https://threejs.org/docs/#api/en/materials/Material.clippingPlanes}
         */
        clippingplanes: Plane[];
        /**
         * Define clip intersection. Default is false.
         * see {@link https://threejs.org/docs/#api/en/materials/Material.clipIntersection}.
         */
        clipintersection: boolean;
        /**
         * Colormap size limit
         * Default is 1024
         */
        colormapsize: number;
    };
    export namespace ColorMap {
        type Options = {
            /**
             * Optional single color (reset to white if a colorprovider is given)
             */
            color?: Color;
            /**
             * A color provider to generate the colormap of this material.
             * Used to associate colors to value on your 3D Object render.
             */
            colorprovider?: ColorProvider | string | Color;
        };
        /**
         * The color map options
         */
        type OptionsOut = {
            /**
             * Optional single color (reset to white if a colorprovider is given)
             */
            color: Color;
            /**
             * A color provider to generate the colormap of this material.
             * Used to associate colors to value on your 3D Object render.
             */
            colorprovider: ColorProvider;
        };
    }
    export namespace MultiColorMap {
        /**
         * Object to describe part of object painted using specified colorprovider
         */
        type ColorMapsBaseType = {
            /**
             * Colorprovider to paint part of tube
             */
            colorprovider: ColorProvider;
        };
        type Options = {
            /**
             * Base information for color layers
             */
            colorlayers?: ColorMapsBaseType[];
        };
        type OptionsOut = Required<Options>;
    }
    export {};
}
