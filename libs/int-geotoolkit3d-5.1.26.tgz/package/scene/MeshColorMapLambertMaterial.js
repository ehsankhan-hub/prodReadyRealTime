/* eslint-disable */

export {QXt as MeshColorMapLambertMaterial} from '@int/impl/geotoolkit3d.js';
