/* eslint-disable */

export {xXt as PlaneMaterial} from '@int/impl/geotoolkit3d.js';
