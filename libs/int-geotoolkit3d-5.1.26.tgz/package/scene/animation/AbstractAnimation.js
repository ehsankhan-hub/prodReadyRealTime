/* eslint-disable */

export {fqt as AbstractAnimation} from '@int/impl/geotoolkit3d.js';
