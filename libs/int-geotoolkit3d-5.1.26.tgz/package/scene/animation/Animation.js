/* eslint-disable */

export {dqt as Animation} from '@int/impl/geotoolkit3d.js';
