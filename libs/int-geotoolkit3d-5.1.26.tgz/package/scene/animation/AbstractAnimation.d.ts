/**
 * Base class for animations
 */
export declare abstract class AbstractAnimation {
    /**
     * Function, that changes scene and returns true if animation was ended
     * @returns true, if animation is ended
     */
    abstract run(): boolean;
    /**
     * Cleanup and reference release method. To call when the class is no longer used.
     */
    abstract dispose(): void;
    static getClassName(): string;
    getClassName(): string;
}
