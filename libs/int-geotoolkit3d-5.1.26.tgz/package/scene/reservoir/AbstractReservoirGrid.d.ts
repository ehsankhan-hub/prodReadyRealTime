/**
 * @module geotoolkit3d/scene/reservoir/AbstractReservoirGrid
 */
import type { Events } from '@int/geotoolkit3d/scene/Object3D';
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
/**
 * Enumerator of the possible property types for Grid PropertyChanged Event.
 * See the Grid's options for more detail on each property.
 * @readonly
 * @enum
 */
export declare enum PropertyTypes {
    /**
     * If the grid cell values are updated.
     */
    CellValues = "CellValues",
    /**
     * If the grid AdditionalCellData are updated.
     */
    AdditionalCellData = "AdditionalCellData",
    /**
     * If the grid filters are updated in any way (either built-in or user custom filter).
     */
    Filters = "Filters",
    /**
     * If the grid ColorProvider is updated via VoxelGrid.setOptions.
     */
    ColorProvider = "ColorProvider",
    /**
     * If the grid DisplayMode is updated.
     */
    Mode = "Mode",
    /**
     * If the grid Skeleton options are updated.
     */
    Skeleton = "Skeleton",
    /**
     * If the grid HighlightMode is updated.
     */
    HighlightMode = "HighlightMode",
    /**
     * If the grid Transparency mode is updated.
     */
    EnableTransparency = "EnableTransparency"
}
/**
 * Base class for geotoolkit3d Grids visuals.
 */
export declare abstract class AbstractReservoirGrid extends Object3D {
    protected constructor(options: Object3D.Options);
    /**
     * Remove the helper shape representing the selected cell from being displayed.
     */
    abstract removeHighlightShape(): void;
    on<E extends keyof AbstractReservoirGrid.EventMap>(type: E, callback: (eventType: E, sender: this, args: AbstractReservoirGrid.EventMap[E]) => void): this;
    off<E extends keyof AbstractReservoirGrid.EventMap>(type?: E, callback?: (eventType: E, sender: this, args: AbstractReservoirGrid.EventMap[E]) => void): this;
    notify<E extends keyof AbstractReservoirGrid.EventMap>(type: E, source: AbstractReservoirGrid, args?: AbstractReservoirGrid.EventMap[E]): this;
}
export declare namespace AbstractReservoirGrid {
    type EventMap = Omit<Object3D.EventMap, 'PropertyChanged'> & {
        /**
         * Fired upon most Grid property changed.
         */
        [Events.PropertyChanged]: PropertyTypes;
    };
}
