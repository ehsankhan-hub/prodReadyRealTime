/**
 * @module geotoolkit3d/scene/reservoir/HighlightMode
 */
/**
 * Enum of Reservoir Highlighting Modes.<br>
 * <br>
 * The values of this enums can be used to determine the highlight mode of a reservoir.
 * @enum
 * @readonly
 */
export declare enum HighlightMode {
    /**
     * When user clicks the reservoir, the face(s) exposed to user will be highlighted
     */
    FrontFace = "frontface",
    /**
     * The highlight effect is disabled
     */
    None = "none"
}
