/**
 * @module geotoolkit3d/scene/reservoir/ReservoirEventDispatcher
 */
import { Type } from '@int/geotoolkit3d/Event';
import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
export declare namespace ReservoirEventDispatcher {
    /**
     * The callback used in the custom Reservoir event system.
     * @param type The type of event.
     * @param source The source that triggered the event.
     * @param [args] Additional arguments.
     */
    type ReservoirEventCallback = (type: Type, source: any, args?: any) => void;
    type EventMap = EventDispatcher.EventMap;
}
