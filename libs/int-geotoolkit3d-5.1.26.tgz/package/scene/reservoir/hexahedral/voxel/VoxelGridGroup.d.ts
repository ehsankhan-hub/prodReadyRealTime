import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import { VoxelGrid } from '@int/geotoolkit3d/scene/reservoir/hexahedral/voxel/VoxelGrid';
import { Box3 } from 'three';
import { AbstractReservoirGrid } from '@int/geotoolkit3d/scene/reservoir/AbstractReservoirGrid';
/**
 * The Voxel grid group is a utility 3D visual that allow handling of multiple Voxel sub grids at the same time, providing
 * convenience of use and performance improvements. (Soon with LOD support)
 */
export declare class VoxelGridGroup extends AbstractReservoirGrid {
    constructor(options?: VoxelGrid.OptionsBase);
    /**
     * Register and add a voxel subGrid to this Voxel grid group.
     * @param voxelGrid the voxel sub grid to add.
     * @param id the ID of the voxel subgrid, for easy retrieval.
     */
    setVoxelGrid(voxelGrid: VoxelGrid, id: string): this;
    /**
     * Return the Voxel sub grid for the specified ID, or undefined if no grid exists at this ID.
     * @param id the subgrid ID.
     */
    getVoxelGrid(id: string): VoxelGrid | undefined;
    /**
     * Return a copy of this VoxelGrid group metadata.
     */
    getMetadata(): VoxelGridGroup.MetaData;
    /**
     * Return all the current Voxel sub grids.
     */
    getVoxelGridList(): VoxelGrid[];
    /**
     * Remove and dispose the voxel subgrid at the specified ID.
     * @param id the voxel subgrid ID
     */
    disposeVoxelGrid(id: string): this;
    /**
     * Return the colorProvider for this Grid group, assuming the same colorprovider is used for all sub grids.
     */
    getColorProvider(): ColorProvider;
    /**
     * Set the colorProvider for this Grid group.
     * @param colorProvider the color provider
     */
    setColorProvider(colorProvider: ColorProvider): this;
    /**
     * Set this VoxelGrid group options.
     */
    setOptions(options: VoxelGrid.OptionsBase): this;
    /**
     * Get this Voxel Grid group options.
     */
    getOptions(): VoxelGrid.OptionsBaseOut;
    /**
     * Delete a previously defined additional cell data.<br>
     * @param name The name of the additional data to delete.
     */
    deleteAdditionalCellData(name: string): void;
    /**
     * Return the number of cells resulting from the user's filter.
     */
    getFilteredCellsCount(): number;
    /**
     * Remove the current cell highlight effects on this voxel grid group.
     */
    removeHighlightShape(): void;
    notify<E extends keyof AbstractReservoirGrid.EventMap>(type: E, source: VoxelGrid, args?: AbstractReservoirGrid.EventMap[E]): this;
    /**
     * Dispose this VoxelGridGroup, along its children.
     */
    dispose(): void;
}
export declare namespace VoxelGridGroup {
    type MetaData = {
        /**
         * The current number of sub grids in this group.
         */
        gridcount: number;
        /**
         * The current number of cells in this group (includes NaN/nullvalue cells)
         */
        totalcellcount: number;
        /**
         * The current number of valid cells in this group (excludes NaN/nullvalue cells)
         */
        totalvalidcellcount: number;
        /**
         * The minimum cell property values inside the entire group.
         */
        cellminvalue: number;
        /**
         * The maximum cell property values inside the entire group.
         */
        cellmaxvalue: number;
        /**
         * The minimum cell measured depth (MD) inside the entire group.
         */
        cellminmd: number;
        /**
         * The maximum cell measured depth (MD) inside the entire group.
         */
        cellmaxmd: number;
        /**
         * The maximum cell distance from its local central I axis, inside the entire group.
         * Radius is measured between the central I axis and the cell center.
         */
        cellmaxradius: number;
        /**
         * The boundaries of the entire Grid group, in local coordinates.
         */
        boundingbox: Box3;
        /**
         * The maximum I cell index across all sub grids. Please note that each Grid is using its own 0-indexed IJK
         * system, to filter along the grid length, please use measured depth (MD) instead.<br>
         * The minimum IJK index is always 0.
         */
        maxi: number;
        /**
         * The maximum J cell index across all sub grids. Please note that each Grid is using its own 0-indexed IJK
         * system.<br>
         * The minimum IJK index is always 0.
         */
        maxj: number;
        /**
         * The maximum K cell index across all sub grids. Please note that each Grid is using its own 0-indexed IJK
         * system.<br>
         * The minimum IJK index is always 0.
         */
        maxk: number;
    };
}
