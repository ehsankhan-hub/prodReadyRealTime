/**
 * @module geotoolkit3d/scene/reservoir/hexahedral/voxel/VoxelGrid
 */
import type { Box3, Color } from 'three';
import { Mesh } from 'three';
import { AbstractReservoirGrid } from '@int/geotoolkit3d/scene/reservoir/AbstractReservoirGrid';
import { IJKIndex } from '@int/geotoolkit3d/scene/reservoir/IJKIndex';
import type { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { DefaultReservoirPickingMaterial } from '@int/geotoolkit3d/picking/pickingrenderer/DefaultReservoirPickingMaterial';
import type { MeshColorMapBasicMaterial } from '@int/geotoolkit3d/scene/MeshColorMapBasicMaterial';
import { IIntersectablePolyhedron } from '@int/geotoolkit3d/util/intersection/IIntersectablePolyhedron';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import type { VoxelGridData } from '@int/geotoolkit3d/data/reservoir/hexahedral/voxel/VoxelGridData';
import { HighlightMode } from '@int/geotoolkit3d/scene/reservoir/HighlightMode';
import type { CellProperties, IJKValueFilter } from '@int/geotoolkit3d/scene/reservoir/IJKValueFilter';
/**
 * A 3D Voxel grid object. It is similar to ReservoirGrid feature wise, but is optimized for more regular structures like voxels, where each cell is identical.<br>
 * The cell shape is defined by 3 vectors, each defining the three axes of the hexahedral cell.<br>
 *
 * This object represents the 3D visualization of a voxel grid with an optional attribute used for coloring.<br>
 * The voxel cell's geometry and values are defined by the given VoxelGridData, and the cell visibility is determined by user-defined filters.
 *
 * Note: VoxelGrid works with transparent colors, but for correct visualization occlusion will be switched off.
 * So performance in case of transparent colors will be worse than with only opaque colors.
 */
export declare class VoxelGrid extends AbstractReservoirGrid implements IIntersectablePolyhedron {
    constructor(options: VoxelGrid.Options);
    getMesh(): Mesh;
    getPolyhedronsBoundingBox(target: Box3): void;
    getPolyhedron(polyhedronIndex: number, target: IIntersectablePolyhedron.PolyhedronCellData): void;
    isPolyhedronIndexFilteredOut(polyhedronIndex: number): boolean;
    getPolyhedronCount(): number;
    /**
     * Return the colorProvider for this Grid.
     */
    getColorProvider(): ColorProvider;
    /**
     * Set the colorProvider for this Grid.
     * @param colorProvider the color provider
     */
    setColorProvider(colorProvider: ColorProvider): this;
    /**
     * Change the cells values, and/or define additional cell data.<br>
     * Changing cell values will change the active cells properties used with the colormap, and reset the "value" filter.<br>
     * Additional cell data are named properties that can be then used in a custom filter function.<br>
     * To remove additional cell data, please use VoxelGridData.deleteAdditionalCellData.
     */
    setCellsValues(cellsValues: VoxelGridData.CellsValues): this;
    /**
     * Set this Grid options.<br>
     * Changing position data using setOptions is not allowed, as it is more expensive than creating a new Grid.
     */
    setOptions(options: VoxelGrid.OptionsBase): this;
    /**
     * Get this Grid options.
     */
    getOptions(): VoxelGrid.OptionsBaseOut;
    /**
     * Get the bounding box of this Voxel Grid (in local coordinates).
     * @returns bbox
     */
    getBoundingBox(): Box3;
    /**
     * Get the grid data, holding the cells positions and values.
     * @returns data
     */
    getData(): VoxelGridData;
    /**
     * Delete a previously defined additional cell data.<br>
     * @param name The name of the additional data to delete.
     */
    deleteAdditionalCellData(name: string): void;
    /**
     * Return the volume occupied by the remaining cells resulting from the user's filter.<br>
     * Each cell volume is computed based on the cell's xyz corner coordinates.<br>
     * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
     * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
     * @returns the total filtered cells volume.
     */
    getFilteredCellsVolume(): number;
    /**
     * Returns the total volume of this grid.<br>
     * Computed by the sum of the volume of every valid cell, filters are ignored.<br>
     * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
     * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
     */
    getGridFullVolume(): number;
    /**
     * Return the number of cells resulting from the user's filter.
     */
    getFilteredCellsCount(): number;
    /**
     * Highlight the designated cell index. Set the index to null to remove the current cell highlight.
     * Only one cell can be highlighted at the same time.<br>
     * Cells highlighted using this method will not be automatically removed by selection tools, unless another cell
     * from this grid is selected.
     * @param [index] the cell index to highlight, or null to remove previous highlight.
     * @returns true if the cell index is valid, false if the index is out of bounds. Null/no value is valid and returns true.
     */
    highlightCellByIndex(index?: number): boolean;
    /**
     * Highlight the designated cell ijk in the format [i, j, k].
     * Set the argument to null to remove the current cell highlight.<br>
     * Only one cell can be highlighted at the same time.
     * Cells highlighted using this method will not be automatically removed by selection tools, unless another cell
     * from this grid is selected.
     * @param [ijk] the cell ijk position to highlight, or null to remove previous highlight.
     * @returns true if the cell ijk is valid, false if the given ijk match no cell. Null/no value is valid and returns true.
     */
    highlightCellByIJK(ijk?: number[]): boolean;
    /**
     * Remove the current cell highlight effect on this grid.
     */
    removeHighlightShape(): void;
    /**
     * Used by the rendering pass to know whether this object have its own highlight mechanism, or should the pass itself generate a generic one.
     */
    useOwnHighlight(): boolean;
    /**
     * Get IJK info of selected/highlighted cell.
     */
    getSelectedProperties(): DefaultReservoirPickingMaterial.PickingCellData;
    /**
     * Return true if the given IJK is valid by the IJK filter of the VoxelGrid, false if is filtered out.
     */
    isIJKValidInFilter(ijk: IJKIndex | number[]): boolean;
    /**
     * Return true if the given value is bounded by the value filter of this Grid, false if the value is filtered out.<br>
     * Also return false if the value is not a number or equal to the defined nullvalue.
     */
    isValueValidInFilter(value: number): boolean;
    /**
     * Return true if the cell of the given index is filtered out (is not displayed), based on both IJK filter, value filter, and the user filter.
     */
    isCellIndexFilteredOut(index: number): boolean;
    notify<E extends keyof AbstractReservoirGrid.EventMap>(type: E, source: VoxelGrid, args?: AbstractReservoirGrid.EventMap[E]): this;
    /**
     * Rebuild the grid geometry depending on filters.<br>
     * Calling VoxelGrid.setOptions() also rebuilds the grid.<br>
     * The main use of this updateCellFilter() function is to manually update the grid when the custom filter is updated
     * via closure variables, and VoxelGrid.setOptions() is not called to update filters.
     */
    updateCellFilter(): this;
    /**
     * Dispose this grid visual, along its VoxelGridData.
     */
    dispose(): void;
}
export declare namespace VoxelGrid {
    export type Options = OptionsBase & {
        /**
         * The grid cell data to build this voxel grid.
         */
        data: VoxelGridData;
    };
    export type OptionsBase = Partial<CommonOptions> & Geometry.Options & Material.OptionsBase & Object3D.Options;
    export type OptionsBaseOut = CommonOptions & Required<Geometry.Options> & Material.OptionsBaseOut & Required<Object3D.Options>;
    type CommonOptions = {
        /**
         * The Voxel Grid's cell highlight mode.
         */
        highlightmode: HighlightMode;
        /**
         * (Very GPU intensive)
         * If enabled, the VoxelGrid is allowed to render with transparency in case its opacity is set to < 1, or if a colorProvider with transparency is provided.<br>
         * Please be aware that to render the grid correctly with transparency, multiple optimizations need to be turned off, which will dramatically reduce the rendering performances.<br>
         * To ensure a correct render, the Plot depth peeling option must be enabled (is enabled by default).
         */
        enabletransparency: boolean;
    };
    export type VoxelCellProperties = CellProperties & {
        /**
         * The cell measured depth at its center.
         */
        md: number;
        /**
         * The cell distance from the grid center (squared), measured between the grid center and the cell center.
         */
        radiussqr: number;
    };
    export namespace Geometry {
        type Options = FilterOptions;
        type FilterOptions = IJKValueFilter & {
            /**
             * If set, define the minimum Measured Depth (MD) of the cells allowed to be rendered.
             */
            minmd?: number;
            /**
             * If set, define the maximum Measured Depth (MD) of the cells allowed to be rendered.
             */
            maxmd?: number;
            /**
             * If set, define the maximum radius from the grid center under which cells are allowed to be rendered.
             */
            maxradius?: number;
        };
    }
    export namespace Material {
        type OptionsBase = Options & MeshColorMapBasicMaterial.OptionsBase;
        type OptionsBaseOut = OptionsOut & MeshColorMapBasicMaterial.OptionsBaseOut;
        /**
         * The Grid skeleton options such as skeleton line width and color.
         */
        type SkeletonOptions = {
            /**
             * The skeleton color
             */
            color?: string | Color;
            /**
             * The skeleton width
             */
            linewidth?: number;
        };
        type OptionsOut = {
            /**
             * The Grid skeleton options such as skeleton line width and color.
             */
            skeleton: Required<SkeletonOptions>;
        };
        type Options = {
            /**
             * The Grid skeleton options such as skeleton line width and color.
             */
            skeleton?: SkeletonOptions;
        };
    }
    export {};
}
