/* eslint-disable */

export {T6t as VoxelGridGroup} from '@int/impl/geotoolkit3d.voxelgrid.js';
