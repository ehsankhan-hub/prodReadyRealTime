/* eslint-disable */

export {x6t as VoxelGrid} from '@int/impl/geotoolkit3d.voxelgrid.js';
