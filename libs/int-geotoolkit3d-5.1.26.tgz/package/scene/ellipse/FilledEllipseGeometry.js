/* eslint-disable */

export {F1t as FilledEllipseGeometry} from '@int/impl/geotoolkit3d.js';
