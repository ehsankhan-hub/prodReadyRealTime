/* eslint-disable */

export {_Zt as EllipseGeometry} from '@int/impl/geotoolkit3d.js';
