/**
 * @module geotoolkit3d/scene/ellipse/FilledEllipseGeometry
 */
import { ShapeGeometry } from 'three';
import type { EllipseGeometry } from './EllipseGeometry';
/**
 * An ellipse geometry to be used with the THREE.Shape mesh.<br>
 * You can use this geometry options to define the ellipse shape and size (width, height, precision).<br>
 * And the mesh's '.position' and '.rotation' or '.quaternion' to change the ellipse position and orientation.<br>
 * This is the filled (shape) ellipse. For an hollow Ellipse, please see {@link @int/geotoolkit3d/scene/ellipse/EllipseGeometry~EllipseGeometry}.
 */
export declare class FilledEllipseGeometry extends ShapeGeometry {
    constructor(options?: EllipseGeometry.Options);
}
