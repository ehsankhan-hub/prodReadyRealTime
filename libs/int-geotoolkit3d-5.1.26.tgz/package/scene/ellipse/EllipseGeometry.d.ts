/**
 * @module geotoolkit3d/scene/ellipse/EllipseGeometry
 */
import { BufferGeometry } from 'three';
/**
 * An ellipse geometry to be used with the THREE.Line mesh.<br>
 * You can use this geometry options to define the ellipse shape and size (width, height, precision).<br>
 * And the mesh's '.position' and '.rotation' or '.quaternion' to change the ellipse position and orientation.<br>
 * This is the hollow (line) ellipse. For a filled Ellipse, please see {@link @int/geotoolkit3d/scene/ellipse/FilledEllipseGeometry~FilledEllipseGeometry}.
 */
export declare class EllipseGeometry extends BufferGeometry {
    constructor(options?: EllipseGeometry.Options);
    /**
     * Extract segmented points from this geometry
     * @returns points
     */
    extractSegmentPoints(): number[];
}
export declare namespace EllipseGeometry {
    type Options = {
        /**
         * Center x coordinate. Default is 0.
         */
        positionx?: number;
        /**
         * Center y coordinate. Default is 0.
         */
        positiony?: number;
        /**
         * Width of ellipse. Default is 1.
         */
        width?: number;
        /**
         * Height of ellipse. Default is 1.
         */
        height?: number;
        /**
         * Fineness of curve. A higher number means more segments and better quality. Default is 12.
         */
        precision?: number;
    };
}
