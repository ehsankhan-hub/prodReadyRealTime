import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { Box3, Mesh } from 'three';
import { CurtainVerticalMode } from '@int/geotoolkit3d/scene/curtain/CurtainVerticalMode';
import { IntersectionManager } from '@int/geotoolkit3d/util/intersection/IntersectionManager';
import { Plane } from '@int/geotoolkit3d/scene/plane/Plane';
import { FillStyle } from '@int/geotoolkit/attributes/FillStyle';
import { LineSegments } from '@int/geotoolkit3d/scene/LineSegments';
import { MultiPanelHighlightMode } from '@int/geotoolkit3d/Constants';
import { ICustomHighlight } from '@int/geotoolkit3d/scene/ICustomHighlight';
import { IIntersectableMesh } from '@int/geotoolkit3d/util/intersection/IIntersectableMesh';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
/**
 * The PlaneCurtain is an implementation of a 3D Curtain object made of Planes.
 * A Curtain is a vertical geometry defined by a series of horizontal points coordinates.
 * These points define a path in the X and Y axes, and the vertical size of the curtain is then defined by the
 * user.<br>
 *
 * This implementation represent the curtain geometry using multiple geotoolkit3d/scene/plane/Plane
 * This enable powerful features such as intersections between the curtain and 3D objects (such as ReservoirGrids, Surfaces).<br>
 *
 * Because each Plane will handle its own canvas and texture for drawing intersections, it is highly recommended to
 * leave the decimation option enabled for performance reasons.<br>
 *
 * This object provide these additional features over handling your own Planes:<ul>
 * <li>Automatic and customizable Curtain path decimation</li>
 * <li>Plane creation and handling</li>
 * <li>Intersection handling (resizing Curtain if needed)</li>
 * <li>Curtain shading</li>
 * </ul>
 */
export declare class PlaneCurtain extends Object3D implements ICustomHighlight, IIntersectableMesh {
    constructor(options: PlaneCurtain.Options);
    getMesh(): Mesh;
    getTriangle(triangleIndex: number, target: IIntersectableMesh.TriangleData): void;
    getTriangleCount(): number;
    getMeshBoundingBox(target: Box3): void;
    getColorProvider(): ColorProvider | RgbaColor;
    setOptions(options?: PlaneCurtain.OptionsBase): this;
    getOptions(): PlaneCurtain.OptionsBaseOut;
    /**
     * Get selected planes in the PlaneCurtain that will generate a highlight
     */
    getHighlightedObjects(): Plane[];
    /**
     * Generate or update an intersection between this curtain and the provided mesh object.
     * Supported objects include ReservoirGrids and Surfaces.
     * @param object the mesh object to intersect.
     * @param options the options for the intersection.
     */
    generateIntersection(object: Object3D, options?: IntersectionManager.PlaneMeshIntersectionOptions): void;
    /**
     * Returns an array that contains all the planes
     */
    getPlanes(): Plane[];
    /**
     * Update an intersection property without recomputing the intersection coordinates.
     * @param object the mesh object to update the intersection of.
     * @param options the options for the intersection.
     */
    setIntersectionProperties(object: Object3D, options: IntersectionManager.PlaneMeshIntersectionOptions): void;
    /**
     * Remove the intersection between this curtain and the given object.
     * @param object the object to remove the intersection of.
     */
    removeIntersection(object: Object3D): void;
}
export declare namespace PlaneCurtain {
    export type Options = CommonOptions & {
        /**
         * The curtain path datas.
         */
        data: {
            /**
             * The X coordinates of the points in the curtain path.
             */
            x: number[] | Float32Array;
            /**
             * The Y coordinates of the points in the curtain path.
             */
            y: number[] | Float32Array;
        };
        /**
         * The options for curtain point path decimation.<br>
         * Decimation allow to reduce the number of points in order to generate fewer Planes, and improve performances and intersection quality.<br>
         * This decimation will linearly resample the points in the given path, to generate Planes of equal size.
         */
        decimation?: {
            /**
             * If decimation is enabled, true by default.<br>
             * If set to false, the curtain will generate (number of provided points - 1) Planes, and this can cause serious performance issues if the number of points is high.<br>
             * We recommend leaving decimation enabled when the curtain have more than 20 or 30 points. Decimation will have no effect if the count of provided points is < option.maxsegments.
             */
            enabled?: boolean;
            /**
             * The maximum number of segments in the resulting decimated path. One segment will account to one Plane.<br>
             * Can be set to 0 to ignore the limit (not advised for performances, and very small Planes can result in artifacts.).<br>
             * Default is 30.
             */
            maxsegments?: number;
        };
    };
    export type OptionsBase = Partial<CommonOptions>;
    export type OptionsBaseOut = Required<CommonOptions>;
    type CommonOptions = Object3D.Options & {
        /**
         * The lower limit of the Curtain on the Z axis. The effect will change based on the defined 'verticalmode'.
         */
        zmin: number;
        /**
         * The higher limit of the Curtain on the Z axis. The effect will change based on the defined 'verticalmode'.
         */
        zmax: number;
        /**
         * The behavior of the Curtain in regard to its vertical position/size.<br>
         * Default is CurtainVerticalMode.AdjustToIntersections.
         */
        verticalmode?: CurtainVerticalMode;
        /**
         * If the Curtain surface should receive shading. This allows to more easily see the details of the curtain path.
         * Default is true.
         */
        shading?: boolean;
        /**
         * The Curtain Plane background fillStyle. This can be either a string color, css color or a geotoolkit/attributes/FillStyle.<br>
         * Default is '#800000' (Dark red).
         */
        fillstyle?: FillStyle.Type;
        /**
         * Set the PlaneCurtain highlight mode. Available modes include highlight by single plane or highlight the entire curtain.
         * Default is MultiPlaneHighlightMode.AllPanels
         */
        highlightmode?: MultiPanelHighlightMode;
        /**
         * The texture resolution used for the overlay intersection. Define the vertical resolution.
         */
        resolution?: number;
        /**
         * Defines options for curtain borders. Borders are generated using the LineSegments class
         * from '@int/geotoolkit3d/scene/LineSegments'.
         */
        borders?: {
            /**
             * If enabled, the borders will be visible.
             * Default is false.
             */
            visible?: boolean;
            /**
             * Line options of the borders.
             */
            lineoptions?: LineSegments.ShaderOptions;
        };
    };
    export {};
}
