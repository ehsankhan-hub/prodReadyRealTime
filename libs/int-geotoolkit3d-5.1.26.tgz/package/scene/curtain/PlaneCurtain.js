/* eslint-disable */

export {V1t as PlaneCurtain} from '@int/impl/geotoolkit3d.js';
