import type { Mesh, Object3D } from 'three';
/**
 * Define an interface to allow custom defined highlighting for 3D objects
 * @interface
 */
export declare abstract class ICustomHighlight {
    /**
     * Return the objects that needs to be highlighted
     */
    abstract getHighlightedObjects(): Object3D | Object3D[] | Mesh | Mesh[] | null;
}
