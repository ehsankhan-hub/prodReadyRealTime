/* eslint-disable */

export {bKt as PointsetMaterial} from '@int/impl/geotoolkit3d.js';
