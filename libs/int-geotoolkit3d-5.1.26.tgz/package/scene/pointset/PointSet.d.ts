/**
 * @module geotoolkit3d/scene/pointset/PointSet
 */
import type { BufferGeometry, Texture as ThreeTexture } from 'three';
import { Box3, Color } from 'three';
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import { ICustomHighlight } from '@int/geotoolkit3d/scene/ICustomHighlight';
import type { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
import { Limitation } from '@int/geotoolkit3d/scene/VisualsCapabilities';
/**
 * Enum of symbols.<br>
 * <br>
 * The functions provided by this enum are responsible for loading/creating a Three.BufferGeometry that will be used to display a symbol in 3D.
 */
export declare class SymbolGeometry {
    /**
     * A sphere symbol using an UV sphere geometry.
     */
    static get Sphere(): (precision: number) => BufferGeometry<import("three").NormalBufferAttributes>;
    /**
     * An icosahedron/sphere symbol using an icosahedron geometry.
     * Can be used as an icosahedron with precision = 0,
     * or as a high quality sphere at precision >= 12.
     */
    static get Icosahedron(): (precision: number) => BufferGeometry<import("three").NormalBufferAttributes>;
    /**
     * A cube symbol
     */
    static get Cube(): () => BufferGeometry<import("three").NormalBufferAttributes>;
    /**
     * A pyramid symbol
     */
    static get Pyramid(): () => BufferGeometry<import("three").NormalBufferAttributes>;
}
/**
 * Define the Picking highlight mode for this pointset.<br>
 * Note that this only affect highlight via picking, individual points or full pointset can still be highlighted
 * via selectFullPointSet or setSelectedPoints.<br>
 * @readonly
 * @enum
 */
export declare enum HighlightMode {
    /**
     * Highlight only the point under the mouse cursor, upon click/picking.
     */
    Point = "Point",
    /**
     * Highlight the full pointset upon clicking/picking on any point of the pointset.
     */
    PointSet = "PointSet"
}
/**
 * PointSet is a set of 3D coordinates rendered as 3D symbols.<br>
 * <br>
 * It's similar to a PointCloud and share most of the same API (even if there is no inheritance between them).<br>
 * The main difference between PointSet and PointCloud is that a PointSet uses real 3D mesh for each symbol.<br>
 * As a consequence, the rendered symbols are cleaner and sharper, and there is no longer depth fighting (symbols blinking by rendering on top of each other).<br>
 * <br>
 * It is quite fast for rendering points as Cubes and Pyramids, however using Sphere geometry for really large sets of points (100 000+ points)
 * can be slower, you might have better performances using a PointCloud with a sphere texture instead.<br>
 * <br>
 * To save valuable memory on large pointset at creation time, it is advised to use typed Float32Array for points xyz, sizes and values as constructor parameters, in stead of regular Array.
 * <br>
 */
export declare class PointSet extends Object3D implements ICustomHighlight {
    constructor(options: PointSet.Options);
    /**
     * Set the PointSet options.
     * @returns this
     */
    setOptions(options: PointSet.Options): this;
    /**
     * Get the pointset general options (legacy)
     */
    getOptions(): PointSet.OptionsBaseOut;
    /**
     * Set per point options, note that it's more efficient to use setOptions() to modify large ensemble of points.
     * @param index The index of the point to edit
     * @param options The options
     * @returns this
     */
    setPointOptions(index: number, options: PointSet.PerPointOptions): this;
    /**
     * Get the attributes of a point at the given index.
     * Returns null if the given point index is not valid.
     * @param index index of point
     */
    getPointOptions(index: number): PointSet.PerPointOptionsOut | null;
    /**
     * Return the selected points indices (highlighted points).
     */
    getSelectedPoints(): number[];
    /**
     * Select and highlight the defined points indices.<br>
     * Can be used to highlight one or more points.<br>
     * To remove the highlight effect, call setSelectedPoints() with null.<br>
     * To select the entire pointset, use selectFullPointSet instead.
     * @param pointsIndices the index, or indices of the points to highlight. Null to remove any point highlight.
     */
    setSelectedPoints(pointsIndices?: number | number[]): void;
    /**
     * Select and highlight (or unselect) the entire PointSet. (points set to not 'visible' will remain hidden).<br>
     * To remove the highlight effect, call setSelectedPoints() with null.<br>
     * @param select true to select and highlight the entire pointset, false to unselect and remove any highlight.
     */
    selectFullPointSet(select: boolean): void;
    /**
     * Generate a highlight geometry for the given point index.
     * Highlight is a geometry that is rendered with a special effect in highlightPass.
     * @deprecated since 4.1, please use setSelectedPoints instead.
     * @param pointIndex the index of the point to highlight.
     */
    hightlightShape(pointIndex?: number): void;
    /**
     * Get the selected point mesh objects. Used in custom highlighting logic.
     */
    getHighlightedObjects(): Object3D | null;
    /**
     * Returns the world space bounding box of this pointset. Because instanced rendering do not use a classic geometry, this custom method is necessary.
     * @returns bounding box
     */
    getWorldBoundingBox(target?: Box3): Box3;
    /**
     * Estimate the maximum number of points that can be created in one PointSet visual, with the given RAM/VRAM information.<br>
     * The data type (array / Float32Array) of input data (xyz positions, sizes, values) will affect the implementation limit.
     * The calculation is based on input data as Float32Array, as it is optimal in performance and size.<br>
     * With enough memory, the implementation limit for PointSet is eventually tied to Typed array allocation.
     * This test will perform a one-time array allocation test on your device, to accurately estimate the maximum array
     * size your browser/device is capable of.
     * It is important to have enough memory available for this test to be accurate.
     */
    static estimateMemoryCapabilities(options: PointSet.MemoryEstimationOptions): PointSet.MemoryCapabilitiesInfo;
    /**
     * Return if this point index is valid (belong to a point in this point set).
     * @param index the point index.
     */
    isValidIndex(index: number): boolean;
}
export declare namespace PointSet {
    /**
     * The options
     */
    type Options = Object3D.Options & {
        /**
         * The data options
         */
        data?: {
            /**
             * The x coordinate values of each point.
             */
            x?: Float32Array | number[];
            /**
             * The y coordinate values of each point.
             */
            y?: Float32Array | number[];
            /**
             * The z coordinate / elevation values of each point.
             */
            z?: Float32Array | number[];
            /**
             * Sizes of the symbols, can be an array or a single value.<br>
             * To give user great flexibility in the display of points, the PointSet uses two size ranges:<ul>
             * <li>The points 'data' size range, which reports the minimum and maximum size value each point bears. These size values then get converted to the screen size range for display.
             * <ul>
             * <li>That range is defined automatically based on each point size value.</li>
             * <li>or manually by the options.data.sizemin and options.data.sizemax.</li>
             * </ul></li>
             * <li>The 'on screen' size range, which is used to define the minimum and maximum size of the point on screen.
             * <ul>
             * <li>That range is defined by the options.symbolminsize and options.symbolmaxsize.</li>
             * </ul></li>
             * </ul>
             * Points sizes are each set in the 'data' range, then that size normalized value get converted to the 'screen' range for render.<br>
             * This allows fine control over the rendering size without modifying the original point values.<br>
             * If this double range system is not necessary, it is always possible to set both ranges to the same min and max, this will effectively display points at their defined size.
             */
            sizes?: Float32Array | number[] | number;
            /**
             * An optional minimum to use for 'sizes' normalization.<br>
             * When manually defined, it overrides the minimum point size.<br>
             * For more details, see options.data.sizes documentation.
             */
            sizemin?: number;
            /**
             * An optional maximum to use for 'sizes' normalization.<br>
             * When manually defined, it overrides the maximum point size.<br>
             * For more details, see options.data.sizes documentation.
             */
            sizemax?: number;
            /**
             * A value attribute used for coloring the symbols.
             */
            values?: Float32Array | number[] | number;
            /**
             * Set the visibility of the points (true by default).
             */
            visible?: boolean[];
        };
        /**
         * The 3D symbol to use for the PointSet points.<br>
         * This option accept both default symbols, and custom 3D symbols.<br>
         * The default symbols textures defined in geotoolkit3d.util.Texture are also accepted, and will be recognized to their equivalent 3D symbol
         * (ex: a Square texture symbol will become a 3D cube). This is to provide a bridge between this PointSet class and the PointCloud class options.<br>
         * Note: custom textures are not supported, only custom 3D geometries are.
         */
        symbol?: SymbolFunction | ThreeTexture;
        /**
         * The size of the point symbol for the smallest value.<br>
         * This value determines the minimum size of each point symbol on screen.<br>
         * When symbolsizeisindevice is true, it determines the size in screen pixels (meaning the point symbol size doesn't change with distance)<br>
         * Otherwise, it determines the size in local coordinate units.<br>
         * Default value is 1.<br>
         * For more details, see options.data.sizes documentation.
         */
        symbolminsize?: number;
        /**
         * The size of the point symbol for the largest value.<br>
         * This value determines the maximum size of each point symbol on screen.<br>
         * When symbolsizeisindevice is true, it determines the size in screen pixels (meaning the point symbol size doesn't change with distance)<br>
         * Otherwise, it determines the size in local coordinate units.<br>
         * Default value is 6.<br>
         * For more details, see options.data.sizes documentation.
         */
        symbolmaxsize?: number;
        /**
         * A color provider or a single color in css format
         */
        colorprovider?: ColorProvider | string | Color;
        /**
         * True if the symbol size should only depend on their value, ignores the projection and any scale.<br>
         * Default is false.
         */
        symbolsizeisindevice?: boolean;
        /**
         * True if the symbols should not scale based on the plot scale.<br>
         * Default is true.
         */
        inverseplot?: boolean;
        /**
         * The symbols' opacity. For individual symbol transparency, use the colorProvider.<br>
         * Default is 1.
         */
        opacity?: number;
        /**
         * This factor is used to determine how many triangles will be used for the Sphere and IcoSphere symbol.<br>
         * By default, this value is automatically determined by the value of option.symbolmaxsize + 1.
         */
        precision?: number;
        /**
         * Define the Picking highlight mode for this pointset.<br>
         * Note that this only affect highlight via picking, individual points or full pointset can still be highlighted
         * via selectFullPointSet or setSelectedPoints.<br>
         * Default mode is HighlightMode.Point.
         */
        highlightmode?: HighlightMode;
    };
    type OptionsBaseOut = Required<Object3D.Options> & {
        opacity: number;
        colorprovider: string | ColorProvider | RgbaColor | Color;
        symbolminsize: number;
        symbolmaxsize: number;
    };
    type MemoryCapabilitiesInfo = {
        /**
         * The maximum number of points that can be loaded safely, with the given memory information.<br>
         * Please keep in mind this is only an estimation, even if the VRAM option is provided, browsers and OSes handle RAM and VRAM memory very differently.
         */
        maxpoints: number;
        /**
         * Describe the current bottleneck for the provided estimation.<br>
         * Please note that if the VRAM argument is not provided, it is not possible to tell if the GPU memory is the current limitation.
         */
        limitation: Limitation;
    };
    type MemoryEstimationOptions = {
        /**
         * The amount of estimated available RAM in bytes, that the PointSet visual can allocate.<br>
         * On average, PointSet will use 48 bytes of RAM per point.<br>
         * Additional features such as transparency can create additional memory spikes.
         */
        ram: number;
        /**
         * (Optional) The amount of estimated available VRAM (Video Memory) in bytes, that the PointSet visual can allocate.<br>
         * PointSet will use 40 bytes of VRAM per cell.
         */
        vram?: number;
    };
    /**
     * Per point options
     */
    type PerPointOptions = {
        /**
         * The visibility of the point
         */
        visible?: boolean;
        /**
         * The size of the point
         */
        size?: number;
        /**
         * The value of the point (used for color)
         */
        value?: number;
    };
    type PerPointOptionsOut = Required<PerPointOptions> & {
        /**
         * the xyz coordinates
         */
        position: number[];
    };
    type SymbolFunction = (precision: number) => BufferGeometry;
}
