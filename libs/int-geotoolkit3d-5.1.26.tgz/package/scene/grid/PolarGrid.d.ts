import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { TickGenerator } from '@int/geotoolkit/axis/TickGenerator';
import { LineStyle } from '@int/geotoolkit/attributes/LineStyle';
import { TextStyle } from '@int/geotoolkit/attributes/TextStyle';
import { Text2d } from '@int/geotoolkit3d/scene/Text2d';
/**
 * A Polar Grid for 3D scenes.<br>
 * <br>
 * The grid can be positioned in space using its position attribute.<br>
 * The labels/ticks displayed are controlled trough 'modelcenter' and 'modelsize'.
 */
export declare class PolarGrid extends Object3D {
    constructor(options?: PolarGrid.Options);
    /**
     * Set the Polar Grid options.
     */
    setOptions(options?: PolarGrid.Options): this;
    /**
     * Return the Polar Grid options.
     */
    getOptions(): PolarGrid.OptionsOut;
    /**
     * Set the external ring ("axis" ring) label text style.
     * @param textStyle a new shape text style
     * @param [merge] true if you want to merge textStyle with existing attribute, false by default
     * @returns this
     */
    setTextStyle(textStyle: TextStyle.Type, merge?: boolean): this;
    /**
     * Return the outline options for the Axis ring text labels.
     */
    getOutline(): Text2d.OutlineOptions;
    /**
     * Return the number of concentric rings (Grid ticks) count.
     */
    getCount(): number;
    /**
     * Return the offset distance from the center labels will consider as the origin.<br>
     * Labels will show the distance from the center, which is (modelsize / 2) - modelcenter.
     */
    getModelCenter(): number;
    /**
     * Return the offset distance from the center labels will consider as the origin.<br>
     * Labels will show the distance from the center, which is (modelsize / 2) - modelcenter.
     */
    getModelSize(): number;
}
export declare namespace PolarGrid {
    /**
     * The Polar Grid options.
     */
    type Options = Omit<Object3D.Options, 'isselectable'> & {
        /**
         * Tick generator to generate radial ticks
         */
        radialtickgenerator?: TickGenerator;
        /**
         * Tick generator to generate angle ticks
         */
        angletickgenerator?: TickGenerator;
        /**
         * The center of the polar grid's model.<br>
         * Can be seen as the offset distance from the center labels will consider as the origin. Default is 0.<br>
         * Labels will show the distance from the center, which is (modelsize / 2) - modelcenter.<br>
         * Example:
         * <ul>
         * <li>A modelsize (diameter) 100, modelcenter 0 will show outer labels displaying 50.</li>
         * <li>A modelsize (diameter) 100, modelcenter 5 will show outer labels displaying 45.</li>
         * </ul>
         */
        modelcenter?: number;
        /**
         * The diameter (size) of the Polar Grid. Default is 10.<br>
         * Labels will show the distance from the center, which is (modelsize / 2) - modelcenter.
         */
        modelsize?: number;
        /**
         * The number of concentric rings (Grid ticks) count. Default is 3.<br>
         * This count include the external ring (the "Axis" ring).
         */
        count?: number;
        /**
         * The number of radius axis (radii axes) to display on the polar grid.<br>
         * A radius axis consist of a line going from the center of the Polar Grid, toward the outer ring axis.
         */
        axiscount?: number;
        /**
         * The external ring ("axis" ring) options.
         */
        axis?: {
            /**
             * Defines the axis ring linestyle. Default is white.
             */
            linestyle?: LineStyle.Type;
            /**
             * Define the axis ring textstyle. Default is white 11px Arial.
             */
            textstyle?: TextStyle.Type;
            /**
             * Function responsible for formatting the axis labels text values.
             */
            formatter?: FormatterFunction;
            /**
             * If provided, the axis text labels will have an outline. Default is false.
             */
            outline?: Text2d.OutlineOptions;
            /**
             * Custom axis options
             */
            additional?: AdditionalAxisMarkers;
        };
        /**
         * The internal rings ("grid" rings) options.
         */
        grid?: {
            /**
             * Defines the grid rings linestyle. Default is grey.
             */
            linestyle?: LineStyle.Type;
            /**
             * Custom grid options
             */
            additional?: AdditionalGridMarkers;
        };
    };
    type OptionsOut = Required<Object3D.Options> & Options;
    /**
     * Custom axis tick options, key number is angle in degree from 0 to 360
     */
    type AdditionalAxisMarkers = Record<number, {
        /**
         * Custom tick line style
         */
        linestyle?: LineStyle.Type;
        /**
         * Additional text to tick
         */
        text?: string;
        /**
         * Custom text text style
         */
        textstyle?: TextStyle.Type;
    }>;
    /**
     * Custom grid tick options, key number is radius in model space, it should be in interval [modelCenter, modelCenter + modelSize] to be visible
     */
    type AdditionalGridMarkers = Record<number, {
        /**
         * Custom tick line style
         */
        linestyle?: LineStyle.Type;
    }>;
    /**
     * User-defined formatter function which provide a number as input, and expect a string as a return.
     */
    type FormatterFunction = (el: number) => string;
}
