/* eslint-disable */

export {_2t as PlaneLegendContainer} from '@int/impl/geotoolkit3d.js';
