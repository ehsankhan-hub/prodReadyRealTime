/* eslint-disable */

export {wKt as isObjectWithMaterial} from '@int/impl/geotoolkit3d.js';
