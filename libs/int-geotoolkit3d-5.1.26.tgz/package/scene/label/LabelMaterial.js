/* eslint-disable */

export {$0t as LabelMaterial} from '@int/impl/geotoolkit3d.js';
