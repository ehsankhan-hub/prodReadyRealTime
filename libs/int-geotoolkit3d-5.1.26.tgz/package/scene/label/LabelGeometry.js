/* eslint-disable */

export {s1t as LabelGeometry} from '@int/impl/geotoolkit3d.js';
