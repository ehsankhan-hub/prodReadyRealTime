/* eslint-disable */

export {E1t as Label} from '@int/impl/geotoolkit3d.js';
