/**
 * @module geotoolkit3d/scene/label/HorizontalAnchorPosition
 */
/**
 * Enum of Label horizontal anchor modes.<br>
 * Define the horizontal anchor point of the label in the view.
 * @enum
 * @readonly
 */
export declare enum HorizontalAnchorPosition {
    /**
     * Top
     * The label will be anchored by its left
     */
    Left = "left",
    /**
     * Bottom
     * The label will be anchored by its right
     */
    Right = "right",
    /**
     * Center
     * The label will be anchored by its center.
     */
    Center = "center"
}
