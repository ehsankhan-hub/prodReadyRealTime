/**
 * @module geotoolkit3d/scene/label/Label
 */
import { TextStyle } from '@int/geotoolkit/attributes/TextStyle';
import type { OrthographicCamera, Scene, Side, WebGLRenderer } from 'three';
import { Box3, PerspectiveCamera, Sphere, Vector2, Vector3 } from 'three';
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { VerticalAnchorPosition } from '@int/geotoolkit3d/scene/label/VerticalAnchorPosition';
import { HorizontalAnchorPosition } from '@int/geotoolkit3d/scene/label/HorizontalAnchorPosition';
import { OrientedBoundingBox } from '@int/geotoolkit3d/util/OrientedBoundingBox';
import type { Plot } from '@int/geotoolkit3d/Plot';
import type { Text2d } from '@int/geotoolkit3d/scene/Text2d';
/**
 * Label class
 */
export declare class Label extends Object3D {
    constructor(options: Label.Options);
    /**
     * Set minor label text style
     * @param textStyle a new major label text style
     * @param [merge] true if you want to merge textStyle with existing attribute, false by default
     * @returns this
     */
    setTextStyle(textStyle: TextStyle.Type, merge?: boolean): this;
    /**
     * The style associated with major labels
     * @returns text style
     */
    getTextStyle(): TextStyle | null;
    /**
     * Set text properties and options
     * @param options The options
     * @returns this
     */
    setOptions(options: Label.OptionsBase): this;
    /**
     * Compute or update this label's bounding box.
     * @deprecated since 5.0, bounding box will be computed automatically for each frame.
     */
    computeBoundingBox(): void;
    /**
     * Compute or update this label's bounding sphere.
     * @deprecated since 5.0, bounding sphere will be computed automatically for each frame.
     */
    computeBoundingSphere(): void;
    /**
     * Compute or update this label's oriented bounding box.
     * @deprecated since 5.0, oriented bounding box will be computed automatically for each frame.
     */
    computeOrientedBoundingBox(): void;
    /**
     * Return the bounding box of this label<br>
     * @returns box
     */
    getBoundingBox(): Box3;
    /**
     * Return the bounding sphere of this label.<br>
     * Calculated based on bounding box
     * @returns sphere
     */
    getBoundingSphere(): Sphere;
    /**
     * Return the oriented bounding box of this label.<br>
     * OBB is considered more accurate than standard bounding box or sphere.
     * @returns obb
     */
    getOrientedBoundingBox(): OrientedBoundingBox;
    /**
     * Update the text of this label.
     * @param text the text to set the label.
     */
    setText(text: string): void;
    /**
     * Return the text of this label
     * @returns text
     */
    getText(): string;
    beforeRender(scene: Scene, camera: PerspectiveCamera | OrthographicCamera, plot: Plot, renderer: WebGLRenderer): this;
    /**
     * Get the texture dimension of this label
     * @returns dimension
     */
    getTextureDimension(): Vector2;
    /**
     * Dispose this Label object
     */
    dispose(): void;
}
export declare namespace Label {
    /**
     * The options
     */
    type Options = OptionsBase & {
        /**
         * The canvas to use for the label texture rendering.
         * Multiple identical Label can reuse the same canvas to reduce memory usage.
         */
        canvas?: HTMLCanvasElement;
        /**
         * @deprecated
         * Label option.enabled is deprecated since 5.0. Please use the option 'visible' instead.
         * Set true to enable this label
         */
        enabled?: boolean;
        /**
         * The opacity of label
         */
        opacity?: number;
    };
    /**
     * The options
     */
    type OptionsBase = Omit<Object3D.Options, 'isselectable'> & Text2d.CommonOptions & {
        /**
         * The label side visibility, can be DoubleSide, FrontSide, BackSide
         */
        renderside?: Side;
        /**
         * @deprecated
         * label option.doublesided is deprecated since 5.0. Please use the option renderside instead.
         * if true, the label will be visible on both sides. If false, it'll only be visible if the normal is pointing toward camera.
         */
        doublesided?: boolean;
        /**
         * Define the coordinate of label position
         */
        origin?: Vector3 | number[];
        /**
         * Define the normal that determines the orientation of label. Default is facing X axis direction.
         */
        normal?: Vector3 | number[];
        /**
         * The scale of the label
         */
        scale?: Vector3;
        /**
         * If false, label is always vertical, rotate on Z axis to loosely match normal direction.
         * If true, label will be able to rotate on every axis to closely match normal direction.
         */
        freeorientation?: boolean;
        /**
         * If enforcetextupright is true, label text will try to never display upside-down by rotating the text 180° if necessary.
         */
        enforcetextupright?: boolean;
        /**
         * Define the offset on the label z axis (label facing direction).
         * Value is relative to apparent text height, so a value of 1 will offset the label by a distance equal to visible text height.
         */
        facingoffset?: number;
        /**
         * The vertical anchor position for the label (default is Center)
         */
        verticalanchor?: VerticalAnchorPosition;
        /**
         * The horizontal anchor position for the label (default is Center)
         */
        horizontalanchor?: HorizontalAnchorPosition;
    };
}
