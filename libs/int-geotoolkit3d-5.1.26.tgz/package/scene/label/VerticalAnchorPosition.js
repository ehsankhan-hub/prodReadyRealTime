/* eslint-disable */

export {_0t as VerticalAnchorPosition} from '@int/impl/geotoolkit3d.js';
