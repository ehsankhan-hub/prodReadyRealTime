/* eslint-disable */

export {a5t as TiledMap} from '@int/impl/geotoolkit3d.js';
