/* eslint-disable */

export {Y1t as CompassAxis} from '@int/impl/geotoolkit3d.js';
