/* eslint-disable */

export {WVt as CompassArrow} from '@int/impl/geotoolkit3d.js';
