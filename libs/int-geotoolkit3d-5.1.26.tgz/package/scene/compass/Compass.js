/* eslint-disable */

export {ZVt as Compass} from '@int/impl/geotoolkit3d.js';
