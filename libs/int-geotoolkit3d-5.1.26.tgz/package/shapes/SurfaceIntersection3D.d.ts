/**
 * @module geotoolkit3d/shapes/SurfaceIntersection3D
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { AbstractPanel } from '@int/geotoolkit3d/scene/panel/AbstractPanel';
import { Iterator } from '@int/geotoolkit/util/iterator';
import type { Surface } from '@int/geotoolkit3d/scene/surface/Surface';
export declare class SurfaceIntersection3D extends Object3D {
    constructor(options: SurfaceIntersection3D.Options);
    /**
     * Returns surface
     * @returns surface
     */
    getSurface(): Surface | null;
    /**
     * Set surface to intersect with specified panels
     * @param surface surface to intersect
     * @returns this
     */
    setSurface(surface: Surface): this;
    /**
     * Return iterator with panels intersected with Surface
     * @returns iterator with panels
     */
    getPanels(): Iterator<AbstractPanel> | null;
    /**
     * Set of panels to intersect with surface
     * @param panels set of panels to intersect with surface
     * @returns this
     */
    setPanels(panels: AbstractPanel | AbstractPanel[] | Iterator<AbstractPanel>): this;
    /**
     * Rebuild model
     * @returns this
     */
    rebuild(): this;
    /**
     * Update time stamp to indicate that Node or Children has been changed.
     * @returns this
     */
    protected updateTimeStamp(): this;
}
export declare namespace SurfaceIntersection3D {
    /**
     * Constructor options, where a few options are mandatory.
     */
    type Options = Object3D.Options & {
        /**
         * The surface to intersect
         */
        surface?: Surface;
        /**
         * The panels to intersect
         */
        panels?: AbstractPanel[] | Iterator<AbstractPanel> | AbstractPanel;
    };
}
