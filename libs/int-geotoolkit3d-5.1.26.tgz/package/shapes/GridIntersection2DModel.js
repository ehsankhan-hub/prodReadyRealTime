/* eslint-disable */

export {WZt as GridIntersection2DModel} from '@int/impl/geotoolkit3d.js';
