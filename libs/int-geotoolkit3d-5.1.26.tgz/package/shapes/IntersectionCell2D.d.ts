/**
 * @module geotoolkit3d/shapes/IntersectionCell2D
 */
import { Rect } from '@int/geotoolkit/util/Rect';
import { Iterator } from '@int/geotoolkit/util/iterator';
import type { FillStyle } from '@int/geotoolkit/attributes/FillStyle';
import type { LineStyle } from '@int/geotoolkit/attributes/LineStyle';
/**
 * Cell projection to 2D plane
 */
export declare class IntersectionCell2D {
    constructor(options?: IntersectionCell2D.Options);
    /**
     * Return clone
     * @returns clone
     */
    clone(): IntersectionCell2D;
    /**
     * Copy data from specified source
     * @param src source to copy from
     * @returns this
     */
    copyConstructor(src: IntersectionCell2D): this;
    /**
     * Returns index
     * @returns index
     */
    getIndex(): number;
    /**
     * Returns value
     * @returns value
     */
    getValue(): number;
    /**
     * Returns associated fill style
     * @returns fill style
     */
    getFillStyle(): FillStyle;
    /**
     * Set fill style
     * @param fillStyle fill style
     * @returns this
     */
    setFillStyle(fillStyle: FillStyle): this;
    /**
     * Returns associated line style
     * @returns line style
     */
    getLineStyle(): LineStyle;
    /**
     * Set line style
     * @param lineStyle line style
     * @returns this
     */
    setLineStyle(lineStyle: LineStyle): this;
    /**
     * Returns cell bounds
     * @returns cell bounds
     */
    getBounds(): Rect;
    /**
     * Clear inner triangles
     * @returns this
     */
    clearTriangles(): this;
    /**
     * Clear inner triangles
     * @returns triangles count
     */
    getTrianglesCount(): number;
    /**
     * Return iterator with inner triangles
     * @returns iterator with triangles
     */
    getTriangles(): Iterator<IntersectionCell2D.PolyShape>;
    /**
     * Add triangle
     * @param triangle triangle to add
     * @returns this
     */
    addTriangle(triangle: IntersectionCell2D.PolyShape): this;
    /**
     * Return cell path coordinates (combined from triangles)
     * @returns x and y coordinates
     */
    getCoordinates(): {
        x: number[];
        y: number[];
    };
    getClassName(): string;
    static getClassName(): string;
}
export declare namespace IntersectionCell2D {
    /**
     * polygon shape
     */
    type PolyShape = {
        /**
         * x-coordinates
         */
        x: number[];
        /**
         * y-coordinates
         */
        y: number[];
        /**
         * calculated shape bounds, for internal use
         */
        bounds?: Rect | null;
    };
    /**
     * cell options
     */
    type Options = {
        /**
         * cell index
         */
        index: number;
        /**
         * cell value
         */
        value: number;
        /**
         * cell bounds
         */
        bounds: Rect | null;
        /**
         * cell x-coordinates
         */
        x: number[] | null;
        /**
         * cell y-coordinates
         */
        y: number[] | null;
        /**
         * fillstyle
         */
        fillstyle?: FillStyle;
        /**
         * linestyle
         */
        linestyle?: LineStyle;
        /**
         * cell polygons
         */
        polygons: PolyShape[];
    };
}
