/* eslint-disable */

export {OZt as SurfaceIntersection2DModel} from '@int/impl/geotoolkit3d.js';
