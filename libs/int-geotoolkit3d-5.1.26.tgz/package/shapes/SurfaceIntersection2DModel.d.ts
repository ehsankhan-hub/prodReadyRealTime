import { PanelsIntersection2DModel } from '@int/geotoolkit3d/shapes/PanelsIntersection2DModel';
import type { Surface } from '@int/geotoolkit3d/scene/surface/Surface';
/**
 * Define surface and panels intersection model
 */
export declare class SurfaceIntersection2DModel extends PanelsIntersection2DModel {
    constructor(options?: SurfaceIntersection2DModel.Options);
    /**
     * Returns surface
     * @returns surface
     */
    getSurface(): Surface | null;
    /**
     * Set surface to intersect with panel
     * @param surface surface to intersect with panels
     * @returns this
     */
    setSurface(surface: Surface): this;
}
export declare namespace SurfaceIntersection2DModel {
    /**
     * Model properties
     */
    type Options = PanelsIntersection2DModel.Options & {
        /**
         * Surface for intersection
         */
        surface?: Surface;
    };
    /**
     * Model properties
     */
    type OptionsOut = PanelsIntersection2DModel.OptionsOut & {
        /**
         * Surface for intersection
         */
        surface: Surface | null;
    };
}
