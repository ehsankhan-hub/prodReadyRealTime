/**
 * @module geotoolkit3d/shapes/GridIntersection3D
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { AbstractPanel } from '@int/geotoolkit3d/scene/panel/AbstractPanel';
import { Iterator } from '@int/geotoolkit/util/iterator';
import type { ReservoirGrid } from '@int/geotoolkit3d/scene/reservoir/hexahedral/ReservoirGrid';
export declare class GridIntersection3D extends Object3D {
    constructor(options: GridIntersection3D.Options);
    /**
     * Returns grid
     * @returns grid reservoir grid
     */
    getGrid(): ReservoirGrid | null;
    /**
     * Set grid to intersect with panels
     * @param grid reservoir grid to intersect with panels
     * @returns this
     */
    setGrid(grid: ReservoirGrid): this;
    /**
     * Return iterator with panels intersected with Grid
     * @returns iterator with panels
     */
    getPanels(): Iterator<AbstractPanel> | null;
    /**
     * Set of panels to intersect with grid
     * @param panels set of panels to intersect with grid
     * @returns this
     */
    setPanels(panels: AbstractPanel | AbstractPanel[] | Iterator<AbstractPanel>): this;
    setHighlightedCells(indexes: number | number[]): this;
    getHighlightedCells(): number[];
    /**
     * Rebuild model
     * @returns this
     */
    rebuild(): this;
    /**
     * Update time stamp to indicate that Node or Children has been changed.
     * @returns this
     */
    protected updateTimeStamp(): this;
}
export declare namespace GridIntersection3D {
    /**
     * Constructor options, where a few options are mandatory.
     */
    type Options = Object3D.Options & {
        /**
         * The grid to intersect
         */
        grid?: ReservoirGrid;
        /**
         * The panels to intersect
         */
        panels?: AbstractPanel[] | Iterator<AbstractPanel> | AbstractPanel;
    };
}
