/* eslint-disable */

export {VZt as PanelsIntersection2D} from '@int/impl/geotoolkit3d.js';
