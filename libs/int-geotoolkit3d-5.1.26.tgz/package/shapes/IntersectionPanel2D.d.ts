import { Iterator } from '@int/geotoolkit/util/iterator';
import { Rect } from '@int/geotoolkit/util/Rect';
import type { IntersectionCell2D } from '@int/geotoolkit3d/shapes/IntersectionCell2D';
/**
 * Intersection projection to 2D, can contain different type of intersection geometries, such as cells, lines and paths
 */
export declare class IntersectionPanel2D {
    constructor(options?: IntersectionPanel2D.Options);
    /**
     * Return clone
     * @returns clone
     */
    clone(): IntersectionPanel2D;
    /**
     * Copy data from specified source
     * @param src source to copy from
     * @returns this
     */
    copyConstructor(src: IntersectionPanel2D): this;
    /**
     * Returns panel bounds in model coordinate system
     * @returns panel bounds
     */
    getBounds(): Rect;
    /**
     * Returns panel inner model limits
     * @returns panel inner model limits
     */
    getModelLimits(): Rect;
    /**
     * Returns inner grid model limits, in panel model coordinates
     * @returns panel inner grid model limits
     */
    getGridLimits(): Rect;
    /**
     * Clear cells
     * @returns this
     */
    clearCells(): this;
    /**
     * Return cells count
     * @returns cells count
     */
    getCellsCount(): number;
    /**
     * Return cell by specified index
     * @param index index of cell
     * @returns cell
     */
    getCell(index: number): IntersectionCell2D;
    /**
     * Return iterator with inner cells
     * @returns iterator with cells
     */
    getCells(): Iterator<IntersectionCell2D>;
    /**
     * Add cell
     * @param cell cell to add
     * @returns this
     */
    addCell(cell: IntersectionCell2D): this;
    /**
     * Clear horizons
     * @returns this
     */
    clearHorizons(): this;
    /**
     * Return horizons count
     * @returns horizons count
     */
    getHorizonsCount(): number;
    /**
     * Return horizon by specified index
     * @param index index of horizon
     * @returns horizon
     */
    getHorizon(index: number): IntersectionPanel2D.Horizon;
    /**
     * Return horizons
     * @returns horizons
     */
    getHorizons(): Iterator<IntersectionPanel2D.Horizon>;
    /**
     * Add horizon
     * @param horizon horizon to add
     * @returns this
     */
    addHorizon(horizon: IntersectionPanel2D.Horizon): this;
    getClassName(): string;
    static getClassName(): string;
}
export declare namespace IntersectionPanel2D {
    /**
     * Horizon intersection
     */
    type Horizon = {
        /**
         * x-coordinates
         */
        x: number[];
        /**
         * y-coordinates
         */
        y: number[];
        /**
         * voxel-color
         */
        colors: string[];
    };
    /**
     * The panel information
     */
    type Options = {
        /**
         * The calculated grid limits, for internal use
         */
        gridlimits?: Rect;
        /**
         * The panel bounds
         */
        bounds?: Rect;
        /**
         * The panel grid model limits
         */
        modellimits?: Rect;
        /**
         * The grid cells
         */
        cells?: IntersectionCell2D[];
        /**
         * The intersection horizon segments
         */
        horizons?: IntersectionPanel2D.Horizon[];
    };
}
