import { NodeTooltip } from '@int/geotoolkit/controls/tooltip/NodeTooltip';
import type { Point } from '@int/geotoolkit/util/Point';
import type { ToolTipRegistry } from '@int/geotoolkit/controls/tooltip/ToolTipRegistry';
import type { PanelsIntersection2D } from '@int/geotoolkit3d/shapes/PanelsIntersection2D';
/**
 * Default Formats
 * @readonly
 * @enum
 */
export declare enum DefaultFormat {
    Visual = "${symbol}${name} <b>${index}</b>&nbsp;<i>${value}</i>"
}
/**
 * A tooltip utility class for 2D grid intersection results.
 */
export declare class GridIntersection2DTooltip extends NodeTooltip {
    constructor(format?: string | NodeTooltip.ToolTipFormatter);
    hitTest(visual: PanelsIntersection2D, pt: Point | null, registry?: ToolTipRegistry, options?: Record<string, any>): GridIntersection2DTooltip.ToolTipInfo;
    getTooltip(visual: PanelsIntersection2D, pt: Point | null, registry: ToolTipRegistry, options?: Record<string, any>): string;
}
export declare namespace GridIntersection2DTooltip {
    /**
     * JSON object, information that ToolTip instance class can collect for specific visual at specific point
     */
    type ToolTipInfo = NodeTooltip.ToolTipInfo & {
        /**
         * intersection type
         */
        type?: 'cell' | 'horizon';
        /**
         * visual description
         */
        description?: string;
        /**
         * tooltip color
         */
        color?: string;
        /**
         * tooltip symbol
         */
        symbol?: string;
        /**
         * tooltip depth/index value
         */
        index?: number;
        /**
         * tooltip value
         */
        value?: number;
        /**
         * x-model value
         */
        x?: number;
        /**
         * y-model value
         */
        y?: number;
    };
    /**
     * options which contains tooltip properties
     */
    type Properties = NodeTooltip.Properties & {};
    /**
     * options which contains tooltip properties
     */
    type PropertiesOut = NodeTooltip.PropertiesOut & {};
}
