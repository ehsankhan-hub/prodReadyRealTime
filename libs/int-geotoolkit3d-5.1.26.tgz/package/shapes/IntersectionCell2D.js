/* eslint-disable */

export {zZt as IntersectionCell2D} from '@int/impl/geotoolkit3d.js';
