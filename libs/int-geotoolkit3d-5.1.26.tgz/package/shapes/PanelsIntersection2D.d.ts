import { Rect } from '@int/geotoolkit/util/Rect';
import { RectangularShape } from '@int/geotoolkit/scene/shapes/RectangularShape';
import { Point } from '@int/geotoolkit/util/Point';
import type { RenderingContext } from '@int/geotoolkit/renderer/RenderingContext';
import type { PanelsIntersection2DModel } from '@int/geotoolkit3d/shapes/PanelsIntersection2DModel';
import type { IntersectionPanel2D } from '@int/geotoolkit3d/shapes/IntersectionPanel2D';
/**
 * Defines planar intersection visual to represent ReservoirGrid intersection with panel-based objects like Fence or PlaneCurtain in 2D plot
 */
export declare class PanelsIntersection2D extends RectangularShape {
    constructor(options?: PanelsIntersection2D.Options);
    clone(): PanelsIntersection2D;
    protected copyConstructor(src: PanelsIntersection2D, deepCopy?: boolean): this;
    /**
     * Returns intersection model
     * @returns intersection model
     */
    getModel(): PanelsIntersection2DModel;
    /**
     * Set intersection model
     * @param model intersection model
     * @returns this
     */
    setModel(model: PanelsIntersection2DModel): this;
    /**
     * Highlight panels
     * @param highlight panels to highlight
     * @returns this
     */
    setHighlight(highlight: IntersectionPanel2D[]): this;
    /**
     * Return panels model space
     * @returns panels model space
     */
    getModelLimits(): Rect;
    render(context: RenderingContext): void;
    /**
     * Hit test symbols of the curve in the device coordinates
     * @param area model area or position
     * @param [radius] radius of selection
     * @returns a collection of selected symbols indices
     */
    hitTest(area: Rect | Point, radius?: number): IntersectionPanel2D[];
    /**
     * Gets all the properties pertaining to this object
     * @returns properties
     */
    getProperties(): PanelsIntersection2D.OptionsOut;
    /**
     * Sets all the properties pertaining to this object
     * @param [properties] object containing the properties to set
     */
    setProperties(properties?: PanelsIntersection2D.Options): this;
}
export declare namespace PanelsIntersection2D {
    /**
     * Shape properties
     */
    type Options = RectangularShape.Options & {
        /**
         * Intersection model
         */
        model?: PanelsIntersection2DModel;
    };
    /**
     * Shape properties
     */
    type OptionsOut = RectangularShape.OptionsOut & {
        /**
         * Intersection model
         */
        model: PanelsIntersection2DModel;
    };
}
