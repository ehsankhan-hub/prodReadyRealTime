/* eslint-disable */

export {UZt as IntersectionPanel2D} from '@int/impl/geotoolkit3d.js';
