/**
 * @module geotoolkit3d/shapes/PanelsIntersection2DModel
 */
import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
import { Rect } from '@int/geotoolkit/util/Rect';
import { Iterator } from '@int/geotoolkit/util/iterator';
import { AbstractPanel } from '@int/geotoolkit3d/scene/panel/AbstractPanel';
import type { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { Intersection3DUtil } from '@int/geotoolkit3d/util/intersection/Intersection3DUtil';
import type { IntersectionPanel2D } from '@int/geotoolkit3d/shapes/IntersectionPanel2D';
/**
 * Intersection model Events enumerator
 * @readonly
 * @enum
 */
export declare enum Events {
    /**
     * Event type fired when a model is modified and requires a render cycle to be done
     */
    Changed = "Changed",
    /**
     * Event type fired when a model is ready
     */
    Ready = "Ready"
}
/**
 * Define panels intersection model
 */
export declare class PanelsIntersection2DModel extends EventDispatcher {
    constructor(options?: PanelsIntersection2DModel.Options);
    /**
     * Gets onDispose event handler
     * @returns method to handle dispose event
     */
    protected getOnDisposedHandler(): (event: string, sender: Object3D) => void;
    /**
     * Gets onPropertyChanged event handler
     * @returns method to handle property changed event
     */
    protected getOnPropertyChangedHandler(): (event: string, sender: Object3D, eventArgs: any) => void;
    /**
     * This method is called when one of the referenced object changed it properties.  Send event {@link @int/geotoolkit3d/scene/Object3D~Events.PropertyChanged}
     * @param object changed object
     * @param properties object properties
     */
    protected onObjectPropertyChanged(object: Object3D, properties?: string | {
        name: string;
        value: any;
    }): void;
    /**
     * This method is called when one of the referenced object was disposed.  Send event {@link @int/geotoolkit3d/scene/Object3D~Events.Disposed}
     * @param object disposed object
     */
    protected onObjectDisposed(object: Object3D): void;
    on<E extends keyof PanelsIntersection2DModel.EventMap>(type: E, callback: (eventType: E, sender: this, args: PanelsIntersection2DModel.EventMap[E]) => void): this;
    off<E extends keyof PanelsIntersection2DModel.EventMap>(type?: E, callback?: (eventType: E, sender: this, args: PanelsIntersection2DModel.EventMap[E]) => void): this;
    /**
     * Update time stamp to indicate that Node or Children has been changed.
     * @returns this
     */
    protected updateTimeStamp(): this;
    /**
     * Return model limits
     * @returns model limits
     */
    getModelLimits(): Rect;
    /**
     * Return iterator with panels intersected with Grid
     * @returns iterator with panels
     */
    getPanels(): Iterator<AbstractPanel> | null;
    /**
     * Set of panels to intersect with grid
     * @param panels set of panels to intersect with grid
     * @returns this
     */
    setPanels(panels: AbstractPanel | AbstractPanel[] | Iterator<AbstractPanel>): this;
    protected handleIntersectionConversion(result3D: Intersection3DUtil.Result, plane: Intersection3DUtil.PlaneObject, offset: number): IntersectionPanel2D;
    protected buildIntersectionModel(): Promise<IntersectionPanel2D[]>;
    /**
     * Return iterator by projections
     * @returns iterator by projections
     */
    getProjections(): Iterator<IntersectionPanel2D>;
    /**
     * Return 2D projections count
     * @returns projections count
     */
    getProjectionsCount(): number;
    /**
     * Return 2D panel projection by specified index
     * @param index projection index
     * @returns 2D projection
     */
    getProjection(index: number): IntersectionPanel2D | null;
    /**
     * Rebuild model
     * @returns this
     */
    rebuild(): this;
}
export declare namespace PanelsIntersection2DModel {
    /**
     * Model properties
     */
    type Options = {
        /**
         * Panels for intersection
         */
        panels?: AbstractPanel | AbstractPanel[] | Iterator<AbstractPanel> | null;
    };
    /**
     * Model properties
     */
    type OptionsOut = {
        /**
         * Panels for intersection
         */
        panels: Iterator<AbstractPanel> | null;
    };
    type EventMap = EventDispatcher.EventMap & {
        /**
         * Event type fired when a model is modified and requires a render cycle to be done
         */
        [Events.Changed]: void;
        /**
         * Event type fired when a model is ready
         */
        [Events.Ready]: void;
    };
}
