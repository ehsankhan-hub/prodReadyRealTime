import { PanelsIntersection2DModel } from '@int/geotoolkit3d/shapes/PanelsIntersection2DModel';
import type { Iterator } from '@int/geotoolkit/util/iterator';
import type { AbstractPanel } from '@int/geotoolkit3d/scene/panel/AbstractPanel';
import type { ReservoirGrid } from '@int/geotoolkit3d/scene/reservoir/hexahedral/ReservoirGrid';
/**
 * Define grid and panels intersection model
 */
export declare class GridIntersection2DModel extends PanelsIntersection2DModel {
    constructor(options?: GridIntersection2DModel.Options);
    /**
     * Returns grid
     * @returns grid reservoir grid
     */
    getGrid(): ReservoirGrid | null;
    /**
     * Set grid to intersect with panel
     * @param grid reservoir grid to intersect with panel
     * @returns this
     */
    setGrid(grid: ReservoirGrid): this;
}
export declare namespace GridIntersection2DModel {
    /**
     * Model properties
     */
    type Options = PanelsIntersection2DModel.Options & {
        /**
         * Grid for intersection
         */
        grid?: ReservoirGrid;
    };
    /**
     * Model properties
     */
    type OptionsOut = PanelsIntersection2DModel.Options & {
        /**
         * Panels for intersection
         */
        panels: Iterator<AbstractPanel> | null;
        /**
         * Grid for intersection
         */
        grid: ReservoirGrid | null;
    };
}
