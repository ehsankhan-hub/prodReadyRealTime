/* eslint-disable */

export {JVt as IntersectionManager} from '@int/impl/geotoolkit3d.js';
