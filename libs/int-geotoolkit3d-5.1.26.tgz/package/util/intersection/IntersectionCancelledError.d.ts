/**
 * IntersectionCancelledError<br>
 * This error is thrown if the queued intersection is cancelled.
 */
export declare class IntersectionCancelledError extends Error {
    getClassName(): string;
    static getClassName(): string;
}
