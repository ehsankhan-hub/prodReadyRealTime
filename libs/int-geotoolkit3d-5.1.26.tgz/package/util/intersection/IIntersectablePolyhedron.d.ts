import type { Box3, Mesh } from 'three';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import type { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
/**
 * Define an interface to provide a way to retrieve intersection related data from a object formed by one or more polyhedrons like ReservoirGrid.<br>
 * 3D Objects implementing this interface will now be eligible for 3D intersection, via the {@link @int/geotoolkit3d/util/intersection/Intersection3DUtil~Intersection3DUtil} utility.
 * @interface
 */
export declare abstract class IIntersectablePolyhedron {
    /**
     * Return the mesh representing the polyhderons to be intersected.
     */
    abstract getMesh(): Mesh;
    /**
     * Return the polyhedron data at given index.<br>
     * Vertices coordinates must be in the local coordinate space of the mesh returned by getMesh method.
     * @param polyhedronIndex the index of the polyhedron
     * @param target result
     */
    abstract getPolyhedron(polyhedronIndex: number, target: IIntersectablePolyhedron.PolyhedronCellData): void;
    /**
     * Return if the polyhedron at given index is filtered out.<br>
     * Polyhedron objects like ReservoirGrid can contain multiple polyhedrons, which can be filtered out by user settings. <br>
     * This method allow to express whether this specific polyhedron is filtered out (and should be excluded from intersection).
     * @param polyhedronIndex
     * @returns true if filtered out, otherwise false
     */
    abstract isPolyhedronIndexFilteredOut(polyhedronIndex: number): boolean;
    /**
     * Return the total number of Polyhedrons contained by this object.
     */
    abstract getPolyhedronCount(): number;
    /**
     * Return the bounding box of the polyhedrons.<br>
     * The bounding box should be calculated directly from the polyhedrons' geometry vertex positions, representing the bounding box in the polyhedrons' local space.<br>
     * The box coordinates must be in the local coordinate space of the mesh returned by getMesh method.
     * @param target result
     */
    abstract getPolyhedronsBoundingBox(target: Box3): void;
    /**
     * Return the color provider of the intersectable.
     */
    abstract getColorProvider(): ColorProvider | RgbaColor;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace IIntersectablePolyhedron {
    /**
     * The target data structure where the user can store the cell's polyhedron points.
     * If a cell polyhedron is concave, it is required to split it into multiple convex sub-polyhedrons, since the intersection algorithm only supports convex shapes.
     */
    type PolyhedronCellData = {
        /**
         * The array of sub polyhedrons. If the cell is convex, the array can contain the whole cell as a single polyhedron.
         * But if the cell is concave, it is required to split and provide the cell as individual convex sub-polyhedron.
         */
        convexpolyhedrons?: ConvexPolyhedron[];
        /**
         * The cell polyhedron property value (if applicable).
         */
        value?: number;
    };
    /**
     * The cell's polyhedron (or sub-polyhedron) points, must be convex to generate a correct intersection result.<br>
     * Each polyhedron point only need to be provided once, the algorithm will form the convex hull shape automatically.<br>
     * A correct polyhedron shape need at least 4 points.
     */
    type ConvexPolyhedron = {
        /**
         * The x coordinates of the polyhedron's vertices.<br>
         * Vertices coordinates must be in the local coordinate space of the object inheriting this interface.
         */
        x: number[];
        /**
         * The y coordinates of the polyhedron's vertices.<br>
         * Vertices coordinates must be in the local coordinate space of the object inheriting this interface.
         */
        y: number[];
        /**
         * The z coordinates of the polyhedron's vertices.<br>
         * Vertices coordinates must be in the local coordinate space of the object inheriting this interface.
         */
        z: number[];
    };
}
