/* eslint-disable */

export {YHt as IIntersectablePolyhedron} from '@int/impl/geotoolkit3d.js';
