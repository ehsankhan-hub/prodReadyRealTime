/* eslint-disable */

export {WJt as IIntersectableMesh} from '@int/impl/geotoolkit3d.js';
