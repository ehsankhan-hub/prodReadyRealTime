/* eslint-disable */

export {GXt as IntersectionNotSupportedError} from '@int/impl/geotoolkit3d.js';
