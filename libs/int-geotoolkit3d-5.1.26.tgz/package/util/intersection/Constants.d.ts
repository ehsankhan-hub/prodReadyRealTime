/**
 * @module geotoolkit3d/util/intersection/Constants
 */
/**
 * Color provider name.<br>
 * This enum is used to describe which color provider to use.
 * @enum
 * @readonly
 */
export declare enum ColorProviderName {
    /**
     * Use objectA's color provider
     */
    ObjectA = "ObjectA",
    /**
     * Use objectB's color provider
     */
    ObjectB = "ObjectB"
}
/**
 * Value provider name.<br>
 * This enum is used to describe which value to use.
 * @enum
 * @readonly
 */
export declare enum ValueName {
    /**
     * Use value from object A
     */
    ObjectA = "ObjectA",
    /**
     * Use value from object B
     */
    ObjectB = "ObjectB",
    /**
     * Ignore intersection values for intersection visual color (for solid color mode usage, or if objects lack values).
     * If a color provider/colorMap is still defined, default values '0' will be used instead.
     */
    NoValues = "NoValues"
}
/**
 * Type of the intersection result.<br>
 * @enum
 * @readonly
 */
export declare enum ResultType {
    /**
     * Result of intersected meshes.
     */
    MeshMesh = "MeshMesh",
    /**
     * Result of intersected mesh and polyhedron.
     */
    MeshPolyhedron = "MeshPolyhedron"
}
