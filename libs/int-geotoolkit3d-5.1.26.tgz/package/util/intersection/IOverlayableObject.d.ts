/**
 * @module geotoolkit3d/util/intersection/IOverlayableObject
 */
import type { Group } from '@int/geotoolkit/scene/Group';
import type { Rect } from '@int/geotoolkit/util/Rect';
import type { Mesh, Vector3 } from 'three';
/**
 * Define an interface for 3D object with overlay capabilities.<br>
 * Overlayable objects should have a rectangular coplanar shape, that can be deduced by using the .getCorner() method.<br>
 * This interface is intended for internal usage only.
 * @interface
 */
export declare abstract class IOverlayableObject {
    /**
     * Return the current 2D Shape group used to render the overlay.
     */
    abstract getOverlay(): Group | null;
    /**
     * Set the current 2D Shape group used to render the overlay.
     */
    abstract setOverlay(group: Group): void;
    /**
     * Return the overlay texture bounds, (unit is in pixel).
     */
    abstract getOverlayTextureBounds(): Rect;
    /**
     * Return the world position of a specific corner of this overlayable (rectangular) object.<br>
     * @param index Index of the corner, from 0 to 3.
     * @param target Optional point Vector3 to avoid unnecessary object creation. Will be updated and returned if provided.
     * @example
     * The indices represent the 4 corners of the overlayable object like so:
     * 0---1
     * |   |
     * 2---3
     */
    abstract getCorner(index: number, target?: Vector3): Vector3;
    /**
     * Return the local position of a specific corner of this overlayable (rectangular) object.<br>
     * @param index Index of the corner, from 0 to 3.
     * @param target Optional point Vector3 to avoid unnecessary object creation. Will be updated and returned if provided.
     * @example
     * The indices represent the 4 corners of the overlayable object like so:
     * 0---1
     * |   |
     * 2---3
     */
    abstract getLocalCorner(index: number, target?: Vector3): Vector3;
    /**
     * Return the Three.js Mesh of this overlayable object.<br>
     * Used in intersections to compute the object boundaries, to generate transformations for the overlay.
     */
    abstract getMesh(): Mesh;
    static getClassName(): string;
    getClassName(): string;
}
