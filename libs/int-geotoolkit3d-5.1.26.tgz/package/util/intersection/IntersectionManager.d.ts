/**
 * @module geotoolkit3d/util/intersection/IntersectionManager
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
import { FillStyle } from '@int/geotoolkit/attributes/FillStyle';
import { LineStyle } from '@int/geotoolkit/attributes/LineStyle';
/**
 * IntersectionManager class handles and keeps track of intersection-related features.
 * A default global instance of this class is created and used.
 */
export declare class IntersectionManager extends EventDispatcher {
    constructor();
    /**
     * Returns default instance of the IntersectionManager
     * @returns this
     */
    static getDefaultInstance(): IntersectionManager;
    /**
     * Set the intersectionManager automatic behavior.
     * Default is true.
     * When a pair of intersecting object have either of its 2 objects move since the last redraw, they become invalidated.
     * When set to true, the invalidated intersection is cleared and redrawn.
     * When set to false, the invalidated intersection is only cleared.
     * When automatic redraw is disabled, the manual way to update an intersection is to call generateIntersection() again.
     */
    setAutoRedraw(auto: boolean): void;
    /**
     * Return if automatic redraw is enabled. See setAutoRedraw for more information.
     */
    isAutoRedrawEnabled(): boolean;
    /**
     * Return true if the provided pair of objects can be used to create a new intersection.
     * @param planeObject the plane object that has overlay support (or one of its parents)
     * @param meshObject the object that intersects the plane object
     * @returns {boolean} if the pair is eligible or not.
     */
    elligibleForIntersection(planeObject: Object3D, meshObject: Object3D): boolean;
    /**
     * Draw intersections between the plane object and the intersecting object, with provided options.
     * @param planeObject the plane object that has overlay support (or one of its parents)
     * @param meshObject the object that intersects the plane object
     * @param [options] the options for intersection
     */
    generateIntersection(planeObject: Object3D, meshObject: Object3D, options?: IntersectionManager.PlaneMeshIntersectionOptions): void;
    /**
     * Remove the intersection between the given plane and mesh objects. <br>
     * User should call this if the intersection is no longer needed to avoid memory leaks, as the intersection
     * manager is a singleton, and keeps references to both objects until the intersection is removed.
     * @param planeObject the plane object that has overlay support
     * @param meshObject the mesh object that intersects the plane object
     */
    removeIntersection(planeObject: Object3D, meshObject: Object3D): void;
    /**
     * Set the options for intersection.<br>
     * Using this method can change intersection's properties without re-calculating intersecting points.
     * Note if the position of intersection has changed, use generateIntersection instead.
     * @param planeObject the plane object that has overlay support
     * @param meshObject the object that intersects the plane object
     * @param properties the intersection properties
     */
    setPropertyByIntersection(planeObject: Object3D, meshObject: Object3D, properties: IntersectionManager.PlaneMeshIntersectionOptions): void;
    /**
     * Returns true, if intersection exists
     * @param planeObject the plane object that has overlay support
     * @param meshObject the object that intersects the plane object
     * @returns true if intersection exists
     */
    isIntersectionExists(planeObject: Object3D, meshObject: Object3D): boolean;
    /**
     * Returns true if matrix world has changed. Otherwise, return false.
     */
    isMatrixWorldChange(): boolean;
    /**
     * Return the map of relationship between plane objects and the mesh(es) they intersect.
     * Map <planeuuid: string, meshessuuidSet: Set<string>>
     */
    getPlaneMap(): Map<string, Set<string>>;
    /**
     * Return the map of relationship between mesh objects and the plane(s) they intersect.
     * Map <meshuuid: string, planesuuidSet: Set<string>>
     */
    getMeshMap(): Map<string, Set<string>>;
    /**
     * Returns the map of all objects being part of intersections.
     * Key are objects's UUID, value is the object itself.
     */
    getObjectMap(): Map<string, {
        object: Object3D;
        matrixworld: number[];
    }>;
    /**
     * Set the time interval in millisecond between each intersection update.
     * Default is 100ms (10 times per second).
     * A smaller interval allow more frequent intersection update, but also require more CPU resources and can cause stuttering on low end machines.<br>
     * Lower-end devices can benefit from lowering this value even further than the default value.<br>
     * The minimum accepted interval is 16.6ms (60 time per seconds).
     */
    setAutoUpdateInterval(interval: number): void;
    /**
     * Get the time interval in millisecond between each intersection update.
     */
    getAutoUpdateInterval(): number;
    /**
     * Dispose the instance and its properties.
     */
    dispose(): void;
}
export declare namespace IntersectionManager {
    /**
     * Options for intersections of type Plane-Mesh.
     */
    type PlaneMeshIntersectionOptions = {
        /**
         * If this intersection should be visible or not. Default is true.
         */
        visible?: boolean;
        /**
         * The line width, if the intersection is of line shape
         */
        linewidth?: number;
        /**
         * The line style for drawing the intersection lines (such as Surface intersections).
         */
        linestyle?: LineStyle.Type;
        /**
         * The fill style for drawing the intersection fillings. (such as Reservoir intersections.)<br>
         * Can be used to color lines if 'linestyle' is not defined.
         */
        fillstyle?: FillStyle.Type;
        /**
         * The flag to preserve the intersecting object's colors on intersections.<br>
         * If true, the intersected object (surface, reservoir) will be used to determine the intersection colors.<br>
         * If false, the defined 'linestyle' and 'fillstyle' option will be used instead.
         */
        preservecolor?: boolean;
    };
}
