/* eslint-disable */

export {jWt as Intersection} from '@int/impl/geotoolkit3d.js';
