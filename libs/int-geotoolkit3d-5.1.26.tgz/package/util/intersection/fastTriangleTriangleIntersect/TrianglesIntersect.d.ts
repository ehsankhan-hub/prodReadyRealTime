/**
 * Intersection type.<br>
 * This enum is used to describe the type of intersection.
 * @enum
 * @readonly
 */
export declare enum Intersection {
    Cross = "Cross",
    Coplanar = "Coplanar"
}
