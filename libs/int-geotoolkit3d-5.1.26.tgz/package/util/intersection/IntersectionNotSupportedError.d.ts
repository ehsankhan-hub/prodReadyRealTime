/**
 * IntersectionNotSupportedError<br>
 * This error is thrown if the objects provided to the Intersection3DUtil.intersectObjects are not supported for intersection.
 */
export declare class IntersectionNotSupportedError extends Error {
    getClassName(): string;
    static getClassName(): string;
}
