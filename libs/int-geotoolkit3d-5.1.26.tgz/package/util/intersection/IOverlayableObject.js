/* eslint-disable */

export {YVt as IOverlayableObject} from '@int/impl/geotoolkit3d.js';
