/**
 * NoIntersectableError<br>
 * This error is thrown if any of the objects provided to the Intersection3DUtil.intersectObjects method lacks an intersectable component like a mesh or doesn't implement an intersection interface such as IIntersectableMesh.
 */
export declare class NoIntersectableError extends Error {
    getClassName(): string;
    static getClassName(): string;
}
