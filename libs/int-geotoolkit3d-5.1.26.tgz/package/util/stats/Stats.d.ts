export declare namespace Stats {
    type Options = {
        /**
         * How often to log performance data, in logs per second.<br>
         * Default 20.
         */
        logsPerSecond?: number;
        /**
         * Number of recent samples gathered to compute the average and range values on the panel.<br>
         * Default 100.
         */
        samplesLog?: number;
        /**
         * Number of recent samples used to define the min/max range in the graph drawing.<br>
         * Default 10.
         */
        samplesGraph?: number;
        /**
         * Precision of the data, in number of decimal places (only affects CPU and GPU milliseconds panels).<br>
         * Default 2
         */
        precision?: number;
        /**
         * If True, display the canvases on the X axis, false to align on vertical axis.<br>
         * Default true
         */
        horizontal?: boolean;
        /**
         * Optional offset to manually position the panel using absolute positioning.<rb>
         * Values represent pixel offsets from the top-left corner of the canvas.
         */
        positionoffset?: {
            /**
             * Distance in pixels from the top edge.<rb>
             * Default is 0.
             */
            top?: number;
            /**
             * Distance in pixels from the left edge.<br>
             * Default is 0.
             */
            left?: number;
        };
    };
}
