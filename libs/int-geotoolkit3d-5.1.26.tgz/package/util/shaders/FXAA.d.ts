/**
 * @author mrdoob / http://mrdoob.com/
 * @see https://github.com/mrdoob/three.js/blob/master/examples/jsm/shaders/FXAAShader.js
 * Modification in this imported shader:
 * - Chage value of edgeDetectionQuality for a better anti-aliasing performance
 */
import { Uniform, Vector2 } from 'three';
/**
 * Shaders for FXAA Anti-Aliasing
 */
export declare class FXAA {
    static FXAAShader: {
        uniforms: {
            resolution: Uniform<Vector2>;
            tDiffuse: Uniform<any>;
        };
        vertexShader: string;
        fragmentShader: string;
    };
}
