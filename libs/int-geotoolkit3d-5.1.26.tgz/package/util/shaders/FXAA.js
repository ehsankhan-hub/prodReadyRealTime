/* eslint-disable */

export {iqt as FXAA} from '@int/impl/geotoolkit3d.js';
