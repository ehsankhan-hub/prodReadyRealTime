/* eslint-disable */

export {h0t as LabelShaders} from '@int/impl/geotoolkit3d.js';
