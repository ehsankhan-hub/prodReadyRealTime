/**
 * @module geotoolkit3d/util/Class
 */
import type { Object3D } from '@int/geotoolkit3d/scene/Object3D';
/**
 * Utility class handling general operations relating to geotoolkit3D's classes.. </br>
 */
export declare class Class {
    /**
     * Retrieve the class name of the object not knowing if it is a toolkit class or THREE.js class
     * @param object The object whose class name is needed
     * @param short If the short version of the class name is required.
     * @returns Class name
     */
    static getObjectClassName(object: Class.NamedObject, short?: boolean): string;
}
export declare namespace Class {
    export type NamedObject = Object3D | ThreeObject;
    type ThreeObject = {
        name: string;
        type: string;
    };
    export {};
}
