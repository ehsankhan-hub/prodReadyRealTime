/* eslint-disable */

export {nPt as Class} from '@int/impl/geotoolkit3d.js';
