/**
 * Utility class providing WebGL rendering capabilities and information.<br>
 */
export declare class WebGLConstants {
    /**
     * Get the WebGL maximum texture size this browser/device can theoretically use (not taking memory usage into account)
     * @returns size
     */
    static getMaxTextureSize(): number;
    /**
     * Get the WebGL maximum number of textures
     * @returns maxTextures number
     */
    static getMaxTextures(): number;
    /**
     * Check if the browser supports WebGL 1.0
     * @returns webgl
     */
    static webgl(): boolean;
    /**
     * Check if it is intel graphic card
     * @returns isIntelGPU
     */
    static isIntelGPU(): boolean | null;
    /**
     * Check if the browser supports WebGL 2.0
     * @returns isWebGL2
     */
    static isWebGL2(): boolean;
    /**
     * Return the list of supported Textures/RenderTarget types.<br>
     * While the traditional UnsignedByte format textures are widely supported, some Float-based textures might not be supported on all hardware/browser combinations.<br>
     * This utility class performs an actual test to make sure these types are supported, which is more reliable than just consulting WebGL extensions.
     */
    static getSupportedRenderTargetTypes(): WebGLConstants.SupportedRenderTargetType;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace WebGLConstants {
    /**
     * The various WebGL extensions required for 3D features to work.<br>
     * The boolean along each extension indicates if this extension is supported or not.<br>
     * When an extension is not supported, the associated features/visuals might be limited, or will not render, but should not crash.
     * @private
     */
    type Gl2Extensions = {
        /**
         * Allow using THREE.LinearFilter (bi-linear interpolation) alongside THREE.FloatType data textures.<br>
         * Is currently needed for Volume rendering linear and cubic filtering and colormap texture.<br>
         * iOS devices are known to not support this extension (iPad 10th gen, iOS 17.5, tested on 11 June 2024).
         */
        OES_texture_float_linear: boolean;
        /**
         * Allow using Stats GPU frame time and GPUBenchmark.startScoreBenchmark.<br>
         * Is currently needed for plot3d and GPUBenchmark to get gpu performance, and adaptive sampling feature of volume rendering. <br>
         * iOS devices are known to not support this extension (iPad 10th gen, iOS 17.5, tested on 11 June 2024).
         */
        EXT_disjoint_timer_query_webgl2: boolean;
    };
    /**
     * Supported texture and render target types.
     */
    type SupportedRenderTargetType = {
        /**
         * Texture/RenderTarget using Float 32bit format for each color channel, with mere Nearest filtering support.<br>
         * It doesn't guarantee Linear filtering support, please check FloatLinear if required.
         */
        FloatNearest: boolean;
        /**
         * Texture/RenderTarget using Float 32bit format for each color channel, with Linear filtering support (implicitly support Nearest Filter too).
         */
        FloatLinear: boolean;
        /**
         * Texture/RenderTarget using Float 16bit format for each color channel, with mere Nearest filtering support.<br>
         * It doesn't guarantee Linear filtering support, please check HalfFloatLinear if required.
         */
        HalfFloatNearest: boolean;
        /**
         * Texture/RenderTarget using Float 16bit format for each color channel, with Linear filtering support (implicitly support Nearest Filter too).
         */
        HalfFloatLinear: boolean;
    };
}
