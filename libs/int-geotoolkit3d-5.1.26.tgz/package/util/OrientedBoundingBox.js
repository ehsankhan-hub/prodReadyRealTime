/* eslint-disable */

export {xJt as OrientedBoundingBox} from '@int/impl/geotoolkit3d.js';
