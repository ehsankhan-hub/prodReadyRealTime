/* eslint-disable */

export {XYt as Attributes} from '@int/impl/geotoolkit3d.js';
