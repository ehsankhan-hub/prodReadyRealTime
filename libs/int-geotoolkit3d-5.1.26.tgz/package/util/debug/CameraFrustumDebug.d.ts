import { Color } from 'three';
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { Plot } from '@int/geotoolkit3d/Plot';
/**
 * Utility class rendering camera frustum and objects' bounding boxes for debugging purpose.
 */
export declare class CameraFrustumDebug {
    /**
     * Create the debug visuals including camera frustum and objects' bounding boxes.<br>
     * Note: the debug visual are meant to be added to the Plot root.
     * @param plot the Plot to debug
     * @param options DisplayDebugVisualsOptions.
     * @returns the container holding the debug visuals.
     */
    static createDebugVisuals(plot: Plot, options?: CameraFrustumDebug.DisplayDebugVisualsOptions): Object3D;
    /**
     * Display the debug visuals including camera frustum and objects' bounding boxes.<br>
     * As opposed to createDebugVisuals() method, this method takes care of adding and updating the visuals automatically.
     * @param plot the Plot to debug
     * @param options DisplayDebugVisualsOptions.
     */
    static displayDebugVisuals(plot: Plot, options?: CameraFrustumDebug.DisplayDebugVisualsOptions): void;
    /**
     * Remove the debug visuals including camera frustum and objects' bounding boxes.
     * @param plot the Plot contains the debug visual
     */
    static removeDebugVisuals(plot: Plot): void;
    static getClassName(): string;
}
export declare namespace CameraFrustumDebug {
    type DisplayDebugVisualsOptions = {
        /**
         * Whether to draw the camera frustum debug visual or not.<br>
         * Default is true.
         */
        drawfrustum?: boolean;
        /**
         * Customize the Frustum debug visual colors
         */
        frustumcolors?: {
            /**
             * Define the camera frustum line colors.
             * Default is 0xffaa00 (orange).
             */
            frustum?: Color;
            /**
             * Define the camera cone (between the near plane and the frustum) color.
             * Default is 0xff0000 (red).
             */
            cone?: Color;
            /**
             * Define the camera up vector color.
             * Default is 0x00aaff (light blue).
             */
            up?: Color;
            /**
             * Define the camera ray color (the line segment representing the camera lookat direction).
             * Default is 0xffffff (white).
             */
            target?: Color;
            /**
             * Define the Frustum crosses color (crosses are horizontal/vertical lines inside the near and far planes).
             * Default is 0x333333 (dark grey).
             */
            cross?: Color;
        };
        /**
         * Whether to draw objects bounding boxes debug visual or not.<br>
         * Default is true.
         */
        drawboxes?: boolean;
        /**
         * Whether to draw objects bounding spheres debug visual or not.<br>
         * Default is true.
         */
        drawspheres?: boolean;
        /**
         * If true, the debug visualisation of the bounding boxes for graduated grids in the scene (IndexGrid, Grid, PolarGrid) will not be drawn.<br>
         * This option only have effect if the option.drawboxes is also true.<br>
         * Default is true.
         */
        excludegrid?: boolean;
        /**
         * Optional scaling for the box size.<br>
         * A larger-than-1 scale (ex: 1.01 to increase box size by 1%) can be useful to avoid z-fighting or improve visual
         * reading when a lot of boxes overlap on similar coordinates.<br>
         * Default is 1
         */
        boxesscale?: number;
        /**
         * A filter function to ignore some nodes if callback returns false.<br>
         * Default is null.
         */
        filter?: Plot.FilterCallback;
    };
}
