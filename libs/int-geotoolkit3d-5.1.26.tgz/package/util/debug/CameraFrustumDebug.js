/* eslint-disable */

export {Uqt as CameraFrustumDebug} from '@int/impl/geotoolkit3d.js';
