/* eslint-disable */

export {LYt as Texture} from '@int/impl/geotoolkit3d.js';
