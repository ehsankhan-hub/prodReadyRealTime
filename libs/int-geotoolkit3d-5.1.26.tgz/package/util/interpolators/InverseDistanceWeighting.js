/* eslint-disable */

export {M0t as InverseDistanceWeighting} from '@int/impl/geotoolkit3d.js';
