/* eslint-disable */

export {b0t as AbstractInterpolator} from '@int/impl/geotoolkit3d.js';
