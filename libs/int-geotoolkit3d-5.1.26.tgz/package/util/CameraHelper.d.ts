import type { Object3D as BASEObject3D } from 'three';
import type { Plot } from '@int/geotoolkit3d/Plot';
/**
 * Utility class providing help functions for camera related operations.<br>
 */
export declare class CameraHelper {
    /**
     * Test if an object (or its children) is inside camera frustum, which means, inside the current 3D viewport of the given Plot.<br>
     * To test if any object is inside camera frustum, user can set object as plot.getRoot().
     * @param plot the plot
     * @param object object to test
     * @param options IsInCameraOptions
     * @returns true if given object is inside camera frustum, otherwise false
     */
    static isInCameraFrustum(plot: Plot, object: BASEObject3D, options?: CameraHelper.IsInCameraOptions): boolean;
}
export declare namespace CameraHelper {
    type IsInCameraOptions = {
        /**
         * filter callback to filter out objects from the test if callback returns false.<br>
         * Default is null.
         */
        filter?: Plot.FilterCallback;
        /**
         * Whether this method should ignore invisible objects or test them.<br>
         * If true, only visible objects (object.visible === true) will be tested.<br>
         * In this case, if a node is not visible, then its children will not be tested either.<br>
         * If set to false, the method will test objects even if they are not visible.<br>
         * Default value is true.
         */
        ignoreinvisible?: boolean;
        /**
         * Whether this method should traverse the given object's children or not.<br>
         * If true, the method will traverse the given object and every children objects recursively.<br>
         * If false, the method will only test the given objects and ignore any children object/mesh.<br>
         * Default is true (recommended, as most Toolkit objects visuals are nested.)
         */
        traversechildren?: boolean;
        /**
         * Whether to test individual objects or consider the union of each children objects' bounding boxes.<br>
         * Configure testindividualobjects to further define behavior when traversechildren is true:<br>
         * If true, the method will test each objects inside the given node with its own independent boundingBox.<br>
         * If false, all objects inside the given nodes will form a larger boundingBox from the union of each children object boundingBox.<br>
         * A typical example is, if the given node to test contains far away objects, like points.<br>
         * In the case of neither of those sub objects is inside the frustum, but the union of their boundingBox is in the frustum, this option will determine if the method returns true or false.<br>
         * Default is false (test with the union of all children bboxes).
         */
        testindividualobjects?: boolean;
    };
}
