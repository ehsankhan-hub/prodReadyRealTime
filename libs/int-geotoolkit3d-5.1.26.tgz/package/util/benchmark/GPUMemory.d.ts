export declare namespace GPUMemory {
    type Result = {
        /**
         * The estimated available shared GPU memory in bytes<br>
         * Shared GPU memory usually include the VRAM and some shared RAM based on the OS settings.
         */
        bytecountmemory: number;
        /**
         * The estimated available shared GPU memory in a human-readable format.<br>
         * Shared GPU memory usually include the VRAM and some shared RAM based on the OS settings.
         */
        formattedmemory: string;
    };
}
