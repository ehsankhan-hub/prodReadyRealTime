/* eslint-disable */

export {R0t as GPUBenchmark} from '@int/impl/geotoolkit3d.js';
