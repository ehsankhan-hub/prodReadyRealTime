import { GPUMemory } from '@int/geotoolkit3d/util/benchmark/GPUMemory';
/**
 * Utility class to benchmark GPU.<br>
 * This GPUBenchmark class provides the following GPU benchmark information:<br>
 * 1. GPU information:<br>
 * General information about current browser, including GPU name and WebGL information.<br>
 * 2. Graphic Performance Score:<br>
 * A score indicates the raw power of the GPU. The higher the score is, the better the GPU is.<br>
 * Usually, an mid-low-end integrated graphics card like Intel UHD Graphics 630 can reach about 460 score,
 * a mid-end dedicated graphics card like NVIDIA GeForce GTX 1050 Ti can reach about 2200 score,
 * and a high-end dedicated graphics card like NVIDIA GeForce RTX 3080 can reach about 20400 score.<br>
 * 3. Estimated GPU memory:<br>
 * To determine the available GPU shared memory (both VRAM and shared RAM memory), this utility allocate GPU memory until the WebGL context drops (in a controlled manner).<br>
 * This allow us to get an estimation of the available memory.<br>
 * Because of web browser limitations, it is currently not possible to measure the exact VRAM capacity, and not possible either to distinguish the GPU VRAM from shared memory.
 * Please note that after estimating GPU memory, it is necessary for the user to reload the page or even close the tab and reload to allow further WebGL context creation.
 * Currently only supported on Windows Chrome and Mac Chrome due to the limitation of devices and browsers.
 */
export declare class GPUBenchmark {
    /**
     * Check if GPUBenchmark.startScoreBenchmark is supported by current device.
     * @returns true if supported, otherwise false
     */
    static isScoreSupported(): boolean;
    /**
     * Check if GPUBenchmark.startMemoryEstimate is supported by current device.
     * @returns true if supported, otherwise false
     */
    static isMemoryEstimateSupported(): boolean;
    /**
     * Get GPU information
     * @returns GPUBenchmark.GPUInfo
     */
    static getGPUInfo(): Promise<GPUBenchmark.GPUInfo>;
    /**
     * Start benchmarking GPU<br>
     * A score that indicates the raw power of GPU will be returned after the benchmarking test.
     * @param container If the container is not provided, it will do the offscreen rendering, otherwise it will render the benchmark scene on the given canvas.
     */
    static startScoreBenchmark(container?: HTMLElement): Promise<number>;
    /**
     * Start GPU memory estimation<br>
     * This method will try to allocate as many textures as possible until the WebGL loses context.<br>
     * The result is the number of bytes allocated. This result can provide a general idea of the GPU memory but not an exact number. The GPU memory estimation includes the GPU memory usage from both dedicated GPU memory and shared GPU memory.<br>
     * Please be aware that this method will cause a page crash due to the GPU being out of memory, it has a chance that the WebGL context can be restored but not guaranteed.<br>
     * Use it very carefully.
     * @param container If the container is not provided, it will do the offscreen rendering, otherwise it will render the benchmark scene on the given canvas.
     */
    static startMemoryEstimate(container?: HTMLElement): Promise<GPUMemory.Result>;
    /**
     * Helper function to format bytes
     * @param bytes number of bytes
     * @returns formatted result
     */
    static formatBytes(bytes: number): string;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace GPUBenchmark {
    type GPUInfo = {
        /**
         * User agent string for the current browser
         */
        browseruseragent: string;
        /**
         * WebGL context name
         */
        contextname: string;
        /**
         * WebGL version
         */
        glversion: string;
        /**
         * Shading language version
         */
        shadinglanguageversion: string;
        /**
         * Vendor
         */
        vendor: string;
        /**
         * Renderer
         */
        renderer: string;
        /**
         * Unmasked Vendor
         */
        unmaskedvendor: string;
        /**
         * Unmasked Renderer
         */
        unmaskedrenderer: string;
    };
}
