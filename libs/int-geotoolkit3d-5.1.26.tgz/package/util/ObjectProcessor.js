/* eslint-disable */

export {sYt as ObjectProcessor} from '@int/impl/geotoolkit3d.js';
