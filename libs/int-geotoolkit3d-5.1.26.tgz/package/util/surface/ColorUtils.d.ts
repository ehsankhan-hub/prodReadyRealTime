import { Color } from 'three';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
export declare namespace ColorUtils {
    /**
     * The surface color options.
     */
    type ColorOptions = {
        /**
         * A color provider or a single color in css format
         */
        colorprovider?: ColorProvider | string | Color;
        /**
         * The opacity of the solid single color.
         */
        opacity?: number;
        /**
         * A single solid color
         */
        color?: Color;
        /**
         * Optional surface data.
         */
        data?: {
            /**
             * Optional Surface vertices custom values.
             */
            values?: Float32Array;
        };
    };
}
