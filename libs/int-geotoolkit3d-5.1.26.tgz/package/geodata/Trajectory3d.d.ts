/**
 * @module geotoolkit3d/geodata/Trajectory3d
 */
import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
import { Box3, Vector3 } from 'three';
import type { TrajectoryValue } from '@int/geotoolkit3d/geodata/TrajectoryValue';
import { TrajectorySelectionMode } from '@int/geotoolkit3d/geodata/TrajectorySelectionMode';
/**
 * The utility class Trajectory3d is used to define a trajectory, providing the coordinates of each point/station along the well path.<br>
 * Trajectory contains MD- (measured depth), X/Y/Z coordinates, and if provided, property values along the trajectory.<br>
 * If measured depth is not provided, it is calculated from 0 along the path.<br>
 * If the origin offset is provided in the constructor, the provided x,y,z array will be used by reference.
 * Please make a copy if these array are to be modified by the user.
 */
export declare class Trajectory3d extends EventDispatcher {
    /**
     * Create the Trajectory3d from the given coordinates.
     * @param x x-coordinate of the transformed stations.
     * @param y y-coordinate of the transformed stations.
     * @param z z-coordinate of the transformed stations.
     * @param [origin] the 3D coordinates offset, if the given xyz coordinates are in deviation from origin.
     * If provided, x,y,z arrays will be used by reference, else, x,y,z arrays will be deep copied.
     * @param [d] The measured depths array for each station. If not supplied, they will be estimated from the given xyz.
     * @param [values] property values that are associated with each station in this trajectory.
     * @throws {Error} if the Trajectory data is invalid.
     */
    constructor(x: number[], y: number[], z: number[], origin?: Vector3, d?: number[], values?: TrajectoryValue[]);
    /**
     * Gets the x coordinate at the specified index.<br>
     * Coordinates are relative to the origin offset.
     * @param index index of the station.
     * @returns value if found; "undefined" otherwise
     */
    getX(index: number): number;
    /**
     * Gets the y coordinate at the specified index.<br>
     * Coordinates are relative to the origin offset.
     * @param index index of the station.
     * @returns value if found; "undefined" otherwise
     */
    getY(index: number): number;
    /**
     * Gets the z coordinate at the specified index.<br>
     * Coordinates are relative to the origin offset.
     * @param index index of the station.
     * @returns value if found; "undefined" otherwise
     */
    getZ(index: number): number;
    /**
     * Gets the MD value (measured depth) at the specified index.
     * @param index index of the station.
     * @returns value if found; "undefined" otherwise
     */
    getDepth(index: number): number;
    /**
     * Gets the number of stations in the trajectory.
     */
    count(): number;
    /**
     * Gets the calculated minimal x coordinate of this trajectory.<br>
     * Coordinates are relative to the origin offset.
     * @deprecated since 5.0 as it is not consistent with the trajectory offset, please use getWellLocalBounds() or getWellWorldBounds() instead.
     */
    getMinX(): number;
    /**
     * Gets the calculated minimal y coordinate of this trajectory.<br>
     * Coordinates are relative to the origin offset.
     * @deprecated since 5.0 as it is not consistent with the trajectory offset, please use getWellLocalBounds() or getWellWorldBounds() instead.
     */
    getMinY(): number;
    /**
     * Gets the calculated maximal x coordinate of this trajectory.<br>
     * Coordinates are relative to the origin offset.
     * @deprecated since 5.0 as it is not consistent with the trajectory offset, please use getWellLocalBounds() or getWellWorldBounds() instead.
     */
    getMaxX(): number;
    /**
     * Gets the calculated maximal y coordinate of this trajectory.<br>
     * Coordinates are relative to the origin offset.
     * @deprecated since 5.0 as it is not consistent with the trajectory offset, please use getWellLocalBounds() or getWellWorldBounds() instead.
     */
    getMaxY(): number;
    /**
     * Gets the calculated minimal z coordinate of this trajectory.<br>
     * Coordinates are relative to the origin offset.
     * @deprecated since 5.0 as it is not consistent with the trajectory offset, please use getWellLocalBounds() or getWellWorldBounds() instead.
     */
    getMinZ(): number;
    /**
     * Gets the calculated maximal z coordinate of this trajectory.<br>
     * Coordinates are relative to the origin offset.
     * @deprecated since 5.0 as it is not consistent with the trajectory offset, please use getWellLocalBounds() or getWellWorldBounds() instead.
     */
    getMaxZ(): number;
    /**
     * Gets the calculated minimum/maximum local coordinates of this trajectory.<br>
     * Coordinates are relative to the origin offset, so to retrieve the actual world coordinates, either add the
     * trajectory offset, or use the .getWellWorldBounds() method.
     */
    getWellLocalBounds(): Box3;
    /**
     * Gets the calculated minimum/maximum world coordinates of this trajectory.<br>
     * Coordinates are absolute. To retrieve the local coordinates which depend on the trajectory offset, please instead
     * use the .getWellLocalBounds() method.
     */
    getWellWorldBounds(): Box3;
    /**
     * Gets the calculated minimal MD (measured depth).<br>
     * Identical to getMinDepth, exists to be closer to the existing Trajectory2d API.<br>
     * Measured depth is considered to be unsigned, meaning min Depth is the shallowest point.
     */
    minDepth(): number;
    /**
     * Gets the calculated minimal MD (measured depth).<br>
     * Measured depth is considered to be unsigned, meaning min Depth is the shallowest point.
     */
    getMinDepth(): number;
    /**
     * Gets the calculated maximal MD (measured depth).<br>
     * Identical to getMaxDepth, exists to be closer to the existing Trajectory2d API.<br>
     * Measured depth is considered to be unsigned, meaning max Depth is the deepest point.
     */
    maxDepth(): number;
    /**
     * Gets the calculated maximal MD (measured depth).<br>
     * Measured depth is considered to be unsigned, meaning max Depth is the deepest point.
     */
    getMaxDepth(): number;
    /**
     * Gets the origin position offset, as a Vector3.<br>
     * To get the real coordinates out of this Trajectory, X, Y and Z coordinates should be offset by the origin coordinates first.
     */
    getOrigin(): Vector3;
    /**
     * Return the trajectory coordinates for the given interval [start, end], in measured depths (MD).<br>
     * If no parameters are given, this will return all depths.
     * @param [start] starting depth. If undefined, will return everything until the given trajectory end.
     * @param [end] ending depth.
     * @param [radii] radii values, for generating a radius value on each depths (depths from start to end).
     * @throws Error if the provided start/end Depth locations are outside of range.
     */
    getCoordinatesForDepths(start?: number, end?: number, radii?: {
        /**
         * The radius of this depth.
         */
        radius: number;
        /**
         * The measured depth, to define a radius value at.
         */
        depth: number;
    }[]): Trajectory3d.CoordinatesForDepths;
    /**
     * Gets the 3D direction of the trajectory at the requested depth, as a Vector3.
     * @param location the measured depth (MD) at which the direction will be deduced.
     * @param [preferForward] If true, the direction will be calculated downside along the well progression (forward),
     * else the direction will be going up the well (backward). Default is true.
     * @throws Error if the provided Depth location is outside of range.
     * @returns pos
     */
    getDirectionAtDepth(location: number, preferForward?: boolean): Vector3;
    /**
     * Gets the interpolated local position at the requested measured depth (MD).<br>
     * Note:
     * @param location depth for the desired position, in measured depth (MD).
     * @param applyOriginOffset if true, the Well origin offset is applied to the result (default is false).
     * @throws Error if the provided Depth location is outside of range.
     * @returns the position as a Vector3.
     */
    getCoordinateForDepth(location: number, applyOriginOffset?: boolean): Vector3;
    /**
     * Gets the property values for the defined start/end measured depths range.<br>
     * If start/end are not defined, this will return the values for all depths in this trajectory.
     * @param [propertyName] name of the property to get the values of.
     * @param [start] starting depth. If undefined, will returns everything before end.
     * @param [end] ending depth.
     * @param [radii] provide optional additional depth positions to compute the values of. Resulting values will still be sorted from start to end depth.
     * @throws Error if the provided start/end Depth locations are outside of range.
     * @returns values the value array, sorted by depth, from start to end of the trajectory.
     */
    getValuesForDepths(propertyName?: string, start?: number, end?: number, radii?: {
        radius: number;
        depth: number;
    }[]): number[];
    /**
     * Returns the closest point/station to the given XYZ world coordinate position.<br>
     * @returns the point result, or null if no point is found, or if the trajectory points are too far.
     */
    getPointForCoordinates(options: Trajectory3d.GetPointByPositionOptions): Trajectory3d.GetPointResult | null;
}
export declare namespace Trajectory3d {
    type CoordinatesForDepths = {
        x: number[];
        y: number[];
        z: number[];
        widths: null | number[];
        heights: null | number[];
        origin: Vector3;
    };
    /**
     * The options when retrieving a trajectory point by position.
     */
    type GetPointByPositionOptions = {
        /**
         * The XYZ position to search for. Z is the elevation, meaning it increase going upward.<br>
         * When used alongside 3D picking, the picking position can directly be used without transformation.
         */
        position: Vector3;
        /**
         * If true, the result will contain the interpolated position between the two closest points/stations found.<br>
         * If false, only the closest point/station will be returned.<br>
         * Default is true.
         */
        interpolate?: boolean;
        /**
         * Define the point selection mode, either closest by distance or by depth.<br>
         * Default mode is ClosestByDepth.
         */
        selectionmode?: TrajectorySelectionMode;
        /**
         * If the resulting point is further than this distance, the selection will be canceled and null will be return instead.<br>
         * Can save time if the well is at an unknown distance from the given point.<br>
         * By default is Number.POSITIVE_INFINITY
         */
        maxdistance?: number;
    };
    /**
     * The point/station result from retrieving a point by coordinates in the trajectory.
     */
    type GetPointResult = {
        /**
         * When the interpolation option is enabled, this field will contain the point interpolated from the two closest
         * trajectory points/stations.<br>
         * Will be undefined if interpolation is disabled.
         */
        interpolatedpoint?: Point | null;
        /**
         * The closest point/station to the provided coordinates.
         */
        point1: Station;
        /**
         * The second closest point/station to the provided coordinates (if interpolation option is enabled, and if the
         * provided coordinate is between point1 and point2).<br>
         * Will be undefined if interpolation is disabled or if the provided coordinate is not between two trajectory points/stations.
         */
        point2?: Station | null;
    };
    /**
     * Define a point or station along the Trajectory. (Can be an interpolated point).
     */
    type Point = {
        /**
         * The trajectory point's measured depth (md).
         */
        md: number;
        /**
         * The trajectory point's position (XYZ).<br>
         * Note that the Trajectory origin offset is applied (added) to this result.
         */
        position: Vector3;
    };
    /**
     * Define a point/station of the Trajectory. This point/station is identified by it's index in the trajectory.
     */
    type Station = Point & {
        /**
         * The trajectory point/station index in this trajectory.
         */
        index: number;
    };
}
