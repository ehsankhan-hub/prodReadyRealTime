/**
 * @module geotoolkit3d/geodata/TrajectorySelectionMode
 */
/**
 * The trajectory point/station selection modes when trying to select a trajectory point from XYZ coordinates.
 * @enum
 * @readonly
 */
export declare enum TrajectorySelectionMode {
    /**
     * Will try to find the closest trajectory point by distance, factoring X, Y and Z coordinates.<br>
     * X, Y and Z are also used to determine if the given point is too far outside the trajectory boundaries.
     */
    ClosestByDistance = "ClosestByDistance",
    /**
     * Will try to find the closest trajectory point by depth, only factoring the Z coordinate.<br>
     * X, Y and Z are still used to determine if the given point is too far outside the trajectory boundaries.
     */
    ClosestByDepth = "ClosestByDepth"
}
