/* eslint-disable */

export {mqt as FirstPersonController} from '@int/impl/geotoolkit3d.js';
