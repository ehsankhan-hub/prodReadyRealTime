/* eslint-disable */

export {oqt as OrbitController} from '@int/impl/geotoolkit3d.js';
