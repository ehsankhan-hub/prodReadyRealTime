/* eslint-disable */

export {$Ai as ColorMapAlphaEditorWidget} from '@int/impl/geotoolkit3d.js';
