/**
 * @module geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents
 */
/**
 * ColorMapAlphaEditor events.
 * @enum
 * @events
 * @readonly
 */
export declare enum ColorMapAlphaEditorEvents {
    /**
     * SetPoints
     * @event module:geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents~SetPoints
     */
    SetPoints = "SetPoints",
    /**
     * PointRemoved
     * @event module:geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents~PointRemoved
     */
    PointRemoved = "PointsRemoved",
    /**
     * PointAdded
     * @event module:geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents~PointAdded
     */
    PointAdded = "PointAdded",
    /**
     * ColorMapChanged
     * @event module:geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents~ColorMapChanged
     */
    ColorMapChanged = "ColorMapChanged",
    /**
     * AlphaPointChanged
     * @event module:geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents~AlphaPointChanged
     */
    AlphaPointChanged = "AlphaPointChanged"
}
