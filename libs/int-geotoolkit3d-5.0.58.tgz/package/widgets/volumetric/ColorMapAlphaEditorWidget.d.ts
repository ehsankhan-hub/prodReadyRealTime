import { Rect } from '@int/geotoolkit/util/Rect';
import { AnnotatedWidget } from '@int/geotoolkit/widgets/AnnotatedWidget';
import { ColorMapAlphaEditorEvents } from '@int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents';
import type { LineStyle } from '@int/geotoolkit/attributes/LineStyle';
import type { TextStyle } from '@int/geotoolkit/attributes/TextStyle';
import type { RectangularShape } from '@int/geotoolkit/scene/shapes/RectangularShape';
import type { FillStyle } from '@int/geotoolkit/attributes/FillStyle';
/**
 * The transfer function widget. This widget manages the editor and provides some functions
 * to set an editor and/or a transfer function.
 *
 * Configuring the various options of the widget can be achieved by calling setOptions().<br>
 * Selection is handled in the application by using the onSelectionChanged event.
 */
export declare class ColorMapAlphaEditorWidget extends AnnotatedWidget {
    constructor(options?: AnnotatedWidget.Options);
    on<E extends keyof ColorMapAlphaEditorWidget.EventMap>(type: E, callback: (eventType: E, sender: this, args: ColorMapAlphaEditorWidget.EventMap[E]) => void): this;
    off<E extends keyof ColorMapAlphaEditorWidget.EventMap>(type?: E, callback?: (eventType: E, sender: this, args: ColorMapAlphaEditorWidget.EventMap[E]) => void): this;
    notify<E extends keyof ColorMapAlphaEditorWidget.EventMap>(type: E, source: ColorMapAlphaEditorWidget, args?: ColorMapAlphaEditorWidget.EventMap[E]): this;
    /**
     * Set the options of the widget
     *
     * @param [options] javascript object used to define the config
     * @returns this
     */
    setOptions(options?: ColorMapAlphaEditorWidget.OptionsBase): this;
    /**
     * Get options
     * @returns options
     */
    getOptions(): ColorMapAlphaEditorWidget.OptionsBaseOut;
    /**
     * Set the color map.
     *
     * @param colorMapName - Array of CSS color (like "rgba(x,x,x,x)" or "#ff00fc" or "0xff00fc")
     * @fires @int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents.ColorMapChanged
     * @returns this
     */
    setColorMap(colorMapName: string): this;
    protected initializeTools(): this;
    /**
     * Get the color map of the transfer function
     * @returns colors of the colormap
     */
    getColorMap(): string;
    /**
     * Get the color map of the transfer function
     * @returns colors of the colormap
     */
    getColorMapArray(): string[];
    /**
     * Set the alpha points of the transfer function
     * @param alphaPoints alpha points
     * @fires @int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents.SetPoints
     * @returns this
     */
    setAlphaPoints(alphaPoints: [
        x: number,
        y: number
    ][]): this;
    /**
     * Get the alpha points of the transfer function
     * @returns alphaPoints alpha points
     */
    getAlphaPoints(): [
        x: number,
        y: number
    ][];
    /**
     * Get the number of alpha points
     * @returns number of alpha points
     */
    getNbOfAlphaPoints(): number;
    /**
     * Get the index-th alpha point
     * @param index the index of the alpha point to get
     * @returns the index-th alphaPoint
     */
    getAlphaPoint(index: number): [
        x: number,
        y: number
    ] | null;
    /**
     * Clear all alpha point and set the default alpha points instead
     */
    resetAlphaPoints(): void;
    /**
     * Add a new alpha point
     * @param point the new alpha point
     * @fires @int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents.PointAdded
     * @returns index the point was inserted at
     */
    addAlphaPoint(point: [
        x: number,
        y: number
    ]): number;
    /**
     * Set an alpha point at the provided index
     * @param index the index of the new alpha point
     * @param point the new alpha point
     * @fires @int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents.AlphaPointChanged
     * @fires @int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents.PointAdded
     * @returns this
     */
    setAlphaPoint(index: number, point: [
        x: number,
        y: number
    ]): this;
    /**
     * Remove the alpha point at the provided index
     * @param index the index of the alpha point to remove
     * @fires @int/geotoolkit3d/widgets/volumetric/ColorMapAlphaEditorEvents~ColorMapAlphaEditorEvents.PointRemoved
     * @returns this
     */
    removeAlphaPoint(index: number): this;
    /**
     * Sets line style
     * @param lineStyle line style or options
     * @param [merge] true if you want to merge lineStyle with existing attribute, false by default
     * @returns this
     */
    setLineStyle(lineStyle: LineStyle.Type, merge?: boolean): this;
}
export declare namespace ColorMapAlphaEditorWidget {
    /**
     * javascript object used to define the config
     */
    type OptionsBase = Visual.Options & {
        /**
         * tool options
         */
        tool?: {
            /**
             * name of the tool
             */
            name?: string;
            /**
             * default linestyle shared for all orientations.
             */
            linestyle?: LineStyle.Type;
            /**
             * default textstyle shared for all orientations.
             */
            textstyle?: TextStyle.Type;
            /**
             * size of symbol
             */
            distance?: number;
        };
    };
    type OptionsBaseOut = AnnotatedWidget.OptionsOut & Visual.OptionsOut & {
        tool: VisualToolOptionsOut;
    };
    namespace Visual {
        /**
         * An object containing the properties to set
         */
        type Options = RectangularShape.Options & {
            /**
             * modellimits of the group
             */
            limits?: Rect;
            /**
             * vertical flip of the group
             */
            verticalflip?: boolean;
            /**
             * horizontal flip of the group
             */
            horizontalflip?: boolean;
            /**
             * enable picking children
             */
            pickingchildren?: boolean;
        };
        type OptionsOut = RectangularShape.OptionsOut & {
            /**
             * vertical flip of the group
             */
            verticalflip: boolean;
            /**
             * horizontal flip of the group
             */
            horizontalflip: boolean;
            /**
             * enable picking children
             */
            pickingchildren: boolean;
        };
    }
    type VisualToolOptionsOut = {
        name: string;
        linestyle: LineStyle | null;
        fillstyle: FillStyle | null;
        distance: number;
    };
    type EventMap = AnnotatedWidget.EventMap & {
        [ColorMapAlphaEditorEvents.ColorMapChanged]: {
            colormap: string;
        };
        [ColorMapAlphaEditorEvents.SetPoints]: {
            points: [
                x: number,
                y: number
            ][];
        };
        [ColorMapAlphaEditorEvents.PointAdded]: {
            point: [
                x: number,
                y: number
            ];
            index: number;
        };
        [ColorMapAlphaEditorEvents.AlphaPointChanged]: {
            point: [
                x: number,
                y: number
            ];
            previouspoint: [
                x: number,
                y: number
            ];
            index: number;
        };
        [ColorMapAlphaEditorEvents.PointRemoved]: {
            point: [
                x: number,
                y: number
            ];
            index: number;
        };
    };
}
