/* eslint-disable */

export {D_t as ScatterPlot} from '@int/impl/geotoolkit3d.js';
