/* eslint-disable */

export {S0t as FirstPersonController} from '@int/impl/geotoolkit3d.js';
