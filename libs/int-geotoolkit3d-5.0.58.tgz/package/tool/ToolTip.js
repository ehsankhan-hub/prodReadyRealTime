/* eslint-disable */

export {T1t as ToolTip} from '@int/impl/geotoolkit3d.js';
