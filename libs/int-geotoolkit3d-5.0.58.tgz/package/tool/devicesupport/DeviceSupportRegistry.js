/* eslint-disable */

export {g$t as DeviceSupportRegistry} from '@int/impl/geotoolkit3d.js';
