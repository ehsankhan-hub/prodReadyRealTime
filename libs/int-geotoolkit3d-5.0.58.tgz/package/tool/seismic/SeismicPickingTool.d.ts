/**
 * @module geotoolkit3d/tool/seismic/SeismicPickingTool
 */
import { AbstractGestureTool } from '@int/geotoolkit3d/tool/AbstractGestureTool';
import type { AbstractDeviceSupport } from '@int/geotoolkit3d/tool/devicesupport/AbstractDeviceSupport';
import type { AbstractPicking } from '@int/geotoolkit3d/picking/AbstractPicking';
import type { SnapPickingStrategy } from '@int/geotoolkit/seismic/data/snap/SnapPickingStrategy';
import type { PickSampleCallbackData } from '@int/geotoolkit/seismic/data/snap/PickSampleCallback';
import type { AbstractTool } from '@int/geotoolkit3d/tool/AbstractTool';
/**
 * Event types
 * @enum
 * @readonly
 * @events
 */
export declare enum Events {
    /**
     * onPicking
     * @event module:geotoolkit3d/tool/seismic/SeismicPickingTool~Events~onPicking
     */
    onPicking = "onPicking"
}
/**
 * Tool to pick seismic samples
 */
export declare class SeismicPickingTool extends AbstractGestureTool {
    constructor(options?: SeismicPickingTool.Options);
    on<E extends keyof SeismicPickingTool.EventMap>(type: E, callback: (eventType: E, sender: this, args: SeismicPickingTool.EventMap[E]) => void): this;
    off<E extends keyof SeismicPickingTool.EventMap>(type?: E, callback?: (eventType: E, sender: this, args: SeismicPickingTool.EventMap[E]) => void): this;
    notify<E extends keyof SeismicPickingTool.EventMap>(type: E, source: SeismicPickingTool, args?: SeismicPickingTool.EventMap[E]): this;
    setOptions(options?: SeismicPickingTool.Options): this;
    getOptions(): SeismicPickingTool.OptionsOut;
    /**
     * Called when a 'onCursorMove' event has occurred
     * @param event the native event with plot coordinates added
     */
    onCursorMove(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onTap' event has occurred
     * @param event the native event with plot coordinates added
     */
    onTap(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * onSelectionFunction
     * @fires @int/geotoolkit3d/tool/seismic/SeismicPickingTool~Events.onPicking
     * @param selection selection
     * @param event the native event
     */
    onSelection(selection: AbstractPicking.PickingResult[], event: AbstractDeviceSupport.CustomPointerEvent): void;
    onKeyStart(event: KeyboardEvent): void;
    onKey(event: KeyboardEvent): void;
    onKeyEnd(event: KeyboardEvent): void;
    onDoubleTap(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onMouseWheel(event: WheelEvent): void;
    onPinchStart(event: AbstractGestureTool.MovePointerEvent): void;
    onPinch(event: AbstractGestureTool.MovePointerEvent): void;
    onPinchEnd(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onDragStart(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onDrag(event: AbstractDeviceSupport.CustomPointerEvent): void;
    onDragEnd(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onSlideStart' event has occurred
     * @param event the native event with plot coordinates added
     */
    onSlideStart(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onSlide' event has occurred
     * @param event the native event with plot coordinates added
     */
    onSlide(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onSlideEnd' event has occurred
     * @param event the native event with plot coordinates added
     */
    onSlideEnd(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onVisibilityGained' event has occurred
     * @param event the native event with plot coordinates added
     */
    onVisibilityGained(event: AbstractDeviceSupport.CustomPointerEvent): void;
    /**
     * Called when a 'onVisibilityLost' event has occurred
     * @param event the native event with plot coordinates added
     */
    onVisibilityLost(event: AbstractDeviceSupport.CustomPointerEvent): void;
}
export declare namespace SeismicPickingTool {
    /**
     * Options object
     */
    type OptionsBase = {
        /**
         * True to enable tool
         */
        enabled?: boolean;
        /**
         * True to make tool working on hovering
         */
        hover?: boolean;
        /**
         * Register the implementation who will perform the 3D picking action.
         * By default, the 3D toolkit's default GPU picking will be used.
         */
        picking?: PickingClass;
        /**
         * Snap picking strategy, algorithm of interpolation for seismic picking
         */
        snappickingstrategy?: SnapPickingStrategy;
    };
    export type Options = AbstractGestureTool.Options & OptionsBase;
    export type OptionsOut = AbstractGestureTool.OptionsOut & Required<OptionsBase>;
    export type EventMap = AbstractTool.EventMap & {
        [Events.onPicking]: PickSampleCallbackData;
    };
    export type PickingClass = typeof AbstractPicking;
    export {};
}
