/* eslint-disable */

export {ani as DefaultAnnotationLayout} from '@int/impl/geotoolkit3d.js';
