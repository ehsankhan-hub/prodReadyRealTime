/* eslint-disable */

export {hni as AbstractAnnotationLayout} from '@int/impl/geotoolkit3d.js';
