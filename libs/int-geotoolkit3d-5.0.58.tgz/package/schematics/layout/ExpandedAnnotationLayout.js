/* eslint-disable */

export {uni as ExpandedAnnotationLayout} from '@int/impl/geotoolkit3d.js';
