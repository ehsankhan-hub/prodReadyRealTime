/* eslint-disable */

export {Jni as Trajectory} from '@int/impl/geotoolkit3d.js';
