/* eslint-disable */

export {gni as SimpleFactory} from '@int/impl/geotoolkit3d.js';
