/* eslint-disable */

export {Wsi as TrajectoryValue} from '@int/impl/geotoolkit3d.js';
