/* eslint-disable */

export {jjt as DefaultSpritePickingMaterial} from '@int/impl/geotoolkit3d.js';
