/* eslint-disable */

export {N9t as DefaultSeismicSlicePickingMaterial} from '@int/impl/geotoolkit3d.js';
