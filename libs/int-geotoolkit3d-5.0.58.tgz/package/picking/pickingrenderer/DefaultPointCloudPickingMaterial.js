/* eslint-disable */

export {GXt as DefaultPointCloudPickingMaterial} from '@int/impl/geotoolkit3d.js';
