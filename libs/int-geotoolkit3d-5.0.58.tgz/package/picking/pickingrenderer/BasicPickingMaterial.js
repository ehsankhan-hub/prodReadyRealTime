/* eslint-disable */

export {Hjt as BasicPickingMaterial} from '@int/impl/geotoolkit3d.js';
