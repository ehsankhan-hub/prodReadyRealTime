/* eslint-disable */

export {qjt as DefaultMeshPickingMaterial} from '@int/impl/geotoolkit3d.js';
