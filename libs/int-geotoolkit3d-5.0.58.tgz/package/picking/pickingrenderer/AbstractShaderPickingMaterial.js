/* eslint-disable */

export {Yjt as AbstractShaderPickingMaterial} from '@int/impl/geotoolkit3d.js';
