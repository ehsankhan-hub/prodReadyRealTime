/* eslint-disable */

export {$jt as DefaultPointsPickingMaterial} from '@int/impl/geotoolkit3d.js';
