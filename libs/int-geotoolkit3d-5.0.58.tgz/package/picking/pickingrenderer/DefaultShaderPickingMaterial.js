/* eslint-disable */

export {Kjt as DefaultShaderPickingMaterial} from '@int/impl/geotoolkit3d.js';
