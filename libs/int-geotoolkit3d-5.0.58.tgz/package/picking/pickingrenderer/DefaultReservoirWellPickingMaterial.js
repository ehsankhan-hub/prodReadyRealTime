/* eslint-disable */

export {S9t as DefaultReservoirWellPickingMaterial} from '@int/impl/geotoolkit3d.js';
