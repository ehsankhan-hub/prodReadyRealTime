/* eslint-disable */

export {R_t as DefaultPointSetPickingMaterial} from '@int/impl/geotoolkit3d.js';
