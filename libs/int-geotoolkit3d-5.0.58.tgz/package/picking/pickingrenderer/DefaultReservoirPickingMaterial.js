/* eslint-disable */

export {Fzt as DefaultReservoirPickingMaterial} from '@int/impl/geotoolkit3d.js';
