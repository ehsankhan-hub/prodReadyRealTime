/* eslint-disable */

export {szt as PickingMaterialRegistrar} from '@int/impl/geotoolkit3d.js';
