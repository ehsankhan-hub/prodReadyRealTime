/* eslint-disable */

export {gii as Vector} from '@int/impl/geotoolkit3d.js';
