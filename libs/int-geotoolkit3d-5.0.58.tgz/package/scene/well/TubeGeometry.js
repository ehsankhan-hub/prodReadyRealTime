/* eslint-disable */

export {cii as TubeGeometry} from '@int/impl/geotoolkit3d.js';
