/* eslint-disable */

export {qii as LogCurve2D} from '@int/impl/geotoolkit3d.js';
