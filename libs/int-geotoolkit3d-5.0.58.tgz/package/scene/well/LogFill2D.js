/* eslint-disable */

export {Lii as LogFill2D} from '@int/impl/geotoolkit3d.js';
