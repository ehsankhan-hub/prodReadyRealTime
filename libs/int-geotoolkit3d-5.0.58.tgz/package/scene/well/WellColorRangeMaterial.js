/* eslint-disable */

export {lii as WellColorRangeMaterial} from '@int/impl/geotoolkit3d.js';
