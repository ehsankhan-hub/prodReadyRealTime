/* eslint-disable */

export {Ssi as SchematicBase} from '@int/impl/geotoolkit3d.js';
