/* eslint-disable */

export {Fsi as Cube} from '@int/impl/geotoolkit3d.js';
