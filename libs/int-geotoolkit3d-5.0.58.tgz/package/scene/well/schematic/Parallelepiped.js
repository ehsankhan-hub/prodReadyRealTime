/* eslint-disable */

export {Gsi as Parallelepiped} from '@int/impl/geotoolkit3d.js';
