/* eslint-disable */

export {ksi as Sphere} from '@int/impl/geotoolkit3d.js';
