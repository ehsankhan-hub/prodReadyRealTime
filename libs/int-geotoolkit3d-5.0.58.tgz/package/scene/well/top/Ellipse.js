/* eslint-disable */

export {Tsi as Ellipse} from '@int/impl/geotoolkit3d.js';
