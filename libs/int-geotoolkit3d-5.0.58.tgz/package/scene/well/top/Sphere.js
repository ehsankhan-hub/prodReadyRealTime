/* eslint-disable */

export {Lsi as Sphere} from '@int/impl/geotoolkit3d.js';
