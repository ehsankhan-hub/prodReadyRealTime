/* eslint-disable */

export {kZt as Text2d} from '@int/impl/geotoolkit3d.js';
