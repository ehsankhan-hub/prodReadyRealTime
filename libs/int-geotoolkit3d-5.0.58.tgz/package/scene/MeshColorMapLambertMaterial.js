/* eslint-disable */

export {i2t as MeshColorMapLambertMaterial} from '@int/impl/geotoolkit3d.js';
