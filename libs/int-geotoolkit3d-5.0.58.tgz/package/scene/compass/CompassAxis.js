/* eslint-disable */

export {M9t as CompassAxis} from '@int/impl/geotoolkit3d.js';
