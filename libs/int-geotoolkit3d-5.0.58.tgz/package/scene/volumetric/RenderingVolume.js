/* eslint-disable */

export {khi as RenderingVolume} from '@int/impl/geotoolkit3d.js';
