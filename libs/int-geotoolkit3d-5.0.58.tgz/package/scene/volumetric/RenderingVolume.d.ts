/**
 * @module geotoolkit3d/scene/volumetric/RenderingVolume
 */
import { Scene, Vector3 } from 'three';
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { Merge } from '@int/geotoolkit/base';
import type { Plot } from '@int/geotoolkit3d/Plot';
import type { Camera, Vector4, WebGLRenderer } from 'three';
import type { AbstractInterpolator } from '@int/geotoolkit3d/util/interpolators/AbstractInterpolator';
/**
 * A 3D Object that represent a cube with a dynamic texture which display a volume rendering. <br>
 * To display some data you must include a Float32Array of data and the size of the data within a THREE.Vector3. <br>
 * The order in the Float32Array needs to be read each in this order Z Y X like :
 * <br>      ____
 * <br>     /___/| <- Z
 * <br>    |   | |
 * <br>    |___|/  <- Y
 * <br>      X
 */
export declare class RenderingVolume extends Object3D {
    constructor(options?: RenderingVolume.Options);
    /**
     * Set the RenderingVolume options
     * @param [options] The options
     * @returns this
     */
    setOptions(options?: RenderingVolume.OptionsBase): this;
    /**
     * Get the RenderingVolume options
     * @returns options
     */
    getOptions(): RenderingVolume.OptionsBaseOut;
    /**
     * Add Data to the Mesh RenderingVolume, and display it.
     * @param data - Raw data, value mush be order like depth,Xline,Inline
     * @returns this
     */
    addMoreData(data: Float32Array): this;
    /**
     * Update the transfer function
     * @param color - Array of CSS color (like "rgba(x,x,x,x)" or "#ff00fc" or "0xff00fc")
     */
    updateColorMap(color: string[]): void;
    /**
     * Get the dataMin in the volume rendering.
     * @returns the value of dataMin used in the volume rendering
     */
    getDataMin(): number;
    /**
     * Get the dataMax in the volume rendering.
     * @returns the value of dataMax used in the volume rendering
     */
    getDataMax(): number;
    /**
     * Get the number of steps used in the volume rendering.
     * @returns Number of steps used in the volume rendering
     */
    getSteps(): number;
    /**
     * Get the alpha factor used in the volume rendering.<br>
     * @returns Alpha value used to correct the volume rendering
     */
    getAlphaCorrection(): number;
    /**
     * Set if the shader will flip the Z axis
     * @param flip - Boolean if flipZ axis or not.
     * @returns this
     */
    setFlipZ(flip: boolean): this;
    /**
     * Get if the shader will flip the Z axis
     * @returns Boolean if flipZ axis or not
     */
    getFlipZ(): boolean;
    /**
     * Get if the shader display lights in the volumetric
     * @returns Boolean if lights are on or off.
     */
    getLightsOnOff(): boolean;
    /**
     * Set the size of the volume in scene
     * @param sizeInScene - center position
     * @returns this
     */
    setSizeInScene(sizeInScene: Vector3): this;
    /**
     * Get the size of the volume in scene
     * @returns sizeInScene - center position
     */
    getSizeInScene(): Vector3;
    /**
     * This function is called prior to rendering and can update this object's content.<br>
     * <br>
     * It should not trigger any invalidateObject though.<br>
     * Note that it is not necessary nor recommended to explicitly call beforeRender on this object's children as beforeRender will be called on all nodes present in the scene.<br>
     * <br>
     * This will be executed after the transformations simplification.<br>
     * <br>
     * @see {@link @int/geotoolkit3d/Plot~Plot} for more details on the render steps
     * @param scene The scene
     * @param camera The camera used for this render phase.
     * @param plot The 3D plot
     * @param renderer The renderer
     */
    beforeRender(scene: Scene, camera: Camera, plot: Plot, renderer: WebGLRenderer): this;
    /**
     * This function is called prior to rendering and can update this object's content.<br>
     * <br>
     * It should not trigger any invalidateObject though.<br>
     * Note that it is not necessary nor recommended to explicitly call beforeRender on this object's children as beforeRender will be called on all nodes present in the scene.<br>
     * <br>.
     * This will be executed after the transformations simplification<br>
     * <br>
     * @see {@link @int/geotoolkit3d/Plot~Plot} for more details on the render steps
     * @param scene The scene
     * @param camera The camera used for this render phase.
     * @param plot The 3D plot
     * @param renderer The renderer
     */
    afterRender(scene: Scene, camera: Camera, plot: Plot, renderer: WebGLRenderer): this;
}
export declare namespace RenderingVolume {
    /**
     * The options
     */
    type OptionsBase = Object3D.Options & Material.Options;
    type OptionsBaseOut = Required<Object3D.Options> & Material.OptionsOut;
    /**
     * The options
     */
    type Options = {
        /**
         * The number of steps for each ray in the volume raytracing.<br>
         * Each step will perform an additional sample for each pixel of the final raytraced render.<br>
         * Bear in mind that a large step count may be detrimental to performances, and a step count larger than the
         * data resolution will have diminishing returns.
         */
        steps?: number;
        /**
         * The corrective factor for the alpha transparency.<br>
         * This alpha factor affect the opacity of each raytraced samples, higher alpha means the volume becomes more opaque.<br>
         * It might be necessary to adjust the alpha based on the number of steps, a higher step count should use a proportionally lower alpha value.<br>
         * <ul>
         * Ex:
         * <li>step 30 | alpha 0.3</li>
         * <li>step 100 | alpha 0.1</li>
         * <li>step 200 | alpha 0.05, etc</li>
         * <ul>
         */
        alphacorrection?: number;
        /**
         * The start location of the grid in world coordinates.
         */
        start?: Vector3;
        /**
         * The end location of the grid in world coordinates.
         */
        end?: Vector3;
        /**
         * Flip the data with the Z axis
         */
        flipz?: boolean;
        /**
         * toggle the Lights in the volumetric render
         */
        switchlights?: boolean;
        /**
         * Interpolator function, used to convert the PointSet data into a 3D scalar field data for rendering.<br>
         * Users can define their own interpolation function if desired, but a default implementation is included.
         */
        interpolator?: AbstractInterpolator;
        /**
         * The Volume data options.<br>
         * The Volume Renderer accepts two types of data, 3D scalar fields and points sets.
         * <ul>
         * <li>
         * 3D Scalar fields are given using the rawdata option, in a 1 dimension Float32Array.<br>
         * In this scenario, the size option must also be defined to specify the 3D data size on each axis.</li>
         * <li>
         * Point sets are a collection of 3D points, each point consist of X,Y,Z coordinates, and a value.<br>
         * Points can be passed to the Volume Renderer in two way, either using the points option, or using the x,y,z, values options.
         * </li>
         * </ul>
         */
        data?: {
            /**
             * The minimum value of the data.
             */
            min?: number;
            /**
             * The maximum value of the data.
             */
            max?: number;
            /**
             * The size of the data in 3D.
             */
            size?: Vector3;
            /**
             * A Float32Array that contain the raw data with the order Z,Y,X (see description for more information)
             */
            rawdata?: Float32Array;
            /**
             * Define the voume data using points.<br>
             * A Point is represented by a Vector4, where x,y,z are the respective coordinates, and w is the point value.<br>
             * Alternatively, poitns can be specified using multiple arrays with the x, y, z and values options.
             */
            points?: Vector4[];
            /**
             * Define the volume data points's x coordinates.
             */
            x?: number[];
            /**
             * Define the volume data points's y coordinates.
             */
            y?: number[];
            /**
             * Define the volume data points's z coordinates.
             */
            z?: number[];
            /**
             * Define the volume data points's values.
             */
            values?: number[];
        };
    };
    namespace Material {
        /**
         * The options
         */
        type Options = RenderingVolume.Options;
        type OptionsOut = Merge<Required<Options>, {
            /**
             * The data options
             */
            data: {
                /**
                 * The minimum value of the data.
                 */
                min: number;
                /**
                 * The maximum value of the data.
                 */
                max: number;
                /**
                 * The size of the data in 3D.
                 */
                size: Vector3;
            };
        }>;
    }
}
