/**
 * @module geotoolkit3d/scene/volumetric/SinglePassRenderingVolume
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { Camera, Plane, Scene, Texture, Vector2, Vector4, WebGLRenderer } from 'three';
import { Vector3 } from 'three';
import type { Plot } from '@int/geotoolkit3d/Plot';
import type { RenderingMode, SamplingMode } from '@int/geotoolkit3d/scene/volumetric/Constants';
import { DataOrder, DataType } from '@int/geotoolkit3d/scene/volumetric/Constants';
/**
 * A 3D Object that represent a unit cube with a 3D data texture which display a volume rendering. <br>
 * SinglePassRenderingVolume supports both 3D and 4D volume rendering.<br>
 * Creating a volume should follow the following steps:
 * 1. Instantiate the SinglePassVolumeRendering.<br>
 * 2. Initialize the data dimensions and type via .initializeVolume(), or via the constructor options in step 1.<br>
 * 3. Set the volume data via .setData().<br>
 * Further re-initialization of the Volume type/dimensions will discard existing data.<br>
 * <br>
 */
export declare class SinglePassRenderingVolume extends Object3D {
    constructor(options?: SinglePassRenderingVolume.Options);
    /**
     * Initialize Volume<br>
     * Define the volume type (3D/4D), its data dimensions (number of samples)
     * @param options SinglePassRenderingVolume.InitOptions
     * @returns this
     * @throws {Error} if volume already initialized.
     */
    initializeVolume(options: SinglePassRenderingVolume.InitOptions): this;
    /**
     * Set data to this volume
     * @param options SinglePassRenderingVolume.DataOptions
     * @returns this
     * @throws {Error} if the volume data is invalid.
     */
    setData(options: SinglePassRenderingVolume.DataOptions): this;
    /**
     * Set the index of the 4D volume
     * @param index The index for the 4th dimension: if the index provided is not an integer value,, it will interpolate between the two nearest integer-indexed volume data points.
     * @throws {Error} if the index is invalid.
     */
    set4DVolumeIndex(index: number): void;
    /**
     * Remove the volume data for the given index only, allowing garbage collection.<br>
     * If the volume index released is currently active and being viewed, it will continue to be able to render (as it is currently loaded on the GPU memory), until a different index is selected.
     * @param index The index for the 4th dimension
     */
    release4DVolumeIndex(index: number): void;
    /**
     * Return true if the specified 4D volume index is loaded and ready and can be selected via set4DVolumeIndex.
     * If false is returned, this means this index isn't loaded yet, or this volume is not 4D, and selection of that index via set4DVolumeIndex will have no effect and log a console warning.
     * @param index The index for the 4th dimension
     */
    is4DVolumeIndexReady(index: number): boolean;
    /**
     * Get the index of the 4D volume
     * @returns index The index for the 4th dimension
     */
    get4DVolumeIndex(): number;
    /**
     * Get data of this volume.<br>
     * @returns data options
     */
    getData(): SinglePassRenderingVolume.DataOptionsOut;
    /**
     * Update transfer function from an array of color string.
     * @param colors - Array of CSS color (like "rgba(x,x,x,x)" or "#ff00fc" or "0xff00fc")
     */
    updateColorMap(colors: string[]): void;
    /**
     * Set the SinglePassRenderingVolume options
     * @param options - The options
     * @returns this
     */
    setOptions(options?: SinglePassRenderingVolume.OptionsBase): this;
    /**
     * Get the SinglePassRenderingVolume options
     */
    getOptions(): SinglePassRenderingVolume.OptionsBaseOut;
    /**
     * Get current ray sampling rate used by volume.<br>
     * The ray sampling rate may change based on the user-defined setting in setOptions option.samplingrateoptions.<br>
     * If both enablequalitypass and enableadaptiverate options are disabled, the current sampling rate will be equal to the user-defined option 'samplingrateoptions.raysamplingrate'.<br>
     * If enablequalitypass or enableadaptiverate are enabled, the current sampling rate will change based on the following logic:
     * <ul><li>If enablequalitypass is enabled, the volume can render either in fast or quality mode</li><ul>
     * <li>In 'fast' mode, if enableadaptiverate is false, the sampling rate is set to the user-defined option samplingrateoptions.raysamplingrate.</li>
     * <li>In 'fast' mode, if enableadaptiverate is true, the sampling rate is set to an adaptive value based on current performance (minimum is samplingrateoptions.raysamplingrate, maximum is samplingrateoptions.maxsamplingrate).</li>
     * <li>In 'quality' mode (QualityRendering pass), the sampling rate is set to the user-defined option samplingrateoptions.maxsamplingrate.</li>
     * </ul>
     * <li> If enablequalitypass is disabled, the volume will render exclusively in 'fast' mode as described above</li>
     * </ul>
     * @returns current ray sampling rate
     */
    getCurrentRaySamplingRate(): number;
    /**
     * To update the camera position for the volume rendering
     * @param scene The scene
     * @param camera The camera used for this render phase.
     * @param plot The 3D plot
     * @param renderer The renderer
     * @returns this
     */
    beforeRender(scene: Scene, camera: Camera, plot: Plot, renderer: WebGLRenderer): this;
    /**
     * Check if adaptive sampling rate is supported on current browser/device.
     * @returns true if Supported, otherwise false.
     */
    isAdaptiveSamplingRateSupported(): boolean;
    /**
     * Dispose all event listeners, Object3D, cache
     */
    dispose(): void;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace SinglePassRenderingVolume {
    /**
     * The options
     */
    type OptionsBase = Object3D.Options & MaterialOptions;
    type OptionsBaseOut = Required<Object3D.Options> & MaterialOptions & {
        /**
         * Get the minimum value of the data
         * @deprecated Deprecated since 5.0, use getData().datamin instead.
         */
        datamin: number;
        /**
         * Get the maximum value of the data
         * @deprecated Deprecated since 5.0, use getData().datamax instead.
         */
        datamax: number;
    };
    /**
     * The options for constructor
     */
    type Options = Object3D.Options & MaterialOptions & {
        /**
         * The options for initializeVolume
         */
        datainitialization?: InitOptions;
        /**
         * Data for the volume, can either be provided from voxel information via the 'rawdata' parameter, or as a set of irregular 3D points via the 'points' parameter.
         * @deprecated since 5.0, use setData with DataOptions instead.
         */
        data?: {
            /**
             * The dimension of data values on each axis in toolkit coordinate system<br>
             * Right-hand, with Z-up, Y-right, X-forward
             */
            dimension?: {
                /** The number of volume samples on the X axis. */
                x: number;
                /** The number of volume samples on the Y axis. */
                y: number;
                /** The number of volume samples on the Z axis. */
                z: number;
            };
            /**
             * A typed 1D array that contain the volume 3D voxel data.<br>
             * If desired, and to save network bandwidth, values can be passed as Uint8Array directly: the values will be interpreted as normalized float encoded to integers.<br>
             * In this case, be sure to specify the data range via the datamin and datamax parameters.<br>
             */
            rawdata?: DataTypedArray;
            /**
             * Define the volume data using irregular points.<br>
             * A Point is represented by a Vector4, where x,y,z are the respective coordinates, and w is the point value.<br>
             */
            points?: Vector4[];
            /**
             * The original minimum value of the data in float.<br>
             * When using Uint8Array data arrays, specify the minimum value of the data.<br>
             * Uint arrays encode values as [0, 1] normalized floats then apply the datamin / datamax range to each value.
             */
            datamin?: number;
            /**
             * The original maximum value of the data in float.<br>
             * When using Uint8Array data arrays, specify the maximum value of the data.<br>
             * Uint arrays encode values as [0, 1] normalized floats then apply the datamin / datamax range to each value.
             */
            datamax?: number;
        };
    };
    /**
     * The Volume initialization options, they determine the volume dimensionality (3D or 4D), its data size (how many sample on each axis), and optionally the data loading order (Y-up or Z-up).
     */
    type InitOptions = (DataSize3D & {
        type: DataType.Volume3D;
    }) | (DataSize4D & {
        type: DataType.Volume4D;
    });
    /**
     * The common options for data descriptor.
     */
    type DataSizeCommon = {
        /**
         * The original minimum value of the data in float.<br>
         * When using Uint8Array data arrays, specify the minimum value of the data.<br>
         * Uint arrays encode values as [0, 1] normalized floats then apply the datamin / datamax range to each value.
         */
        datamin?: number;
        /**
         * The original minimum value of the data in float.<br>
         * When using Uint8Array data arrays, specify the maximum value of the data.<br>
         * Uint arrays encode values as [0, 1] normalized floats then apply the datamin / datamax range to each value.
         */
        datamax?: number;
        /**
         * Data order and coordinate system of the provided raw data.<br>
         * This class supports two data orders, ZUpZYX and YUpXYZ<br>
         * Please see the enum documentation {@link @int/geotoolkit3d/scene/volumetric/Constants~DataOrder} for more details.<br>
         * Default value is DataOrder.ZUpZYX
         */
        dataorder?: DataOrder;
    };
    /**
     * Data descriptor if the volume is 3D.
     */
    type DataSize3D = {
        /**
         * Describe the 3D volume data dimensions as a Vector3.<br>
         * The number of data samples on each axis in the coordinate system of the data itself.<br>
         */
        datadimensions: Vector3;
    } & DataSizeCommon;
    /**
     * Data descriptor if the volume is 4D.<br>
     * The 4th dimension can represent the 'time' axis, and is achieved by storing an array of 3D Volumes instead of a single 3D Volume.<br>
     * The volume to visualize can then be selected by setting the 4D index via .set4DVolumeIndex(), and can accept non-integer values in order to interpolate between two volume indices.
     */
    type DataSize4D = {
        /**
         * Describe the 4D volume data dimensions as a Vector4.<br>
         * The first 3 values represent the number of data samples on the x, y and z data axes.<br>
         * The 4th value of the vector represent the volume index axis. Since the 4D volume is internally handled as an array of 3D Volume, this value define how many volume are indexed. This index axis can represent 'time' as a 4th dimension, for example.
         */
        datadimensions: Vector4;
    } & DataSizeCommon;
    /**
     * The accepted options for the .setData method.<br>
     * Please note that the accepted options differ based on the 3D or 4D dimensionality of the volume defined by the user.
     */
    type DataOptions = (Data3D & {
        type: DataType.Volume3D;
    }) | (Data4D & {
        type: DataType.Volume4D;
    });
    /**
     * The Typed array formats accepted by the volume class.<br>
     * If desired, and to save network bandwidth, values can be passed as Uint8Array directly: the values will be interpreted as normalized float encoded to integers.<br>
     * In this case, be sure to specify the data range via the datamin and datamax parameters.<br>
     */
    type DataTypedArray = Float32Array | Uint8Array | Uint8ClampedArray;
    /**
     * The format for defining a 3D volume, where each sample is defined by the user (as opposed to the PointSet data).<br>
     * The volume data is passed as a single-dimension typed array.
     */
    type RawVolumeData = {
        rawdata: DataTypedArray;
    };
    /**
     * The format defining a 3D volume, from an irregular set of 3D weighted points.<br>
     * The volume class will then generate the voxel grid based on these points, the resolution of the voxel grid being defined by the user in the Volume dimentions initialization step (.initializeVolume method)
     */
    type PointSet = {
        /**
         * Each point in the point set is defined by a Vector4, where the x/y/z component define the point position, and the w component define the point value. Values can then be mapped to color with a colormap for better visualization of the data.<br>
         * The interpolation step used to generate the voxel grid will then use this w component and interpolate it based on distance, using the inverse distance weighting algorithm.
         */
        points: Vector4[];
    };
    /**
     * Define the data format for 3D volume, either a raw volume data (user specify individual sample of the 3D volume), or a weighted pointset which will be interpolated into a voxel grid internally.
     */
    type Data3D = RawVolumeData | PointSet;
    /**
     * The format for defining a 4D volume, where each sample is defined by the user (as opposed to the PointSet data).<br>
     * The 4D volume is represented by an array of 3D volumes, in which the array index represent the 4th dimension. Each individual 3D volume data is then represented by a single-dimension typed array.
     */
    type Data4D = {
        /**
         * A typed 1D array that contains the volume 3D voxel data at the specific index on the 4th dimension.<br>
         */
        rawdata: DataTypedArray;
        /**
         * The index of 4th dimension of the 4D volume.
         */
        index: number;
    };
    /**
     * The output option of 4D volume data.
     */
    type Data4DOptionsOut = {
        /**
         * An array of typed 1D array that contains the volume 3D voxel data in different timestamps.<br>
         */
        rawdataarray: DataTypedArray[];
    };
    /**
     * The data returned by the getData method.<br>
     * Please note that the returned format differ based on the 3D or 4D dimensionality of the volume defined by the user.
     */
    type DataOptionsOut = (Data3D & DataSize3D & {
        type: DataType.Volume3D;
    }) | (Data4DOptionsOut & DataSize4D & {
        type: DataType.Volume4D;
    });
    /**
     * The volume options related to rendering, such as the colormap, sampling rate, raytracing modes and more.
     */
    type MaterialOptions = {
        /**
         * The volume dimensions in world space coordinates.<br>
         * (Not to be confused with the data dimensions, ie: how many voxels on each axis does the data contain).<br>
         * Default value is (1.0, 1.0, 1.0), and will be scaled equally proportioned to the data dimensions.
         */
        volumedimension?: Vector3;
        /**
         * Transfer function option<br>
         * User can use either a texture as transfer function or an array of color string<br>
         * User can also specify the value range that maps to the transfer function by setting minvalue and maxvalue<br>
         * Note that these values need to be in the original float type.<br>
         * By default, minvalue will be 'datamin' of the data, maxvalue will be 'datamax' of the data.
         */
        transferfunc?: {
            /**
             * An array of color string or a texture that represents the transfer function
             */
            colormap?: string[] | Texture;
            /**
             * The min value of the data map to the transfer function.<br>
             * By default, the min value of data will be used.
             */
            minvalue?: number;
            /**
             * The max value of the data map to the transfer function.<br>
             * By default, the min value of data will be used.
             */
            maxvalue?: number;
        };
        /**
         * Data texture sampling mode.<br>
         * Default value is SamplingMode.Liner.
         */
        samplingmode?: SamplingMode;
        /**
         * The corrective factor for the alpha transparency.<br>
         * This alpha factor affects the opacity of each raytraced sample, higher alpha means the volume becomes more opaque.<br>
         * Default value is 1.0.
         */
        alphacorrectionfactor?: number;
        /**
         * Ray sampling rate multiplier, affects how many samples per voxel are computed in each ray, default is 1.<br>
         * The sampling rate can be set to anything between 0.1 and 10.0, but bear in mind a higher sampling rate will result in worse performances.<br>
         * If it is set to 2, it means 2x the usual sampling (higher quality, slower)<br>
         * If it is set to 0.5, it means 0.5x the usual sampling (lower quality, faster).<br>
         * Higher samplings above 1x have diminishing returns, with virtually no improvement after 2x (excepted for Surface mode which is specific).<br>
         * In Surface mode, when using linear/cubic interpolation, more samples increase the accuracy of the interpolation and can reduce the noise artifacts.
         * @deprecated Deprecated since 5.0, please use options.samplingrateoptions.raysamplingrate instead.
         */
        raysamplingrate?: number;
        /**
         * The mode of the volume rendering.<br>
         * Default value is RenderingMode.DVR.
         */
        renderingmode?: RenderingMode;
        /**
         * When in Surface rendering mode, define the visible value ranges.<br>
         * Up to 4 range (datamin, datamax) can be defined.<br>
         * When multiple ranges are defined, the final visible range will be the Union of all ranges.<br>
         * Default is one range from datamin to datamax if data has been set.<br>
         * If data is empty, default value is null.<br>
         * @example
         * import {Vector2} from 'three';
         * import {RenderingMode} from '@int/geotoolkit3d/scene/volumetric/Constants';
         * // Change rendering to surface mode, turn on lighting, and filter values so that
         * // only values in the union of ranges [0, 3] U [5, 7] U [9, 10] will be rendered.
         * renderingVolume.setOptions({
         *     renderingmode: RenderingMode.Surface,
         *     surfaceranges: [
         *                      new Vector2(0, 3),
         *                      new Vector2(5, 7),
         *                      new Vector2(9, 10)
         *                      ]
         * });
         */
        surfaceranges?: Vector2[];
        /**
         * Enable the simulation of lighting/shading of the volume rendering, by interpreting the differences in values as 3D surfaces the light can bounce off.<br>
         * This can improve the sense of depth/surface in some cases.<br>
         * The rendering might become slower when enabled.
         */
        enablelighting?: boolean;
        /**
         * Defines the clipping planes
         * see {@link https://threejs.org/docs/#api/en/materials/Material.clippingPlanes})
         */
        clippingplanes?: Plane[];
        /**
         * Define clip intersection
         * see {@link https://threejs.org/docs/#api/en/materials/Material.clipIntersection})
         */
        clipintersection?: boolean;
        /**
         * Options for the sampling rate
         */
        samplingrateoptions?: {
            /**
             * Enable quality pass rendering, when enabled:<br>
             * During plot's FastRendering pass the volume will use 'raysamplingrate' as sampling rate value for increased performances.<br>
             * Once the plot starts Quality Rendering Pass, it will use 'maxsamplingrate' for increased quality on the still image.<br>
             * plot quality pass needs to be enabled by Plot option.advancedrendering.qualityrenderpass.enable.<br>
             * Default is true.
             */
            enablequalitypass?: boolean;
            /**
             * Ray sampling rate multiplier, affects how many samples per voxel are computed in each ray, default is 1.0.<br>
             * The sampling rate can be set to anything between 0.1 and 10.0, but bear in mind a higher sampling rate will result in worse performances.<br>
             * If it is set to 2, it means 2x the usual sampling (higher quality, slower)<br>
             * If it is set to 0.5, it means 0.5x the usual sampling (lower quality, faster).<br>
             * Higher samplings above 1x have diminishing returns, with virtually no improvement after 2x (excepted for Surface mode which is specific).<br>
             * In Surface mode, when using linear/cubic interpolation, more samples increase the accuracy of the interpolation and can reduce the noise artifacts.
             */
            raysamplingrate?: number;
            /**
             * The sampling rate on QualityRendering pass. Default is 1.0.
             */
            maxsamplingrate?: number;
            /**
             * Enable adaptively adjusting the rendering quality based on the hardware capabilities.<br>
             * Faster GPUs will use a higher sampling rate (up to maxsamplingrate).<br>
             * User can set the target GPU frame time (the time needed to render a frame) in 3D Plot option.advancedrendering.performancemetrics.targetgpuframetime.<br>
             * Default is false.
             */
            enableadaptiverate?: boolean;
        };
    };
}
