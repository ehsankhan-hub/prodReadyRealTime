/**
 * @module geotoolkit3d/scene/volumetric/Constants
 */
/**
 * Volume Rendering Mode.<br>
 * This enum is used to describe the rendering mode of the volume.
 * @enum
 * @readonly
 */
export declare enum RenderingMode {
    /**
     * Direct Volume Rendering<br>
     * DVR stands for Direct Volume Rendering, which is the classic volume rendering mode.<br>
     * In this mode, the volume is rendered by raycasting, accumulating the voxels values along the ray path, taking into account the voxel sample opacity.<br>
     * Once the ray's accumulated voxel samples reach full opacity, the ray do not travel further.<br>
     * The voxels opacity is affected by the transfer function, to give users full control over the values transparency.
     */
    DVR = "DVR",
    /**
     * Direct Volume Rendering with value of volume for opacity<br>
     * This mode stands for Direct Volume Rendering using voxel value as alpha.<br>
     * Similarly to the regular DVR mode, the volume is rendered by raycasting, accumulating the voxels values along the ray path, taking into account the voxel sample opacity.<br>
     * The main difference is in this mode, the value themselves are used for opacity. The stronger the value, the more opaque the voxel. This is the legacy behavior in classic CT scan volume renderers.
     */
    DVRValueAsAlpha = "DVRValueAsAlpha",
    /**
     * Maximum Intensity Projection<br>
     * MIP stands for Maximum Intensity Projection.<br>
     * In this mode, the fragment color is determined by the voxel with maximum intensity value along the ray.<br>
     * This mode is classic in CT scan visualisation, where the data represent density value, so the data can be better visualized by favoring higher density values.<br>
     * To enable fine control over which value is prioritized, please instead use MIP_CUSTOM.
     */
    MIP = "MIP",
    /**
     * Customized Maximum Intensity Projection<br>
     * This mode is implemented based on MIP mode, but offers more freedom for user to use transfer function to control the result.<br>
     * Instead of prioritizing voxels with the highest value, it use the transfer function's opacity to determine the value to prioritize.
     */
    MIPCustom = "MIPCustom",
    /**
     * Iso 'Surface' Rendering<br>
     * In stead of actually generated surface, this mode will cast a ray from camera and render the first voxel within up to four ranges specified by user.<br>
     * The ranges can be set from option surfaceranges. By default, for each range, the min of the range is set as datamin, the max of the range is set as datamax.<br>
     * Because of the nature of Surface mode, enabling the Volume rendering Lighting can improve the visual result, but the performances will be affected.
     */
    Surface = "Surface"
}
/**
 * Sampling Mode.<br>
 * This enum is used to describe the sampling mode of the volume data texture.
 * @enum
 * @readonly
 */
export declare enum SamplingMode {
    /**
     * Nearest Neighbor mode<br>
     * Use nearest neighbor (also called step interpolation) to sample the volume data texture.
     */
    Nearest = "Nearest",
    /**
     * Linear Interpolation mode<br>
     * Use tri-linear filtering (also called linear interpolation) to sample the volume data texture.
     */
    Linear = "Linear",
    /**
     * Cubic Interpolation mode<br>
     * Use tri-cubic filtering (also called cubic interpolation) to sample the volume data texture.<br>
     * Warning: this filtering is much slower compared to Nearest and Linear mode, due to the increased sampling.<br>
     * It is not recommended to use this filtering with lower-end GPUs and devices such as older integrated GPUs.<br>
     * To mitigate performance impact, a lower sampling rate can be set on the Volume object.
     */
    Cubic = "Cubic"
}
/**
 * Type of the data.<br>
 * This enum is used to describe the type of the data
 * @enum
 * @readonly
 */
export declare enum DataType {
    /**
     * A single 3D volume
     */
    Volume3D = "Volume3D",
    /**
     * A 4D volume
     */
    Volume4D = "Volume4D"
}
/**
 * Data order and coordinate system.<br>
 * This enum is used to describe the coordinate system and reading/writing order of the data.
 * @enum
 * @readonly
 */
export declare enum DataOrder {
    /**
     * Data in Y-Up, right hand coordinate system.<br>
     * Commonly used in medical and general volume imagery.<br>
     * When in this mode, the raw data array needs to be provided in the order X Y Z, like so:
     * @example
     *   +------+
     *  /      /|
     * +------+ | <- Y
     * |      | +
     * |      |/ <- Z
     * +------+
     *    X
     */
    YUpXYZ = "YUpXYZ",
    /**
     * Data in Z-Up, right hand coordinate system.<br>
     * Commonly used to store seismic volumes, where samples (Z axis) are read the most frequently.<br>
     * When in this mode, the raw data array needs to be provided in the order Z Y X, like so:
     * @example
     *   +------+
     *  /      /|
     * +------+ | <- Z
     * |      | +
     * |      |/ <- X
     * +------+
     *    Y
     */
    ZUpZYX = "ZUpZYX"
}
