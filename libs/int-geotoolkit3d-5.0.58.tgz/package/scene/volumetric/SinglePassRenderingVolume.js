/* eslint-disable */

export {Dhi as SinglePassRenderingVolume} from '@int/impl/geotoolkit3d.js';
