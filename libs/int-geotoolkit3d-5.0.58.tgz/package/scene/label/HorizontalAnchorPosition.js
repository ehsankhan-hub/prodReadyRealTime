/* eslint-disable */

export {q6t as HorizontalAnchorPosition} from '@int/impl/geotoolkit3d.js';
