/* eslint-disable */

export {U6t as VerticalAnchorPosition} from '@int/impl/geotoolkit3d.js';
