/* eslint-disable */

export {l9t as Label} from '@int/impl/geotoolkit3d.js';
