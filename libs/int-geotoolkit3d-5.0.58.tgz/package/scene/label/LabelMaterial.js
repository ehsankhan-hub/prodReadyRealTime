/* eslint-disable */

export {T6t as LabelMaterial} from '@int/impl/geotoolkit3d.js';
