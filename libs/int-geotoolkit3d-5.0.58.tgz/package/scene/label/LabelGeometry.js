/* eslint-disable */

export {H6t as LabelGeometry} from '@int/impl/geotoolkit3d.js';
