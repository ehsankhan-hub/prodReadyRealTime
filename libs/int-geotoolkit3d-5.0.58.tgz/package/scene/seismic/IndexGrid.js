/* eslint-disable */

export {Gei as IndexGrid} from '@int/impl/geotoolkit3d.js';
