/* eslint-disable */

export {lei as ITiledSurface} from '@int/impl/geotoolkit3d.js';
