import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { Mesh, Vector3 } from 'three';
import type { FenceMaterial } from '@int/geotoolkit3d/scene/seismic/FenceMaterial';
import type { IndexCoordinates } from '@int/geotoolkit3d/transformation/IndexCoordinates';
import type { Group } from '@int/geotoolkit/scene/Group';
import { ITiledSurface } from '@int/geotoolkit3d/scene/seismic/ITiledSurface';
import { ICustomHighlight } from '@int/geotoolkit3d/scene/ICustomHighlight';
import type { SliceMaterial } from '@int/geotoolkit3d/scene/seismic/SliceMaterial';
import { ISeismicObject } from '@int/geotoolkit3d/scene/seismic/ISeismicObject';
import type { SeismicPipeline } from '@int/geotoolkit/seismic/pipeline/SeismicPipeline';
import { Point } from '@int/geotoolkit/util/Point';
import { IOverlayableObject } from '@int/geotoolkit3d/util/intersection/IOverlayableObject';
/**
 * A seismic fence object.<br>
 * <br>
 * A seismic fence is the cross-section along a given 2D arbitrary path.<br>
 * It's composed of contiguous seismic panels that form a fence.<br>
 */
export declare class FencePanel extends Object3D implements ITiledSurface, ICustomHighlight, ISeismicObject, IOverlayableObject {
    constructor(options: FencePanel.Options);
    /**
     * Set this FencePanel options
     */
    setOptions(options?: FencePanel.OptionsBase): this;
    /**
     * Get this FencePanel options
     */
    getOptions(): FencePanel.OptionsBaseOut;
    /**
     * Returns the group used to render 2D shapes on top of the seismic Fence.<br>
     * The coordinate system of the group is in trace/samples.
     */
    getOverlay(): Group | null;
    /**
     * Get the Fences's material
     * @returns This slice's material
     */
    getFenceMaterial(): FenceMaterial;
    /**
     * Returns the plane mesh, used in intersections
     */
    getMesh(): Mesh;
    /**
     * Return the overlay texture bounds of this panel unit, in pixels.<br>
     * In fences, the first panel's x value is zero, then each consecutive panel adds the previous panels width.
     */
    getOverlayTextureBounds(): import("../../../geotoolkit/util/Rect").Rect;
    /**
     * Get the selected FencePanel object(s) that will generate a highlight
     */
    getHighlightedObjects(): FencePanel | FencePanel[];
    /**
     * Used for intersection API
     */
    setOverlay(overlayGroup: Group): this;
    /**
     * Return the world position of a specific corner of this panel quad.<br>
     * If this panel (or a parent object) has been moved/rotated since the last render,
     * please call Fence.updateWorldMatrix(true, true), or FencePanel.updateWorldMatrix(true, true) first for correct results.
     * (Updating the Fence will update all its children FencePanel at once.)<br>
     * If the fence is made of several tiles, the corners will still represent the global panel.
     * @param index Index of the panel quad, from 0 to 3.
     * @param target Optional point Vector3, will be updated and returned if provided.
     * @example
     * The indices represent the 4 corners of the quad like so:
     * 0---1
     * |   |
     * 2---3
     */
    getCorner(index: number, target?: Vector3): Vector3;
    /**
     * Return the local position of a specific corner of this panel quad. This method is mainly used for intersection purposes.<br>
     * For coordinates calculation accuracy purpose, local panel coordinates might not match the provided coordinates at construction time.<br>
     * For this reason, it is recommended to users to instead use getCorner, which apply all parent's matrix transformations.<br>
     * If the fence is made of several tiles, the corners will still represent the global panel.
     * @param index Index of the panel quad, from 0 to 3.
     * @param target Optional point Vector3, will be updated and returned if provided.
     * @example
     * The indices represent the 4 corners of the quad like so:
     * 0---1
     * |   |
     * 2---3
     */
    getLocalCorner(index: number, target?: Vector3): Vector3;
    /**
     * Dispose method for FencePanel
     */
    dispose(): void;
    resetTiles(): void;
    getPipeline(): SeismicPipeline;
    getSeismicModelPosition(worldPosition: Vector3): Point;
}
export declare namespace FencePanel {
    type Options = OptionsBase & {
        /**
         * The slice's material containing the seismic textures
         */
        material: FenceMaterial;
        /**
         * data
         */
        data: {
            /**
             * index coordinates
             */
            index: IndexCoordinates;
            /**
             * The fence coordinates
             */
            path: {
                /**
                 * The inline indices of the fence
                 */
                i?: number[];
                /**
                 * The xline indices of the fence
                 */
                j?: number[];
            };
        };
    };
    type OptionsBase = Object3D.Options & SliceMaterial.OptionsBase;
    type OptionsBaseOut = Required<Object3D.Options> & SliceMaterial.OptionsBaseOut;
}
