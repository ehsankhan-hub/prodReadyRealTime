/* eslint-disable */

export {xei as Volume} from '@int/impl/geotoolkit3d.js';
