/**
 * @module geotoolkit3d/scene/seismic/Fence
 */
import { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import { FencePanel } from '@int/geotoolkit3d/scene/seismic/FencePanel';
import { ICustomHighlight } from '@int/geotoolkit3d/scene/ICustomHighlight';
import { ITiledSurface } from '@int/geotoolkit3d/scene/seismic/ITiledSurface';
import type { IndexCoordinates } from '@int/geotoolkit3d/transformation/IndexCoordinates';
import type { SliceMaterial } from '@int/geotoolkit3d/scene/seismic/SliceMaterial';
import { MultiPanelHighlightMode } from '@int/geotoolkit3d/Constants';
import { IIntersectableMesh } from '@int/geotoolkit3d/util/intersection/IIntersectableMesh';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
import type { Box3 } from 'three';
/**
 * A seismic fence object that represent the cross section of a seismic volume with an arbitrary line.<br>
 * <br>
 * A seismic fence can be used to display seismic along a user crafted path or a well trajectory for example.<br>
 * The resulting shape will be composed of contiguous seismic panels that form a fence.<br>
 * <br>
 * The given coordinates describes the inflexion points of the path.<br>
 * It's expected to be in IJ coordinates and to match actual existing IJ indices.<br>
 * <br>
 * This shape uses a {@link @int/geotoolkit/seismic/data/SeismicReader~SeismicReader} to fetch the traces and metadata.<br>
 * The reader's metadata should contain the proper 'sections' in order for the fence to display correctly.<br>
 * This Shape is compatible with {@link @int/geotoolkit/seismic/data/RemoteSeismicReader~RemoteSeismicReader RemoteSeismicReader} using INTGeoServer. (version >= 2.18)<br>
 * <br>
 * As the rasterization process is delegated to the SeismicPipeline, all the capabilities of the pipeline are available (colormap, interpolation, etc).<br>
 * It can be configured at initialization time using 'options.pipeline.options'.<br>
 * And/Or at runtime using <br>
 * <pre>
 * `setOptions({ pipeline:{ options:{...} } })`
 * </pre>
 * <br>
 * This fence also supports an 'overlay' feature that lets you provide a {@link @int/geotoolkit/scene/Group~Group group} containing 2D shapes.<br>
 * The content of this group will be rendered on top of the seismic.<br>
 * This group modellimits and bounds will be automatically set to the correct values.<br>
 * The group's content should use coordinates in trace/sample domain.<br>
 * Note that this group will be rasterized in a way similar to how the seismic is rasterized itself.<br>
 * <br>
 */
export declare class Fence extends Object3D implements ITiledSurface, ICustomHighlight, IIntersectableMesh {
    constructor(options: Fence.Options);
    getTriangle(triangleIndex: number, target: IIntersectableMesh.TriangleData): void;
    getTriangleCount(): number;
    getMeshBoundingBox(target: Box3): void;
    getColorProvider(): ColorProvider | RgbaColor;
    /**
     * Set the Fence options
     */
    setOptions(options?: Fence.OptionsBase): this;
    /**
     * Get the Fence options
     */
    getOptions(): Fence.OptionsBaseOut;
    /**
     * Returns an array that contains all the fence panels
     * @deprecated since 5.0, please use getFencePanels() instead for more correct naming
     * @returns panels
     */
    getFencePanel(): FencePanel[];
    /**
     * Returns an array that contains all the fence panels
     * @returns fence panels
     */
    getFencePanels(): FencePanel[];
    /**
     * Get selected fence panels in the Fence that will generate a highlight
     */
    getHighlightedObjects(): FencePanel[];
    /**
     * Get the index coordinates
     * @returns The index coordinates
     */
    getIndexCoordinates(): IndexCoordinates;
    resetTiles(): void;
}
export declare namespace Fence {
    export type Options = Object3D.Options & SliceMaterial.Options & HighlightOptions & {
        /**
         * The options related to the seismic data
         */
        data: {
            /**
             * index coordinates
             */
            index: IndexCoordinates;
            /**
             * The fence coordinates
             */
            path: {
                /**
                 * The inline indices of the fence
                 */
                i: number[];
                /**
                 * The xline indices of the fence
                 */
                j: number[];
            };
        };
    };
    export type OptionsBase = Object3D.Options & FencePanel.OptionsBase & HighlightOptions;
    export type OptionsBaseOut = Required<Object3D.Options> & Partial<FencePanel.OptionsBase>;
    type HighlightOptions = {
        /**
         * Set the Seismic Fence highlight mode. Available modes include highlight by single FencePanel or highlight the entire Fence.
         * Default is MultiPlaneHighlightMode.AllPanels
         */
        highlightmode?: MultiPanelHighlightMode;
    };
    export {};
}
