/* eslint-disable */

export {tni as FencePanel} from '@int/impl/geotoolkit3d.js';
