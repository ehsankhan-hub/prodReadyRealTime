/* eslint-disable */

export {Dei as Slice} from '@int/impl/geotoolkit3d.js';
