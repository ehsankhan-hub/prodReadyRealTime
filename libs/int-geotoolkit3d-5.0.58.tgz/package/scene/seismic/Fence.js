/* eslint-disable */

export {nni as Fence} from '@int/impl/geotoolkit3d.js';
