/* eslint-disable */

export {zei as SliceMaterial, Vei as Events} from '@int/impl/geotoolkit3d.js';
