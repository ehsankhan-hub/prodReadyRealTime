/**
 * @module geotoolkit3d/scene/seismic/ISeismicObject
 */
import type { SeismicPipeline } from '@int/geotoolkit/seismic/pipeline/SeismicPipeline';
import type { Vector3 } from 'three';
import type { Point } from '@int/geotoolkit/util/Point';
/**
 * Interface for 3d objects, that visualize seismic planes.
 */
export declare abstract class ISeismicObject {
    /**
     * Returns seismic pipeline
     */
    abstract getPipeline(): SeismicPipeline;
    /**
     * Get position in seismic model limits from 3d world position
     * @param worldPosition position in 3d world coordinates
     */
    abstract getSeismicModelPosition(worldPosition: Vector3): Point;
}
