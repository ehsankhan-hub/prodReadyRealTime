/* eslint-disable */

export {ini as FenceMaterial} from '@int/impl/geotoolkit3d.js';
