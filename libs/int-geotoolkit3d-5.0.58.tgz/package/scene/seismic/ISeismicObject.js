/* eslint-disable */

export {oei as ISeismicObject} from '@int/impl/geotoolkit3d.js';
