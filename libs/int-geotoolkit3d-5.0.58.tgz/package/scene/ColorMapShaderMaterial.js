/* eslint-disable */

export {kzt as ColorMapShaderMaterial} from '@int/impl/geotoolkit3d.js';
