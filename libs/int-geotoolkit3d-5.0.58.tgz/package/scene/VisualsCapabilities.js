/* eslint-disable */

export {jzt as Limitation} from '@int/impl/geotoolkit3d.js';
