/* eslint-disable */

export {B9t as FilledEllipseGeometry} from '@int/impl/geotoolkit3d.js';
