/* eslint-disable */

export {s2t as EllipseGeometry} from '@int/impl/geotoolkit3d.js';
