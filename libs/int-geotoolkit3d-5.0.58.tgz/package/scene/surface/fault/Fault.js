/* eslint-disable */

export {k7t as Fault} from '@int/impl/geotoolkit3d.js';
