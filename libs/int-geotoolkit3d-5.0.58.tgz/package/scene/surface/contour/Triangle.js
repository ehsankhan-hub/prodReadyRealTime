/* eslint-disable */

export {m8t as Triangle} from '@int/impl/geotoolkit3d.js';
