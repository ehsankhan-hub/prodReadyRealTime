/* eslint-disable */

export {o7t as MajorMinorStrategy} from '@int/impl/geotoolkit3d.js';
