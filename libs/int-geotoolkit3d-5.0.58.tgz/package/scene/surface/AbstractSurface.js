/* eslint-disable */

export {w8t as AbstractSurface} from '@int/impl/geotoolkit3d.js';
