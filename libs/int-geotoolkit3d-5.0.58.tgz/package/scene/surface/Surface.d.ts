/**
 * @module geotoolkit3d/scene/surface/Surface
 */
import type { Box2, Color } from 'three';
import { Box3 } from 'three';
import { AbstractSurface } from '@int/geotoolkit3d/scene/surface/AbstractSurface';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import type { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { HeightMapElevationValueMode } from '@int/geotoolkit3d/Constants';
import { HighlightMode } from '@int/geotoolkit3d/scene/surface/SurfaceConstants';
import { IIntersectableMesh } from '@int/geotoolkit3d/util/intersection/IIntersectableMesh';
import { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
import { Limitation } from '@int/geotoolkit3d/scene/VisualsCapabilities';
/**
 * A Surface 3D object.<br>
 * <br>
 * This object represents a 3D surface with an optional attribute used for coloring.<br>
 * The surface's geometry is defined by the given SurfaceData.<br>
 * <br>
 * The surface will contains holes whenever the given attribute or elevation is equals to nullvalue.<br>
 * Note that the current implementation still generates the vertices for those points but abstain itself from rendering them.<br>
 * <br>
 * @throws {Error} if options object has no AbstractSurfaceData inside
 */
export declare class Surface extends AbstractSurface implements IIntersectableMesh {
    static ESTIMATE_RAM_PER_VERTEX: number;
    static ESTIMATE_RAM_PER_VERTEX_INTERSECTION: number;
    static ESTIMATE_VRAM_PER_VERTEX: number;
    static MAX_VALUES_PER_ELEMENT: number;
    constructor(options: Surface.Options);
    getTriangle(triangleIndex: number, target: IIntersectableMesh.TriangleData): void;
    getTriangleCount(): number;
    getMeshBoundingBox(target: Box3): void;
    getColorProvider(): ColorProvider | RgbaColor;
    /**
     * Set options, the given json will be merged with the object's state so that only the given options will be changed.<br>
     * @param [options] The options to change
     * @returns this
     */
    setOptions(options?: Surface.OptionsBase): this;
    /**
     * Get surface options
     */
    getOptions(): Surface.OptionsBaseOut;
    /**
     * Return this object's data (geometry, values) when available.
     * Because data can be large, they are returned by reference (no copies).
     */
    getData(): AbstractSurface.Geometry.DataOut;
    /**
     * Set this Surface data.
     */
    setData(data: AbstractSurface.Geometry.Data): this;
    clear(): this;
    /**
     * Estimate the maximum number of vertices that can be created in one Surface visual, with the given RAM/VRAM information.<br>
     * With enough memory, the implementation limit for Surface is eventually tied to Typed array allocation.
     * This test will perform a one-time array allocation test on your device, to accurately estimate the maximum array
     * size your browser/device is capable of. It is important to have enough memory available for this test to be accurate.
     */
    static estimateMemoryCapabilities(options: Surface.MemoryEstimationOptions): Surface.MemoryCapabilitiesInfo;
}
export declare namespace Surface {
    /**
     * The options to use to create the surface
     */
    export type Options = AbstractSurface.Geometry.Options & AbstractSurface.Material.Options & CommonOptionsBase;
    export type OptionsBase = AbstractSurface.Material.OptionsBase & CommonOptionsBase;
    export type OptionsBaseOut = AbstractSurface.Material.OptionsBaseOut & CommonOptionsBaseOut;
    type CommonOptionsBase = Object3D.Options & AbstractSurface.TextureOptionsIn & Partial<CommonOptions> & {
        /**
         * A color provider or a single color in css format
         */
        colorprovider?: ColorProvider | string | Color;
        /**
         * The Surface Data options.
         */
        data?: {
            /**
             * The interpretation mode for converting the heightmap texture colors into actual elevation values.<br>
             * Default mode is "BlackAndWhite".<br>
             * For HeightMap usage only.
             */
            valuemode?: HeightMapElevationValueMode;
        };
    };
    type CommonOptionsBaseOut = Required<Object3D.Options> & AbstractSurface.TextureOptionsOut & CommonOptions & {
        /**
         * The value used to signal the absence of value in the data values.
         */
        nullvalue: number;
        /**
         * The minimum z value
         */
        zmin: number;
        /**
         * The maximum z value
         */
        zmax: number;
    };
    type CommonOptions = {
        /**
         * the lowest level of tile layer
         */
        minlod: number;
        /**
         * the highest level of tile layer
         */
        maxlod: number;
        /**
         * visible model limits of elevation (WGS84 full limits by default)
         */
        extent: Box2;
        /**
         * model limits of elevation (WGS84 full limits by default)
         */
        maplimits: Box2;
        /**
         * tile width
         */
        tilewidth: number;
        /**
         * tile height
         */
        tileheight: number;
        /**
         * object for loading texture tiles
         */
        material: CanvasServer;
        /**
         * object for loading geometry tiles
         */
        geometry: CanvasServer;
        /**
         * maximum requests at the same time (for network optimization)
         */
        maximumrequests: number;
        /**
         * Define how the Surface will be highlighted when selected.<br>
         * Default is HighlightMode.ContourHighlight for regular Surfaces, or HighlightMode.HaloHighlight for HeightMap surfaces.
         */
        highlightmode?: HighlightMode;
    };
    export type CanvasServer = {
        /**
         * server for loading tiles
         */
        server: string;
        /**
         * formatter function for loading tiles
         */
        formatterfunction: FormatterFunction;
    };
    type FormatterFunction = (z: number, y: number, x: number) => string;
    export type MemoryCapabilitiesInfo = {
        /**
         * The maximum number of vertices that can be loaded safely, with the given memory information.<br>
         * For example, if the result is 1000,000 vertices, one can imagine loading a Surface of dimensions of 1000 * 1000
         * (or any combinations that leads to one million).<br>
         * Please keep in mind this is only an estimation, even if the VRAM option is provided, browsers and OSes handle
         * RAM and VRAM memory very differently.
         */
        maxvertices: number;
        /**
         * Describe the current bottleneck for the provided estimation.<br>
         * Please note that if the VRAM argument is not provided, it is not possible to tell if the GPU memory is the current limitation.
         */
        limitation: Limitation;
    };
    export type MemoryEstimationOptions = {
        /**
         * The amount of estimated available RAM in bytes, that the Surface visual can allocate.<br>
         * On average, Surface will use 40 bytes of RAM per cell.<br>
         * Additional features such as intersections and transparency can create additional memory spikes.
         */
        ram: number;
        /**
         * (Optional) The amount of estimated available VRAM (Video Memory) in bytes, that the Surface visual can allocate.<br>
         * Surface will use 28 bytes of VRAM per cell.
         */
        vram?: number;
        /**
         * (Optional) Use an extra amount of RAM per cell if intersections are used.
         * Default is false.
         */
        useintersection?: boolean;
    };
    export {};
}
