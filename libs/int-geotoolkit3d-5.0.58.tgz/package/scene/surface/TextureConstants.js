/* eslint-disable */

export {Q8t as TextureType, E8t as TextureCoordinateMode} from '@int/impl/geotoolkit3d.js';
