/* eslint-disable */

export {AXt as ICustomHighlight} from '@int/impl/geotoolkit3d.js';
