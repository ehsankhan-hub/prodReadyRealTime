/* eslint-disable */

export {fzt as Object3D} from '@int/impl/geotoolkit3d.js';
