/* eslint-disable */

export {L6t as Plane} from '@int/impl/geotoolkit3d.js';
