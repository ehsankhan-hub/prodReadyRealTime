/* eslint-disable */

export {I8t as PlaneMaterial} from '@int/impl/geotoolkit3d.js';
