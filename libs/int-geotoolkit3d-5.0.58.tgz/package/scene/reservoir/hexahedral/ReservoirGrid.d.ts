/**
 * @module geotoolkit3d/scene/reservoir/hexahedral/ReservoirGrid
 */
import type { Box3, Vector4 } from 'three';
import { BufferGeometry, Mesh } from 'three';
import { AbstractReservoirGrid } from '@int/geotoolkit3d/scene/reservoir/AbstractReservoirGrid';
import type { Merge } from '@int/geotoolkit/base';
import { HighlightMode } from '@int/geotoolkit3d/scene/reservoir/HighlightMode';
import { IJKIndex } from '@int/geotoolkit3d/scene/reservoir/IJKIndex';
import type { ReservoirData } from '@int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData';
import type { Plot } from '@int/geotoolkit3d/Plot';
import type { Object3D } from '@int/geotoolkit3d/scene/Object3D';
import type { IJKValueFilter } from '@int/geotoolkit3d/scene/reservoir/IJKValueFilter';
import type { MeshColorMapBasicMaterial } from '@int/geotoolkit3d/scene/MeshColorMapBasicMaterial';
import type { SkeletonOptions } from '@int/geotoolkit3d/scene/reservoir/SkeletonOptions';
import { DisplayMode } from '@int/geotoolkit3d/scene/reservoir/DisplayMode';
import { IIntersectablePolyhedron } from '@int/geotoolkit3d/util/intersection/IIntersectablePolyhedron';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import type { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
import { Limitation } from '@int/geotoolkit3d/scene/VisualsCapabilities';
/**
 * A 3D Reservoir object.<br>
 *
 * This object represents the 3D visualization of a reservoir grid with an optional attribute used for coloring.<br>
 * The reservoir cell's geometry and values is defined by the given ReservoirData, and the cell visibility is determined by user-defined filters.
 *
 * The skeleton (outline) is drawn simultaneously as the cell in the GPU fragment stage, so it doesn't need extra CPU/memory resources.<br>
 *
 * The default DisplayMode is showing mesh, skeleton, but not horizons.<br>
 *
 * Note: ReservoirGrid works with transparent colors, but for correct visualization occlusion will be switched off.
 * So performance in case of transparent colors will be worse than with only opaque colors.
 */
export declare class ReservoirGrid extends AbstractReservoirGrid implements IIntersectablePolyhedron {
    static ESTIMATE_RAM_PER_CELL: number;
    static ESTIMATE_RAM_PER_CELL_INTERSECTION: number;
    static ESTIMATE_VRAM_PER_CELL: number;
    static MAX_VALUES_PER_ELEMENT: number;
    static ADDITIONAL_PROPERTY_SIZE: number;
    constructor(options: ReservoirGrid.Options);
    getPolyhedronsBoundingBox(target: Box3): void;
    getPolyhedron(polyhedronIndex: number, target: IIntersectablePolyhedron.PolyhedronCellData): void;
    isPolyhedronIndexFilteredOut(polyhedronIndex: number): boolean;
    getPolyhedronCount(): number;
    getColorProvider(): ColorProvider | RgbaColor;
    /**
     * Change the cells values, and/or define additional cell data.<br>
     * Changing cell values will change the active cells properties used with the colormap, and reset the "value" filter.<br>
     * Additional cell data are named properties that can be then used in a custom filter function.<br>
     * To remove additional cell data, please use ReservoirGrid.deleteAdditionalCellData.
     */
    setCellsValues(cellsValues: ReservoirData.CellsValues): this;
    /**
     * Set this Reservoir Grid options.<br>
     * Changing position data using setOptions is not allowed, as it is more expensive than creating a new Reservoir Grid.
     */
    setOptions(options: ReservoirGrid.OptionsBase): this;
    /**
     * Get this Reservoir Grid options.
     */
    getOptions(): ReservoirGrid.OptionsBaseOut;
    /**
     * Get the bounding box of this Reservoir Grid (in local coordinates).
     * @returns bbox
     */
    getBoundingBox(): Box3;
    /**
     * Get the reservoir data, holding the cells positions and values.
     * @returns data
     */
    getData(): ReservoirData;
    /**
     * Delete a previously defined additional cell data.<br>
     * @param name The name of the additional data to delete.
     */
    deleteAdditionalCellData(name: string): void;
    /**
     * Return the volume occupied by the remaining cells resulting from the user's filter.<br>
     * Each cell volume is computed based on the cell's xyz corner coordinates.<br>
     * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
     * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
     * @returns the total filtered cells volume.
     */
    getFilteredCellsVolume(): number;
    /**
     * Returns the total volume of this reservoir.<br>
     * Computed by the sum of the volume of every cell, filters are ignored.<br>
     * The unit of the volume measurement is based on the unit used in cells coordinates, to user discretion.
     * (ex: if cells coordinates are in meters, then the volume will be in cubic meters. If feet, then cubic feet, and so on.)
     */
    getReservoirFullVolume(): number;
    /**
     * Return the number of cells resulting from the user's filter.
     */
    getFilteredCellsCount(): number;
    /**
     * Return a new instance of ReservoirData resulting from the user's filter, the cells that are filtered in (are displayed),
     * based on IJK filter, value filter, and the user filter.
     * If no cell is currently visible, null will be returned instead as no ReservoirData can be created.
     */
    getFilteredReservoirData(): ReservoirData | null;
    /**
     * Remove the highlight effect on the selected shape.
     */
    removeHighlightShape(): void;
    /**
     * Used by the rendering pass to know whether this object have its won highlight mechanism, or should the pass itself generate a generic one.
     */
    useOwnHighlight(): boolean;
    /**
     * Get IJK info of selected/highlighted cell.
     */
    getSelectedIJKIndex(): IJKIndex;
    /**
     * Return true if the given IJK is valid by the IJK filter of ReservoirGrid, false if is filtered out.
     */
    isIJKValidInFilter(ijk: IJKIndex | number[]): boolean;
    /**
     * Return true if the given value is bounded by the value filter of this ReservoirGrid, false if the value is filtered out.<br>
     * Also return false if the value is not a number or equal to the defined nullvalue.
     */
    isValueValidInFilter(value: number): boolean;
    /**
     * Return true if the cell of the given index is filtered out (is not displayed), based on both IJK filter, value filter, and the user filter.
     */
    isCellIndexFilteredOut(index: number): boolean;
    /**
     * Dispose this reservoir visual, along its ReservoirData.
     */
    dispose(): void;
    /**
     * Rebuild reservoir geometry depending on filters.<br>
     * Calling ReservoirGrid.setOptions() also rebuilds the reservoir.<br>
     * The main use of this updateCellFilter() function is to update the reservoir when the custom filter is updated
     * via closure variables when setOptions() is not called.
     */
    updateCellFilter(): this;
    /**
     * Build a cell geometry from an existing cell index ijk, that overlaps the aforesaid cell depending on the value
     * entered for the scale parameter. Scale is the percentage of overlapping.<br>
     * The ijk array is the index of the cell in the reservoir: <br>
     * For example, if i=0, j= 4 and z=2, the array will be<br>
     * [ 0, 4, 2 ]<br>
     * If plot is specified, the Geometry will be adapted in "business" coordinates else it will be in local coordinates<br>
     * Business coordinates are obtained using {@link @int/geotoolkit3d/util/Helper~Helper.localToBusiness}
     */
    getCellGeometry(ijk: number[] | IJKIndex, scale: number, plot?: Plot): BufferGeometry;
    /**
     * Get the selected cell geometry. Used in highlighting logic.
     * @deprecated since 5.0, was not meant to be public. To retrieve the currently selected cell, please use getCellGeometry instead.
     */
    getHighlightedObjects(): Mesh | null;
    /**
     * Estimate the maximum number of cells that can be created in one ReservoirGrid visual, with the given RAM/VRAM information.<br>
     * With enough memory, the implementation limit for ReservoirGrid is eventually tied to Typed array allocation.
     * This test will perform a one-time array allocation test on your device, to accurately estimate the maximum array
     * size your browser/device is capable of.
     * It is important to have enough memory available for this test to be accurate.
     */
    static estimateMemoryCapabilities(options: ReservoirGrid.MemoryEstimationOptions): ReservoirGrid.MemoryCapabilitiesInfo;
}
export declare namespace ReservoirGrid {
    export type Options = Merge<OptionsBase, {
        /**
         * The Reservoir cell data to build this reservoir.
         */
        data: ReservoirData;
        /**
         * Disable the Intel integrated GPU warning when using picking with the reservoir grid.<br>
         * This only disable the warning, Reservoir picking is still disabled by default upon detecting Intel iGPU.<br>
         * To enable Reservoir picking and cell highlight when using an integrated GPU, please use ReservoirGrid.setSelectable(true).
         */
        disableigpuwarning?: boolean;
    }>;
    export type OptionsBase = Partial<CommonOptions> & Geometry.Options & Omit<Material.OptionsBase, 'skeleton'> & {
        skeleton?: SkeletonOptions;
    } & Object3D.Options;
    export type OptionsBaseOut = CommonOptions & Required<Geometry.Options> & Material.OptionsBaseOut & Required<Object3D.Options>;
    type CommonOptions = {
        /**
         * If set to true, compute cells volume. If false, will be computed when the volume is first queried.<br>
         * Volume can then be obtained using {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#getReservoirFullVolume}(),
         * or per cell through {@link @int/geotoolkit3d/data/reservoir/hexahedral/ReservoirData~ReservoirData#getCellData}(cellIndex).volume.
         */
        computecellsvolume: boolean;
        /**
         * The reservoir highlight mode.
         */
        highlightmode: HighlightMode;
        /**
         * (Very GPU intensive)
         * If enabled, the reservoir is allowed to render with transparency in case its opacity is set to < 1, or if a colorProvider with transparency is provided.<br>
         * Please be aware that to render the reservoir correctly with transparency, multiple optimizations need to be turned off, which will dramatically reduce the rendering performances.<br>
         * To ensure a correct render, the Plot depth peeling option must be enabled (is enabled by default).
         */
        enabletransparency: boolean;
    };
    export type MemoryCapabilitiesInfo = {
        /**
         * The maximum number of cells that can be loaded safely, with the given memory information.<br>
         * For example, if the result is 1000,000 cells, one can imagine loading a ReservoirGrid of dimensions of
         * 100*100*100 (or any combinations that leads to one million).<br>
         * Please keep in mind this is only an estimation, even if the VRAM option is provided, browsers and OSes handle
         * RAM and VRAM memory very differently.
         */
        maxcells: number;
        /**
         * Describe the current bottleneck for the provided estimation.<br>
         * Please note that if the VRAM argument is not provided, it is not possible to tell if the GPU memory is the current limitation.
         */
        limitation: Limitation;
    };
    export type MemoryEstimationOptions = {
        /**
         * The amount of estimated available RAM in bytes, that the ReservoirGrid visual can allocate.<br>
         * This accounts for the TypedArray passed as constructor parameters to ReservoirData, which are reused internally.<br>
         * On average, ReservoirGrid will use 112 bytes of RAM per cell, with an additional 4 bytes per additional cell property.<br>
         * Additional features such as intersections and transparency can create additional memory spikes.
         */
        ram: number;
        /**
         * (Optional) The amount of estimated available VRAM (Video Memory) in bytes, that the ReservoirGrid visual can allocate.<br>
         * ReservoirGrid will use 100 bytes of VRAM per cell.<br>
         * But for the purpose of estimating the maximum capabilities, this method will assume that all cells will be loaded in GPU memory.
         */
        vram?: number;
        /**
         * (Optional) Ratio of the cells that are occluded compared to total cells count. 0.2 means 20% occluded, and 1
         * means 100% occluded.<br>
         * Thanks to cell occlusion optimization, not all cells are rendered at all time, at most only 60% of cells are
         * visible (40% occluded) at the same time (even with filters applied), and on average 20% only are visible
         * (80% occluded), thus reducing the actual video memory usage.<br>
         * By setting this option the occlusion optimization will be taken into calculation.
         * The total number of cells capable of loading can be larger.
         */
        occlusion?: number;
        /**
         * (Optional) Use an extra amount of RAM per cell if intersections are used.
         * Default is false.
         */
        useintersection?: boolean;
        /**
         * (Optional) Each additional properties (on top of the main property) use an extra 4 bytes per cell.
         * Default value is 0.
         */
        additionalproperties?: number;
    };
    export namespace Geometry {
        type Options = OcclusionOptions & FilterOptions;
        type OcclusionOptions = {
            /**
             * When enabled, the occlusion optimization system will make sure cells can only be occluded (removed from render when possible)
             * if the cell's corners are shared by its 6 direct neighbors (not in diagonal).<br>
             * When disabled however, cells no longer check for corner sharing, meaning seams and faults between cells will no longer prevent them from being occluded.
             * Disabling this option can result in artifacts (ex: seeing inside the reservoir from the outside, hollow reservoir in seams/faults).<br>
             * Enabled by default.
             */
            occlusioncheckcorners?: boolean;
        };
        type FilterOptions = IJKValueFilter & {
            /**
             * If set, define the minimum bounds of the cells allowed to be rendered, such that:<ul>
             * <li>minbound.x => the minimum I index, cells below that index will not be rendered.</li>
             * <li>minbound.y => the minimum J index, cells below that index will not be rendered.</li>
             * <li>minbound.z => the minimum K index, cells below that index will not be rendered.</li>
             * <li>minbound.w => the minimum active property value, cell with a value below that value will not be rendered.</li></ul>
             */
            minbound?: Vector4;
            /**
             * If set, define the maximum bounds of the cells allowed to be rendered, such that:<ul>
             * <li>maxbound.x => the maximum I index, cells above that index will not be rendered.</li>
             * <li>maxbound.y => the maximum J index, cells above that index will not be rendered.</li>
             * <li>maxbound.z => the maximum K index, cells above that index will not be rendered.</li>
             * <li>maxbound.w => the maximum active property value, cell with a value above that value will not be rendered.</li></ul>
             */
            maxbound?: Vector4;
        };
    }
    export namespace Material {
        type OptionsBase = Shader.Options & MeshColorMapBasicMaterial.OptionsBase;
        type OptionsBaseOut = Shader.OptionsOut & MeshColorMapBasicMaterial.OptionsBaseOut;
    }
    export namespace Shader {
        type OptionsOut = {
            skeleton: Required<Omit<SkeletonOptions, 'horizons'>>;
            /**
             * The reservoir can be displayed in several modes available in the enum DisplayMode.<br>
             * These modes allow you to control the visibility of the property, skeleton and horizons.<br>
             * Default value is DisplayMode.IgnoreHorizons.
             */
            mode: DisplayMode;
        };
        type Options = Omit<Partial<OptionsOut>, 'skeleton'> & {
            skeleton?: Partial<Omit<SkeletonOptions, 'horizons'>>;
        };
    }
    export {};
}
