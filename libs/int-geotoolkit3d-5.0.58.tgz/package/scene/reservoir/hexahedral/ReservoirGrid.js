/* eslint-disable */

export {Wzt as ReservoirGrid} from '@int/impl/geotoolkit3d.js';
