/* eslint-disable */

export {Pzt as IJKIndex} from '@int/impl/geotoolkit3d.js';
