/* eslint-disable */

export {b_t as isObjectWithMaterial} from '@int/impl/geotoolkit3d.js';
