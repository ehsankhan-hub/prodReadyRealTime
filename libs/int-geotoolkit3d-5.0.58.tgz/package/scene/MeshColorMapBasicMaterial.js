/* eslint-disable */

export {Rzt as MeshColorMapBasicMaterial} from '@int/impl/geotoolkit3d.js';
