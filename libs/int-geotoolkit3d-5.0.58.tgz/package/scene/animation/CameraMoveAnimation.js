/* eslint-disable */

export {R0t as CameraMoveAnimation} from '@int/impl/geotoolkit3d.js';
