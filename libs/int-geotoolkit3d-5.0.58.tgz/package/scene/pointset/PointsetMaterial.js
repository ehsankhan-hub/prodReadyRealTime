/* eslint-disable */

export {F_t as PointsetMaterial} from '@int/impl/geotoolkit3d.js';
