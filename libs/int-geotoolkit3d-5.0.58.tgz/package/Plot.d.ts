/**
 * @module geotoolkit3d/Plot
 */
import type { ColorRepresentation, Object3D as ThreeObject3D, WebGLInfo, WebGLRendererParameters } from 'three';
import { Box3, OrthographicCamera, PerspectiveCamera, Scene, Vector3, WebGLRenderer } from 'three';
import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
import { AntiAliasing } from '@int/geotoolkit3d/Constants';
import { AnimationManager } from '@int/geotoolkit3d/scene/animation/AnimationManager';
import { Event, Type as BaseType } from '@int/geotoolkit3d/Event';
import { Compass } from '@int/geotoolkit3d/scene/compass/Compass';
import { DepthPeelingPass } from '@int/geotoolkit3d/postprocessing/DepthPeelingPass';
import { SSAARenderPass } from '@int/geotoolkit3d/postprocessing/SSAARenderPass';
import { OutlinePass } from '@int/geotoolkit3d/postprocessing/OutlinePass';
import type { AbstractController } from '@int/geotoolkit3d/controller/AbstractController';
import { Dimension } from '@int/geotoolkit/util/Dimension';
import { AbstractPass } from '@int/geotoolkit3d/postprocessing/AbstractPass';
import { Coordinate } from '@int/geotoolkit3d/util/Helper';
import type { AnchoredShape } from '@int/geotoolkit/scene/shapes/AnchoredShape';
import type { AbstractTool } from '@int/geotoolkit3d/tool/AbstractTool';
/**
 * Enum of built-in camera types.<br>
 * Each Camera has its own projection algorithm.<br>
 * @readonly
 * @enum
 */
export declare enum CameraType {
    /**
     * Camera will be using a perspective projection
     */
    Perspective = "perspective",
    /**
     * Camera will be using an orthographic projection
     */
    Orthographic = "orthographic"
}
/**
 * Enum of ways to have the orthographic camera resize<br>
 * @readonly
 * @enum
 */
export declare enum OrthographicResizeMode {
    /**
     * Cameras view port will not be modified <br>
     */
    None = "None",
    /**
     * Cameras view port will try to maintain the current view scale<br>
     * scene will keep the view but cut off space to maintain view scale.
     */
    MaintainScale = "MaintainScale"
}
/**
 * Enum of built-in controller types.<br>
 * To provide your own controller simply pass the constructor function/class to the setOption instead of one of the enum value.
 * @readonly
 * @enum
 */
export declare enum CameraControllerType {
    /**
     * Moves the camera so that it revolves around a given point.
     */
    Orbit = "orbit",
    /**
     * Behaves like a trackball, the 3D scene being the ball.
     */
    TrackBall = "trackball",
    /**
     * Moves like a first person camera - commonly referred to as FPS controllers
     */
    FirstPerson = "firstperson",
    /**
     * No interactive controller.
     */
    None = "none"
}
/**
 * HighlightType
 * @readonly
 * @enum
 */
export declare enum HighlightType {
    /**
     * 3D object gets highlighted when hovering
     */
    Hover = "hover",
    /**
     * 3D object gets highlighted when clicking
     */
    Click = "click"
}
/**
 * Default Tool Names
 * @readonly
 * @enum
 */
export declare enum DefaultTool {
    /**
     * Highlight Tool
     */
    HighlightTool = "HighlightTool"
}
/**
 * A Plot with 3D capabilities.<br>
 * Unlike a geotoolkit 2D plot, this plot requires a DIV element to be passed and not a canvas.<br>
 * Requires WebGL2 device support (since Toolkit v4.1), see {@link https://webglreport.com/?v=2 WebGL Report}.<br>
 * <br>
 * The plot is internally structured as a SceneGraph using THREE.Scene.<br>
 * It uses a camera system to represent user's eye location in 3D space.<br>
 * This camera position can be moved anywhere in the plot and can look in any direction (although controller are encouraged to limit this freedom to ensure meaningful displays)<br>
 * The camera type and option can be configured at creation or on the fly using setOptions().<br>
 * <br>
 * To increase rendering accuracy the plot will try to compute ideal near/far planes positions and simplify transformation matrices.<br>
 * This mechanism relies on the fact that the plot can compute its own modellimits and that those limits are reasonably small.<br>
 * The rendering accuracy might suffer if modellimits are too big because of GPU floating point computing accuracy.<br>
 * <br>
 * To render its content to the plot a render cycle made is of the following steps:<br>
 * <ul>
 * <li>Call updateObject on <b>all</b> nodes: Offers a chance to each node to update its status before rendering occurs. This should not trigger any invalidation event though.</li>
 * <li>Call prepareRender: Simplifies transformation matrices, move near/far planes to increase accuracy.</li>
 * <li>Call beforeRender on <b>visible</b> nodes. This can be used to update nodes 'on the fly' in the render pass. However be careful when overriding this function as it heavily impacts the rendering logic.</li>
 * <li>Render: The WebGLRenderer traverses the scene, rendering node using WebGL (all GL operations occur at this stage).</li>
 * <li>Call finishRender: Restores the matrices, revert near/far planes.</li>
 * </ul>
 * <br>
 * The updateObject phase differs from beforeRender as it is executed before the plot's matrices/transformation have been simplified&optimized.<br>
 * Which means that its implementation modifies a transformation that will be taken into account during this render pass for the simplification step.<br>
 * However beforeRender is executed after the simplification,  any modification done in this function will be rendered but will not be used for simplification.<br>
 * Also, beforeRender expose a bit more of the internal plot logic and usage of those elements that are not part of the public API should be done with caution.<br>
 * Generally, updateObject is used to implement application level changes.<br>
 * And beforeRender is generally used to execute low level operations like GPU resource loading and management.<br>
 * <br>
 * The plot also exposes some rendering options like anti-aliasing, clear-color or preferred GPU precision.<br>
 * Some of them cannot be changed on the fly though like the transparency of the background.<br>
 * <br>
 * A notification system using EventDispatcher exposes the events occurring in the plot (object added, removed, invalidate, camera changes, etc).<br>
 * One could listen to events occurring on any node of the plot by listening to the Plot's events.<br>
 * Note that you can also send custom events from your nodes to implement your application's logic.<br>
 * See geotoolkit3d.Event.Type for the built-in events.<br>
 * <br>
 * When an event is fired and caught by the plot, it marks itself as dirty.<br>
 * Whenever the next renderCycle occurs (based on requestanimationframe), this flag will be checked.<br>
 * If it's true then a render cycle will occur, otherwise the plot will hibernate until the next requestanimationframe lands.<br>
 * That's why one may need to manually call invalidateObject() on a node after modifying it through direct access (like position, scale, rotation, etc).<br>
 * It will flag the plot as dirty (through the event notification system), resulting in a render.<br>
 * Note that because the rendering is asynchronous, during invalidate several time in a row will trigger only one render.<br>
 * <br>
 * The plot also offers some useful features like built-in lighting (ambient light and camera headlight) and global scale.<br>
 * Those options can be enabled/disabled and configured through the setOptions().<br>
 * <br>
 * Like a geotoolkit widget, the plot uses a Tool system to catch, process and dispatch user input. (See {@link @int/geotoolkit3d/tool/AbstractTool~AbstractTool}).<br>
 * One of those tools is the controller, it's a special tool that allow the user to manipulate the camera using an input device (mouse, touch screen, ...).<br>
 * <br>
 * The plot will also have a compass added to it (as an overlay).<br>
 * This compass can be configured/changed and also replaced by a custom one.<br>
 * <br>
 * The plot provides postprocessing effects like anti-aliasing and outline highlighting.
 * Since post processing is enabled by default, an EffectComposer will be created and will replace WebGLRenderer in animation loop.<br>
 * It renders scene into a 2D image on a render target, and applies some passes to the result before drawing it to the canvas.<br>
 * @throws Will throw an error if the browser does not support WebGL
 */
export declare class Plot extends EventDispatcher {
    /**
     * Create plot
     * @param options options to create plot
     */
    constructor(options: Plot.Options);
    on<E extends keyof Plot.EventMap>(type: E, callback: (eventType: E, sender: this, args: Plot.EventMap[E]) => void): this;
    off<E extends keyof Plot.EventMap>(type?: E, callback?: (eventType: E, sender: this, args: Plot.EventMap[E]) => void): this;
    notify<E extends keyof Plot.EventMap>(type: E, source: Plot, args?: Plot.EventMap[E]): this;
    /**
     * Set options, the given json will be merged with the object's state so that only the given options will be changed.<br>
     * @param options options to set on this object
     * @returns this
     */
    setOptions(options: Plot.OptionsBase): this;
    /**
     * Get the Plot options
     */
    getOptions(): Plot.Options;
    /**
     * Converts user coordinates to world coordinates in place (modifies the given object).<br>
     * <br>
     * User coordinates are world coordinates without global scaling applies.<br>
     * Use `.setOptions({ scale: ... })` to change the global scaling.<br>
     * <br>
     * @param vector3 Source AND target vector3
     * @returns The converted coordinates
     */
    rootScale(vector3: Vector3): Vector3;
    /**
     * Converts world coordinates to user coordinates in place (modifies the given object).<br>
     * <br>
     * User coordinates are world coordinates without global scaling applies.<br>
     * Use `#setOptions({ scale: ... })` to change the global scaling.<br>
     * <br>
     * @param vector3 Source AND target vector3
     * @returns The converted coordinates
     */
    rootScaleInv(vector3: Vector3): Vector3;
    /**
     * Returns camera location in user coordinates.<br>
     * @param [target] Optional target vector
     * @returns The camera location
     */
    getCameraLocation(target?: Vector3): Vector3;
    /**
     * Returns the camera lookat point in user coordinates IF such information is available (depends on the controller used).<br>
     * Otherwise returns camera.location + camera.direction.
     * @param [target] Optional target vector
     * @returns The camera lookat
     */
    getCameraLookAt(target?: Vector3): Vector3;
    /**
     * This function will try to reset the camera position along the y-axis so most of the scene fits into the view.<br>
     * It will also change the camera anchor point to the scene center.<br>
     * If the there is no visible geometry in the scene this will silently fail.
     * @param [animate] Animate the camera change
     * @param [animationDuration] Duration of the animation in milliseconds
     * @returns this
     */
    resetCamera(animate?: boolean, animationDuration?: number): this;
    /**
     * This function will try to adjust the camera position along the direction axis so that most of the scene fits into the view. It
     * will also change the camera anchor point to the scene center.
     * If the there is no visible geometry in the scene this function will silently fail.
     * @param [direction] Direction to move the camera in, will use scene center to camera if null.
     * @param [animate] Animate the camera change
     * @param [animationDuration] Duration of the animation in milliseconds
     * @param [distanceFactor] Distance factor when fitting the camera. Greater than 1 means further from scene center.
     * @param [ignoreZScale] If true, z scale will be ignored
     * @returns this
     */
    fitCamera(direction?: Vector3, animate?: boolean, animationDuration?: number, distanceFactor?: number, ignoreZScale?: boolean): this;
    /**
     * Sets camera location in user coordinates.<br>
     * It is recommended to use #moveCamera() instead as it handles both the location and the direction of the camera.<br>
     * @param position The position to move to (in USER coordinates)
     * @param [animate] Animate the camera change
     * @param [animationDuration] Duration of the animation in milliseconds
     * @returns this
     */
    setCameraLocation(position: Vector3, animate?: boolean, animationDuration?: number): this;
    /**
     * Sets camera target in user coordinates.<br>
     * It is recommended to use #moveCamera() instead as it handles both the location and the direction of the camera.<br>
     * @param lookat The point to look at (in USER coordinates)
     * @param [animate] Animate the camera change
     * @param [animationDuration] Duration of the animation in milliseconds
     * @returns this
     */
    setCameraLookAt(lookat: Vector3, animate?: boolean, animationDuration?: number): this;
    /**
     * Moves the camera to the given position and rotate it to look at the given lookat.<br>
     * Note that the given points should be in user coordinates (world coordinates without global scaling).<br>
     * @param [position] The position to move to in USER coordinates
     * @param [lookAt] The point to look at (in USER coordinates)
     * @param [animate] Animate the camera change
     * @param [animationDuration] Duration of the animation in milliseconds
     * @param [upVector] up vector
     * @returns this
     */
    moveCamera(position?: Vector3, lookAt?: Vector3, animate?: boolean, animationDuration?: number, upVector?: Vector3): this;
    /**
     * Returns the scene graph root.<br>
     * One should use it to append nodes to the scene using the add() function.<br>
     * @returns The root node
     */
    getRoot(): ThreeObject3D;
    /**
     * Returns the scene.<br>
     * Recommended uses are limited to:
     * <ul>
     * <li>Insert 'absolute' positioned objects like directional lights.</li>
     * <li>Used as parameter to {@link @int/geotoolkit3d/scene/grid/Grid~Grid#getMode}().</li>
     * </ul>
     */
    getScene(): Scene;
    /**
     * Returns the scene graph animation manager.<br>
     * This manager should be used to perform smooth animations in the plot.<br>
     * See {@link @int/geotoolkit3d/scene/animation/AnimationManager~AnimationManager} for more details.<br>
     * @returns The animation manager
     */
    getAnimationManager(): AnimationManager;
    /**
     * Returns the compass object.<br>
     * The returned compass can be configured/modified.<br>
     * See {@link @int/geotoolkit3d/scene/compass/Compass~Compass} for more details.<br>
     * @returns The compass object
     */
    getCompass(): Compass;
    /**
     * Set size of the Plot.<br>
     * This increase the rendering-area size (canvas) to the given dimension.<br>
     * It also notifies the WebGl renderer.<br>
     * The given pixelDeviceRatio can be used to take into account the current Browser zoom level.<br>
     * @param width The new width that should be set
     * @param height The new height that should be set
     * @param [pixelDeviceRatio] The pixel device ratio, if unset, will use the value provided by the window if available.
     * @returns this
     */
    setSize(width: number, height: number, pixelDeviceRatio?: number): this;
    /**
     * Manually set the given object to be highlighted. <br>
     * Passing 'null' or an empty parameter will remove the highlight of the currently highlighted object.<br>
     * Conditions required for highlight:
     * <ul>
     * <li>The advanced rendering option is enabled in the plot (enabled by default, unless the browser is not WebGL2 compliant)</li>
     * <li>The given object exist in the scene, and have of highlight capabilities.</li>
     * </ul>
     */
    highlightObject(object?: ThreeObject3D): void;
    /**
     * Add postprocessing pass to the renderer.<br>
     * The pass to be added must inherit {@link @int/geotoolkit3d/postprocessing/AbstractPass~AbstractPass}. <br>
     * The order of passes affects the final output, please use getMultipass and setOptions for ordering.
     * @param pass the postprocessing pass
     * @deprecated since 4.1, please use addPostProcessingPass instead.
     */
    addMultipass(pass: AbstractPass): void;
    /**
     * Get the current user custom postprocessing passes as an array.
     * This return the original array so the order can be modified.
     * @deprecated since 4.1, please use getPostProcessingPasses() instead.
     * If getMultipass() was used to enable highlight on an object, please instead use highlightObject().
     */
    getMultipass(): AbstractPass[];
    /**
     * Add postprocessing pass to the renderer.<br>
     * The pass to be added must inherit {@link @int/geotoolkit3d/postprocessing/AbstractPass~AbstractPass}. <br>
     * The order of passes affects the final output, please use getMultipass and setOptions for ordering.
     * @param pass the postprocessing pass
     */
    addPostProcessingPass(pass: AbstractPass): void;
    /**
     * Get the current user custom postprocessing passes as an array.
     * This return the original array so the order can be modified.
     */
    getPostProcessingPasses(): AbstractPass[];
    /**
     * Get the default antialiasing method according to the pixel scale, screen size and device type
     * The default AA for retina and 2K (2560x1440) and above monitor is fast approximate AA (FXAA), and super-resolution AA (SRAA) for lower resolution.
     * The FXAA requires less computing power hence it is the default AA mode for a mobile
     * @returns antialiasing type
     * @deprecated since 4.1, it was not meant to be public. Default AntiAliasing mode is the default plot mode, unless specified by users.
     * To have the plot use the default AntiAliasing mode, use Plot.setOptions with advancedrendering.antialias.mode: AntiAliasing.AUTO instead
     */
    getDefaultAA(pixelScale: number, screen: Screen): AntiAliasing;
    /**
     * Returns the 'virtual device' size of the plot.<br>
     * <br>
     * This returns the raw size given at initialization or through the setSize function.<br>
     * Ignoring any pixelRatio that could have been set on the WebGL renderer.<br>
     * @param [target] optional object to store the dimensions
     * @returns The plot size
     */
    getSize(target?: Dimension): Dimension;
    /**
     * Returns a copy of the model origin in world coordinates.<br>
     * The model origin is the center of the modellimits.<br>
     * @returns The model origin
     */
    getModelOrigin(): Vector3;
    /**
     * Returns a copy of the modellimits in world coordinates.<br>
     * The returned limits are either the one provided through the setOptions() or the one automatically computed by the plot.<br>
     * @param [viewModelLimits] gets the modelLimits that includes grid sprites and children of objects with a getWorldBoundingBox
     * @param [filter] that gets applied to the compute the model limits
     * @returns The model limits
     * @deprecated since 5.0, because this method would inconsistently return the result with and without the Plot's scale reverted. Please use Plot.getSceneBoundingBox instead.
     */
    getModelLimits(viewModelLimits?: boolean, filter?: Plot.FilterCallback): Box3;
    /**
     * Returns a copy of the scene bounding box based on specified SceneBoundingBoxOptions.<br>
     * The returned scene bounding box are either the one provided through the setOptions() or the one automatically computed by the plot.<br>
     * By default, it returns the bounding box in Business coordinates, which has inverse plot scale applied.<br>
     * To get the bounding box in world coordinate, set options.coordinate to Coordinate.World.
     * @param [target] Target bounding box
     * @param [options] SceneBoundingBoxOptions
     * @returns the scene bounding box
     */
    getSceneBoundingBox(target?: Box3, options?: Plot.SceneBoundingBoxOptions): Box3;
    /**
     * Project the given (world) point to virtual screen space in place.<br>
     * @param point The point to project in world coordinates.<br>
     * @returns The projected point
     */
    project(point: Vector3): Vector3;
    /**
     * Adds and initializes the given tool.<br>
     * The tool will be notified it has been added, and it will attach its system-event listeners.<br>
     * @param tool The tool to initialize and add.
     * @returns this
     */
    addTool(tool: AbstractTool): this;
    /**
     * Finds the tool matching the given name.<br>
     * If several tool match this name, the 'first' is returned.<br>
     * @param name The name of the tool to look for
     */
    getToolByName(name: string): AbstractTool;
    /**
     * Removes a tool (and disposes it).<br>
     * The given tool will be disposed only if it does belong to this plot.<br>
     * @param tool The tool to remove and dispose
     * @returns this
     */
    removeTool(tool: AbstractTool): this;
    /**
     * List all tools in the plot
     * @returns tools
     */
    listTool(): AbstractTool[];
    /**
     * Set the plot as 'dirty' so it gets redrawn during the next render phase.<br>
     * This also propagates an event notifying the plot's listeners that an invalidation has occurred.<br>
     * <br>
     * See {@link @int/geotoolkit3d/Event~Type} for built-in events, custom event types can also be used.<br>
     * @param [event] The event that should be propagated as the reason of the invalidation
     * @returns this
     */
    invalidateObject<T>(event?: Event<T>): this;
    /**
     * Updates the model limits of the Plot by computing it using the current scene state.<br>
     * <br>
     * If 'autoupdatemodellimits' is enabled, this should be called automatically when some operations occur (adding, removing a node, etc).<br>
     * <br>
     * However it should be called manually if an object in the scene is moved outside the current modellimits manually.<br>
     * For example by changing its position attribute.<br>
     * <br>
     * The modellimits are used internally to improves accuracy of rendering & picking.<br>
     * Note: this method can have side effects if non-standard filter was used.
     * @param [filter] gets applied to the compute of model limits
     * @param [alwaysTraverseChildren] Forces the calculation to traverse children to get the extents of the whole view
     * @returns this
     */
    updateModelLimits(filter?: Plot.FilterCallback, alwaysTraverseChildren?: boolean): this;
    /**
     * Gets the WebGLRenderer
     * @returns renderer
     */
    getRenderer(): WebGLRenderer;
    /**
     * Returns usage statistics like WebGl calls per frame or amount of vertices rendered per frame.
     * @returns The statistics see THREE.WebGLRenderer.info for more details.
     */
    getUsageStatistics(): WebGLInfo;
    /**
     * Disposes the plot and all its resources.<br>
     * To do so, all objects contained in the scene will be disposed.<br>
     * The tools registered on this plot will also be disposed.<br>
     */
    dispose(): void;
    /**
     * Gets camera
     */
    getCamera(): PerspectiveCamera | OrthographicCamera;
    /**
     * Gets container where canvas is added
     * @returns container
     */
    getContainer(): HTMLElement;
    /**
     * Gets canvas element where the scene is drawn
     * @returns canvas element where the scene is drawn
     */
    getCanvasElement(): HTMLCanvasElement | null;
    /**
     * Set watermark to draw over plot 3d
     * @param watermark watermark
     * @returns this
     */
    setWatermark(watermark: AnchoredShape): this;
    /**
     * Apply a translation to the root and camera for higher precision. <br>
     * Because renderer has a high precision error when working with large positions, set the root and camera closer to origin improves the accuracy.
     * Note that it temporarily changes camera's position, i.e. during beforeRender().
     * @param enabled to enable
     */
    setOriginTranslation(enabled: boolean): void;
    /**
     * Get performance metrics
     * @returns Plot.PerformanceMetrics
     */
    getPerformanceMetrics(): Plot.PerformanceMetrics;
    /**
     * Check if GPU Performance Metric is supported
     * @returns true if supported, otherwise false
     */
    isGPUPerformanceSupported(): boolean;
    /**
     * Force plot to trigger quality pass
     */
    renderQualityPass(): void;
}
export declare namespace Plot {
    /**
     * The Plot constructor options.
     */
    export type Options = OptionsBase & {
        /**
         * The div element in which the canvas will be added
         */
        container?: HTMLElement;
        /**
         * If true, the plot will automatically update when a node is invalidated
         */
        autoupdate?: boolean;
        /**
         * Auto update time interval. window.requestAnimationFrame will be used if available and autoUpdateInterval not specified
         */
        autoupdateinterval?: number;
        /**
         * True to let the plot update the modellimits when an object is inserted/removed into the scene. If an object is moved outside of the current modellimits you can manually call plot.updateModelLimits()
         */
        autoupdatemodellimits?: boolean;
        /**
         * Apply a translation to the root and camera for higher precision. The side effect is it temporarily changes camera's position, i.e. during beforeRender().
         */
        applyorigintranslation?: boolean;
    };
    /**
     * Options accepted by Plot.setOptions
     */
    export type OptionsBase = {
        /**
         * The modellimits, necessary if autoupdatemodellimits is not enabled. Should be the boundingbox of the scene.
         */
        modellimits?: Box3;
        /**
         * This position becomes the effective origin for the scene for scaling purposes.
         */
        translation?: Vector3;
        /**
         * The global scale to be applied to the scene graph. This change the relation between user coordinates and world coordinates
         */
        scale?: Vector3;
        /**
         * The camera options
         */
        camera?: CameraOptions;
        /**
         * The renderer configuration
         */
        renderer?: RendererOptions & {
            /**
             * The renderer configuration. See ThreeJS documentation. (Note: you can set logarithmicDepthBuffer false to improve performance, but there may be some artifacts)
             */
            parameters?: WebGLRendererParameters;
            devicepixelratio?: number;
        };
        /**
         * Ambient lighting options
         */
        ambientlighting?: AmbientLightingOptions;
        /**
         * The camera lighting options
         */
        cameralighting?: CameraLightingOptions;
        /**
         * The advanced rendering options.
         * @deprecated since 4.1, please use advancedrendering instead.
         * These options have been reworked in 4.1 to be cleaner and more consistent.
         * Because of the amount of change, it is advised to verify your Plot options match the API.
         */
        postprocessing?: PostProcessingOptions;
        /**
         * The advanced rendering options.
         */
        advancedrendering?: AdvancedRenderingOptions;
        /**
         * The default compass options.
         */
        compass?: CompassOptions;
        /**
         * Flag for performance tools (frame rate and memory), default false.<br>
         * When stats is enabled, the plot will perform continuous rendering, otherwise, the plot will perform default lazy rendering.
         */
        stats?: boolean;
        /**
         * Flag for displaying stats panels when stats is enabled. By default, when stats enabled, all panels will be displayed.
         */
        statspanels?: StatsPanelOptions;
        /**
         * Picking cache settings.
         */
        picking?: PickingOptions;
        /**
         * Options for debugging
         */
        debug?: {
            /**
             * Flag for enforcing materials' depthWrite to be enabled
             * Materials usually should write to the depthBuffer when rendering. Some 3D engines can use transparend materials which doesn't write to the depthBuffer,
             * but the Toolkit does not work this way.<br>
             * This check make sure all materials are writing to the depthBuffer, for correct rendering.
             * Default is true.
             */
            enforcematerialdepthwrite?: boolean;
        };
    };
    export type CameraOptions = {
        /**
         * The camera type
         */
        type?: CameraType;
        /**
         * The location of the camera in the scene
         */
        position?: Vector3;
        /**
         * The coordinates of the point the camera will look at
         */
        lookat?: Vector3;
        /**
         * The field-of-view angle in degrees (applies only to perspective camera)
         */
        fov?: number;
        /**
         * The frustum near clipping plane. (By default is computed automatically)<br>
         * Define the distance in front of the camera before objects start rendering (visible objects are rendered between the near and far planes).<br>
         * Generally, users want the near and far planes to be as close to each other as possible to ensure Z-buffer
         * accuracy, while maintaining all objects on screen visible.<br>
         * The toolkit will automatically compute this near value based on the objects on screen, but it can be set manually with this option.<br>
         * Setting this option, or setting the option 'autonear' to false, will both disable automatic near calculation (for advanced users).<br>
         * For more information about near/far planes, see this {@link https://learnopengl.com/Guest-Articles/2021/Scene/Frustum-Culling OpenGL tutorial}.
         */
        near?: number;
        /**
         * True if let the plot compute the ideal near plane that fit the current modellimits and provide the best accuracy.<br>
         * Default value is true.<br>
         * When 'autonear' is set to false, please define 'near'. Otherwise, Plot will automatically set default value 1 for 'near'.<br>
         * When 'near' and 'autonear' are both defined, 'autonear' will have priority.<br>
         */
        autonear?: boolean;
        /**
         * The frustum far clipping plane. (By default is computed automatically)<br>
         * Define the distance in front of the camera before objects stops rendering (visible objects are rendered between the near and far planes).<br>
         * Generally, users want the near and far planes to be as close to each other as possible to ensure Z-buffer
         * accuracy, while maintaining all objects on screen visible.<br>
         * The toolkit will automatically compute this far value based on the objects on screen, but it can be set manually with this option.<br>
         * Setting this option, or setting the option 'autofar' to false, will both disable automatic far calculation (for advanced users).<br>
         * For more information about near/far planes, see this {@link https://learnopengl.com/Guest-Articles/2021/Scene/Frustum-Culling OpenGL tutorial}.
         */
        far?: number;
        /**
         * True if let the plot compute the ideal far plane that fit the current modellimits and provide the best accuracy.<br>
         * The actual far plane value will be returned in 'far' when getOptions.<br>
         * Default value is true.<br>
         * When 'autofar' is set to false, please define 'far'. Otherwise, Plot will automatically set default value 100000 for 'far'.<br>
         * When 'far' and 'autofar' are both defined, 'autofar' will have priority.
         */
        autofar?: boolean;
        /**
         * when set to auto clipping planes (autonear is true or near is 'auto'), this is the minimum value that will be set on the near plane.<br>
         * Default value is 1, minimum valid value is 0.001 (0 will cause rendering issues).
         */
        minnear?: number;
        /**
         * when set to Auto clipping planes (autofar is true or far is 'auto'), this is the minimum value that will be set on the far plane.<br>
         * Default value is 2.
         */
        minfar?: number;
        /**
         * This option can be used to maintain a minimum near/far ratio, to help with depth accuracy.<br>
         * Because of how floats variables handle precision, there can be a loss of accuracy (Z-fighting, clipping artifacts) when the near plane is very close and the far plane is very far to the camera. For this reason, the near distance can be automatically adjusted to enforce a minimum ratio.<br>
         * Example, if near=0.01 and far=200000, the ratio is 0.01 / 200 000 = 20 000 000, this is too high and could lead to accuracy issues.)<br>
         * By setting a nearfarscale ratio of 30000 (a recommended value), the above example near would be increased from 0.01 to 6.66, and would ensure accurate depth in the scene.<br>
         * This adjustment can be disabled by setting the nearfarscale to 0.<br>
         * Default value is 30000.
         */
        nearfarscale?: number;
        /**
         * The way a plot handles resize when in Orthographic mode
         */
        orthoresize?: OrthographicResizeMode;
        /**
         * The camera controller configuration
         */
        controller?: ControllerOptions;
        /**
         * The camera 'up' direction (or camera roll).
         * When moving the camera, this control where the camera 'up' is relative to the scene axes. This do not affect
         * the camera orientation, but define the "roll" axis.<br>
         * Default is +Z (0, 0, +1).
         */
        up?: Vector3;
    };
    export type FilterCallback = (o: ThreeObject3D) => boolean;
    type RendererOptions = {
        /**
         * The renderer clearcolor color
         */
        clearcolor?: ColorRepresentation;
        /**
         * The renderer clearcolor alpha value (0,1)
         */
        clearcoloralpha?: number;
    };
    type AmbientLightingOptions = {
        /**
         * Determines if the ambient light is enabled
         */
        enabled?: boolean;
        /**
         * The color of the ambient light.
         */
        color?: ColorRepresentation;
    };
    type CameraLightingOptions = {
        /**
         * Set to true to enable camera lighting.
         */
        enabled?: boolean;
        /**
         * The color of the camera light.
         */
        color?: string;
        /**
         * The intensity of the camera light.<br>
         * Default value is Math.PI.
         */
        intensity?: number;
    };
    export type AdvancedRenderingOptions = AbstractPass.BaseRenderPassOptions & AbstractPass.MainRenderPassOptions & SSAARenderPass.SSAARenderOptions & DepthPeelingPass.DepthPeelingPassOptions & OutlinePass.OutlinePassOptions & {
        /**
         * The base options for RenderPasses supporting forms of Anti-Aliasing.
         */
        antialias?: AbstractPass.AntialiasOptions;
        /**
         * Highlight options.
         */
        highlight?: {
            /**
             * True if need to highlight edges of meshes.
             */
            highlightedges?: boolean;
            /**
             * The highlight mode, define if the highlight is triggered on mouse hover, or on mouse click.
             */
            mode?: HighlightType;
        };
        /**
         * Disable advanced rendering passes.
         * @deprecated option since 4.1, it is no longer relevant to disable advanced rendering passes this way.
         */
        enabled?: boolean;
        /**
         * Quality Render pass options.
         */
        qualityrenderpass?: {
            /**
             * When enabled, a Quality render pass will be drawn after a set time (see option 'timeout') after the last scene or camera update.<br>
             * A Quality render will fire a QualityRender event from the Plot, signaling compatible objects to produce a higher quality rendering if applicable.<br>
             * Even if disabled, Quality render can still be programmatically triggered via the Plot.renderQualityPass() method.<br>
             * Default value is false.
             */
            enable?: boolean;
            /**
             * The delay for triggering a Quality render after the last scene/camera update.<br>
             * Rendering a Quality frame will be preceded by a Type.QualityRendering event.<br>
             * Default value is 500 milliseconds.<br>
             * Please note that too smalls value will cause frequent change between quality rendering and fast rendering.
             */
            timeout?: number;
        };
        performancemetrics?: {
            /**
             * The desired GPU frametime in milliseconds when rendering.<br>
             * A frametime is the time the GPU takes to render a frame. For example, to maintain a fluid 30 frames per seconds, the desired frametime should be 33 ms.<br>
             * If current frametime exceed this value, objects that can adapt will reduce rendering quality to try to maintain the desired frametime.<br>
             * Custom user objects can make use of these performance metrics by inheriting from geotoolkit3d/scene/Object3D and overriding the method onStatsUpdated().<br>
             * Default value is 33 ms (1 second / 30 FPS => 33ms).
             */
            targetgpuframetime?: number;
            /**
             * The desired CPU frametime in milliseconds when rendering.<br>
             * A frametime is the time the CPU takes to render a frame. For example, to maintain a fluid 30 frames per seconds, the desired frametime should be 33 ms.<br>
             * If current frametime exceed this value, objects that can adapt will reduce rendering quality to try to maintain the desired frametime.<br>
             * Custom user objects can make use of these performance metrics by inheriting from geotoolkit3d/scene/Object3D and overriding the method onStatsUpdated().<br>
             * Default value is 33 ms (1 second / 30 FPS => 33ms).
             */
            targetcpuframetime?: number;
            /**
             * Frame number between each metric update.<br>
             * Default value is 100.
             */
            updateframeperiod?: number;
        };
    };
    export type PostProcessingOptions = AdvancedRenderingOptions;
    type CompassOptions = {
        /**
         * An optional container for the default compass, if not specified one will be created. Note that in order to be correctly positioned, this container requires the given container to have a 'position' set.
         */
        container?: HTMLElement;
        /**
         * An optional canvas to render the compass to
         */
        canvas?: HTMLElement;
        /**
         * flag to create the compass canvas.
         */
        enabled?: boolean;
        /**
         * renderer options for the compass
         */
        renderer?: {
            /**
             * renderer parameters for the compass
             */
            parameters?: WebGLRendererParameters;
        };
    };
    export type PickingOptions = {
        /**
         * True to enable the picking cache system. Default is true.<br>
         * Picking cache can save costly picking calculations by returning the cached picking result when conditions are met:<ul><li>
         * -two or more consecutive picking are done in very short timespan, configured by 'cachetimelimit'.</li><li>
         * -consecutive picking settings are identical to cached picking result: pick origin (caller), pick diameter, cursor position.</li></ul>
         * Use cases:<br>
         * On view with multiple tools, or with high refresh rate, multiple pickings can be requested in a very short amount of time.
         * Because picking is a costly process, involving offscreen-rendering all objects several time for each picking,
         * this can dramatically increase power consumption or induce performance loss when unnecessary picking are requested.
         */
        usecache?: boolean;
        /**
         * The lifespan of the picking cache in milliseconds, after which the picking result is automatically invalidated.<br>
         * Default is 33ms (the duration of a frame when rendering at 30FPS).
         */
        cachetimelimit?: number;
    };
    type ControllerOptions = {
        /**
         * The controller to be used to change the camera location.
         */
        type?: CameraControllerType | ControllerClass;
        /**
         * Set to true to automatically rotate around object. (only supports OrbitController)<br>
         * If the controller is changed, autorotate will be set to false (unless specified otherwise).
         */
        autorotate?: boolean;
        /**
         * The controller options.
         * Please refer to the related Controller implementation for the complete list of options.
         * For TypeScript compliance, this field might need a type cast, ex:<br>
         * @example
         * 'options': {
         *    'pointerlock': true // Not an AbstractController option
         * } as FirstPersonController.Options
         */
        options?: AbstractController.Options;
    };
    export type ControllerClass = {
        new (options: {
            camera?: PerspectiveCamera | OrthographicCamera;
            plot?: Plot;
            position?: Vector3;
            lookat?: Vector3;
        }): AbstractController;
    };
    type EventArgs<T> = {
        source: Event.Source;
        args: T;
    };
    export type EventMap = EventDispatcher.EventMap & {
        [BaseType.BeforeRender]: void;
        [BaseType.AfterRender]: void;
        [BaseType.Invalidate]: void;
        [BaseType.DuringRender]: void;
        [BaseType.RenderError]: void;
        [BaseType.Remove]: EventArgs<ThreeObject3D | ThreeObject3D[]>;
        [BaseType.Camera]: void;
        [BaseType.Animation]: void;
        [BaseType.ModelLimits]: void;
        [BaseType.QualityRendering]: void;
        [BaseType.FastRendering]: void;
    };
    /**
     * Performance metrics:<br>
     * We measure performance information by looking at both the CPU and the GPU rendering/update time.<br>
     * To maintain a target framerate, the corresponding time spend on each frame (the frametime) must be kept within limits.<br>
     * Example: On standard monitors, maximum refresh rate is 60 FPS (frame per seconds), this is (1/60) ~16.6ms per frame. If the frametime is <16.6ms it will be very fluid.<br>
     * If the frametime is >50ms (~20 FPS) it will start to feel very sluggish.<br>
     *
     * In most cases, CPU and GPU times are asynchronous, meaning while the GPU renders, the CPU can continue working on other tasks and even prepare the next frame.<br>
     * This means, for example, to maintain a steady 60 FPS, the time spent in each frame in GPU render must be <16.6ms AND the time spend in CPU update must be <16.6ms too.<br>
     * If one of them is too slow, the framerate will be affected. For this reason, a balance between CPU and GPU cost must be achieved when the scene is complex or when the hardware is not powerful enough.
     */
    export type PerformanceMetrics = {
        /**
         * Current target CPU frametime set by Plot option performancemetrics.targetcpuframetime.
         */
        targetcpuframetime: number;
        /**
         * Current target GPU frametime set by Plot option performancemetrics.targetgpuframetime.
         */
        targetgpuframetime: number;
        /**
         * The average GPU frametime (the time the GPU spend to render a frame) over the period since the last performance metric update.<br>
         * Will not be available on devices not support EXT_disjoint_timer_query_webgl2.<br>
         * User can check if GPU performance metrics is supported by Plot.isGPUPerformanceSupported
         */
        averagegpuframetime: number | null;
        /**
         * The array of individual GPU frametimes (the time the GPU spend to render a frame).<br>
         * The number of frames to log can be defined by Plot option performancemetrics.updateframeperiod.<br>
         * Will not be available on devices not support EXT_disjoint_timer_query_webgl2.<br>
         * User can check if GPU performance metrics is supported by Plot.isGPUPerformanceSupported
         */
        gpuframetimes: number[] | null;
        /**
         * The average CPU frametime (the time the CPU spend to render a frame) over the period since the last performance metric update.
         */
        averagecpuframetime: number;
        /**
         * The array of individual CPU frametimes (the time the CPU spend to render a frame).<br>
         * The number of frames to log can be defined by Plot option performancemetrics.updateframeperiod.<br>
         */
        cpuframetimes: number[];
    };
    /**
     * Stats Panel Options<br>
     * When Plot option.stats is enabled, user can further configure the visibility of each performance metric panel.
     */
    export type StatsPanelOptions = {
        /**
         * Show GPU Frametime panel, default true.
         */
        showgputime?: boolean;
        /**
         * Show CPU Frametime panel, default true.
         */
        showcputime?: boolean;
        /**
         * Show FPS panel, default true.
         */
        showframepersecond?: boolean;
        /**
         * Show heap memory panel, default true.
         */
        showheapmemory?: boolean;
        /**
         * Optional offset to manually position the panel using absolute positioning.<rb>
         * Values represent pixel offsets from the top-left corner of the canvas.
         */
        positionoffset?: {
            /**
             * Distance in pixels from the top edge.<rb>
             * Default is 0.
             */
            top?: number;
            /**
             * Distance in pixels from the left edge.<br>
             * Default is 0.
             */
            left?: number;
        };
    };
    /**
     * Options for Plot.getSceneBoundingBox<br>
     */
    export type SceneBoundingBoxOptions = {
        /**
         * The coordinate space of the return bounding box.<br>
         * Default value is Coordinate.Business.
         */
        coordinate?: Coordinate;
        /**
         * A filter function to ignore some nodes if callback returns false.<br>
         * Default is null.
         */
        filter?: Plot.FilterCallback;
        /**
         * gets the bounding box that includes grid sprites and children of objects
         */
        traversechildren?: boolean;
    };
    export {};
}
