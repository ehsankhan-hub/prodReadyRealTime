/* eslint-disable */

export {Ani as SeismicVolume} from '@int/impl/geotoolkit3d.js';
