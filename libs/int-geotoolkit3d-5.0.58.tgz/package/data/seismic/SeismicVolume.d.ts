import { EventDispatcher } from '@int/geotoolkit/util/EventDispatcher';
import type { IndexCoordinates } from '@int/geotoolkit3d/transformation/IndexCoordinates';
import type { RemoteReaderDataProvider } from '@int/geotoolkit/seismic/data/RemoteReaderDataProvider';
import type { SeismicReader } from '@int/geotoolkit/seismic/data/SeismicReader';
/**
 * Defines an abstract implementation of a seismic volume data.
 */
export declare abstract class SeismicVolume extends EventDispatcher {
    protected constructor();
    /**
     * Open seismic volume and return itself when it is ready to display
     */
    abstract open(): Promise<SeismicVolume>;
    /**
     * Volume original coordinates
     */
    abstract getOriginalIndexCoordinates(): IndexCoordinates;
    /**
     * Volume coordinates
     */
    abstract getIndexCoordinates(): IndexCoordinates;
    /**
     * Volume IJK information
     */
    abstract getIJK(): SeismicVolume.IJKCoordinates;
    /**
     * Returns seismic reader for spectified location
     * @param location slice location
     * @param seismic reader for spectified location
     */
    abstract getReader(location: SeismicVolume.Location, lod?: number): Promise<SeismicReader>;
}
export declare namespace SeismicVolume {
    type Options = {};
    type IJKCoordinates = {
        I?: RemoteReaderDataProvider.SeismicKey;
        J?: RemoteReaderDataProvider.SeismicKey;
        K?: RemoteReaderDataProvider.SeismicKey;
    };
    type IndexCoordinates = {
        i0?: number;
        istep?: number;
        icount?: number;
        j0?: number;
        jstep?: number;
        jcount?: number;
        z0?: number;
        samplerate?: number;
        samplecount?: number;
    };
    type Location = {
        /**
         * The inline number of the section
         */
        i?: number;
        /**
         * The xline number of the section
         */
        j?: number;
        /**
         * The sample <b>index</b> of the horizontal slice
         */
        k?: number;
        /**
         * The sample <b>index</b> of the horizontal slice
         */
        z?: number;
    };
}
