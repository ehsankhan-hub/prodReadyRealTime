/* eslint-disable */

export {W8t as AbstractSurfaceData} from '@int/impl/geotoolkit3d.js';
