/* eslint-disable */

export {k9t as SurfaceData} from '@int/impl/geotoolkit3d.js';
