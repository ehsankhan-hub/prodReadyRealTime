/* eslint-disable */

export {X8t as TrimeshSurfaceData} from '@int/impl/geotoolkit3d.js';
