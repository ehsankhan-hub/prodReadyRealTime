/* eslint-disable */

export {Qti as VTKLoader} from '@int/impl/geotoolkit3d.js';
