/* eslint-disable */

export {Eti as VTKFactory} from '@int/impl/geotoolkit3d.js';
