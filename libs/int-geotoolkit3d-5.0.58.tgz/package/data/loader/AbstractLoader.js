/* eslint-disable */

export {i7t as AbstractLoader} from '@int/impl/geotoolkit3d.js';
