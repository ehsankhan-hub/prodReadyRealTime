/* eslint-disable */

export {Iii as MultiLateralWellData} from '@int/impl/geotoolkit3d.js';
