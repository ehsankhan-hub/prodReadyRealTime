/* eslint-disable */

export {Zii as MultiLateralPipeData} from '@int/impl/geotoolkit3d.js';
