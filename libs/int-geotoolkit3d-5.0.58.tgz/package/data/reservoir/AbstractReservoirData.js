/* eslint-disable */

export {Osi as AbstractReservoirData} from '@int/impl/geotoolkit3d.js';
