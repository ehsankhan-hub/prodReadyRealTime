/* eslint-disable */

export {zsi as ReservoirData} from '@int/impl/geotoolkit3d.js';
