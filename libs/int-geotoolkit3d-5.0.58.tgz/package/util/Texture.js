/* eslint-disable */

export {UXt as Texture} from '@int/impl/geotoolkit3d.js';
