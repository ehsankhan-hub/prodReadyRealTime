import { Box3, Color, LineBasicMaterial, LineDashedMaterial, MeshLambertMaterial, MeshPhongMaterial } from 'three';
import type { BufferAttribute, MeshBasicMaterial, MeshMatcapMaterial, MeshStandardMaterial, MeshToonMaterial, PointsMaterial, ShadowMaterial, SpriteMaterial } from 'three';
import { LineStyle } from '@int/geotoolkit/attributes/LineStyle';
import type { FillStyle } from '@int/geotoolkit/attributes/FillStyle';
import { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
import type { HsvColor } from '@int/geotoolkit/util/HsvColor';
import type { HlsColor } from '@int/geotoolkit/util/HlsColor';
/**
 * Utility class offering various functions to manipulate attributes and threejs materials.<br>
 * <br>
 */
export declare class Attributes {
    /**
     * Builds a line material for the given linestyle.<br>
     * Note that current implementation assumes that the given style is immutable and therefore will not listen to its changes.<br>
     * <br>
     * Note that supported patterns are only the simple regular ones.<br>
     * Per THREEJS requirements for the LineDashedMaterial you will also have to call line.computeLineDistances() on your THREE.Line object.<br>
     * <br>
     * Note that style.width is not supported on windows-webgl.<br>
     * See:<br>
     * {@link https://threejs.org/docs/#api/en/objects/Line.computeLineDistances}<br>
     * {@link http://alteredqualia.com/tmp/webgl-linewidth-test/}<br>
     * {@link http://en.wikipedia.org/wiki/WebGL#Desktop_browsers}<br>
     * {@link https://code.google.com/p/angleproject/issues/detail?id=334}<br>
     * <br>
     * @param style The style to use to create a material
     * @returns The created material
     */
    static createLineMaterial(style: LineStyle.Type): LineBasicMaterial | LineDashedMaterial;
    /**
     * Build a mesh material (Lambertian reflectance) for the given fillstyle.<br>
     * Note that current implementation assumes that the given style is immutable and therefore will not listen to its changes. <br>
     * To update the material color, please use Attributes.updateMeshMaterial().
     * @param color The color or FillStyle to build a material for. Most known color format are accepted, such as RgbaColor, HSVColor, Three.js Color and so on.
     * @returns The created material
     */
    static createMeshMaterial(color: FillStyle.Type | Attributes.ColorType): MeshLambertMaterial;
    /**
     * Build a mesh material (Phong reflectance) for the given color/fillstyle.<br>
     * Note that current implementation assumes that the given style is immutable and therefore will not listen to its changes. <br>
     * To update the material color, please use Attributes.updateMeshMaterial().
     * @param color The color or FillStyle to build a material for. Most known color format are accepted, such as RgbaColor, HSVColor, Three.js Color and so on.
     * @returns The created material
     */
    static createPhongMeshMaterial(color: FillStyle.Type | Attributes.ColorType): MeshPhongMaterial;
    /**
     * Convert most known color representation to the Three.js color format, with separated opacity and RGB values.
     * @param color a color representation in most known color formats.
     */
    static getThreeColor(color: FillStyle.Type | Attributes.ColorType): {
        color: Color;
        opacity: number;
    };
    /**
     * Convert a css-color or RgbaColor to a THREE.js color, with separated opacity and RGB values.
     * @param color The color in css format or RgbaColor format.
     * @returns A json containing the converted color and the corresponding opacity
     */
    static getThreeColorFromCssRgba(color: string | RgbaColor): {
        color: Color;
        opacity: number;
    };
    /**
     * Updates the given material color with the given FillStyle/Color.<br>
     * @param material The material to update.
     * @param color a color representation in most known color formats.
     * @returns The updated material
     */
    static updateMeshMaterial(material: Attributes.ColorMaterial, color: FillStyle.Type | Attributes.ColorType): Attributes.ColorMaterial;
    /**
     * Fit the given index array to the smallest precision needed to be able to represent the maximum index.<br>
     * This ensure memory savings if the maximum index is below Uint16 or Uint8 max value.<br>
     * Return the same array if the type is already a good fit.
     * @param array the array.
     * @param maxIndex the maximum index value if it is known. If not defined, the given array will be parsed to evaluate the max index value.
     * @returns the Uint BufferAttribute
     */
    static fitUintTypedArray(array: number[] | Uint8Array | Uint16Array | Uint32Array, maxIndex?: number): Uint8Array | Uint16Array | Uint32Array;
    /**
     * Creates and returns a typed array of unsigned integers (Uint8Array, Uint16Array, or Uint32Array)
     * that can represent the provided maximum value.
     * @param {number} maxValue - The maximum value for determining the type of the unsigned integer array.
     * Depending on the value, the method selects the appropriate typed array.
     * @param {number} arraySize - The array size.
     * @returns {Uint8Array | Uint16Array | Uint32Array} A typed array of unsigned integers accommodating
     * to the specified maximum value.
     */
    static createUintTypedArray(maxValue: number, arraySize: number): Uint8Array | Uint16Array | Uint32Array;
    /**
     * Compute the 3D bounding box, but only considering the triangles indexed by the given index buffer.<br>
     * This is useful when the BufferAttribute can include invalid data such as surfaces having NaN elevations in some Z values.
     */
    static computeBoundingBoxFromIndexedBuffer(positionBuffer: BufferAttribute, indexBuffer: BufferAttribute, target?: Box3): Box3;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace Attributes {
    /**
     * All known color formats.
     */
    type ColorType = RgbaColor | HsvColor | HlsColor | Color | string;
    /**
     * Most Three.js materials that can be colored by a single solid color.
     */
    type ColorMaterial = MeshLambertMaterial | MeshPhongMaterial | MeshBasicMaterial | MeshMatcapMaterial | MeshStandardMaterial | MeshToonMaterial | PointsMaterial | ShadowMaterial | SpriteMaterial;
}
