/* eslint-disable */

export {$ti as Well, Wti as OffsetMode} from '@int/impl/geotoolkit3d.js';
