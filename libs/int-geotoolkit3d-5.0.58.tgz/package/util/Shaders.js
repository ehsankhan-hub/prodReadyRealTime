/* eslint-disable */

export {MVt as Shaders} from '@int/impl/geotoolkit3d.js';
