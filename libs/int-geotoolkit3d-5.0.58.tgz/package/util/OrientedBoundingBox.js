/* eslint-disable */

export {R1t as OrientedBoundingBox} from '@int/impl/geotoolkit3d.js';
