/* eslint-disable */

export {I6t as CameraFrustumDebug} from '@int/impl/geotoolkit3d.js';
