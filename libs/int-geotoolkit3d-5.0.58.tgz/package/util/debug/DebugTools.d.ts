/**
 * @module geotoolkit3d/util/debug/DebugTools
 */
import { Box3 } from 'three';
import type { Color } from 'three';
export declare namespace DebugTools {
    /**
     * Options for generating a wireframe visual of a given bounding box.
     */
    type BoxHelperOptions = {
        /**
         * The Three.js Box3 to visualize.
         */
        box: Box3;
        /**
         * The color of the wireframe to generate.<br>
         * Default is red.
         */
        color?: string | Color;
        /**
         * The width of the wireframe lines.<br>
         * Default is 1.
         */
        width?: number;
        /**
         * Optional scaling for the box size. it can be useful to use different scales for multiple box to avoid z-fighting or improve visual reading.<br>
         * Default is 1
         */
        boxscale?: number;
    };
}
