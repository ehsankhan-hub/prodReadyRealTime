/* eslint-disable */

export {e6t as AbstractInterpolator} from '@int/impl/geotoolkit3d.js';
