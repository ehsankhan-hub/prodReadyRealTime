/* eslint-disable */

export {r6t as InverseDistanceWeighting} from '@int/impl/geotoolkit3d.js';
