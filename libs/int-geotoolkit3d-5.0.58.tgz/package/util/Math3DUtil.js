/* eslint-disable */

export {Ujt as Math3DUtil} from '@int/impl/geotoolkit3d.js';
