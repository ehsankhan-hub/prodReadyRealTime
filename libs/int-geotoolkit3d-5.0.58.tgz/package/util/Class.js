/* eslint-disable */

export {IOt as Class} from '@int/impl/geotoolkit3d.js';
