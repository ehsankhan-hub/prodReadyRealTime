/* eslint-disable */

export {nXt as ObjectProcessor} from '@int/impl/geotoolkit3d.js';
