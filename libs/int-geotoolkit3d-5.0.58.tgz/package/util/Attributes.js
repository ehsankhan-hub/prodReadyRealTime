/* eslint-disable */

export {oZt as Attributes} from '@int/impl/geotoolkit3d.js';
