/* eslint-disable */

export {C8t as IntersectionNotSupportedError} from '@int/impl/geotoolkit3d.js';
