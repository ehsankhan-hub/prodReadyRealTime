/* eslint-disable */

export {OWt as IOverlayableObject} from '@int/impl/geotoolkit3d.js';
