/* eslint-disable */

export {A8t as Intersection} from '@int/impl/geotoolkit3d.js';
