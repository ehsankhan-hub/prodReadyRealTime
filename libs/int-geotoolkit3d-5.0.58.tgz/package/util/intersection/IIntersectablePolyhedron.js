/* eslint-disable */

export {Ozt as IIntersectablePolyhedron} from '@int/impl/geotoolkit3d.js';
