/* eslint-disable */

export {XWt as IntersectionManager} from '@int/impl/geotoolkit3d.js';
