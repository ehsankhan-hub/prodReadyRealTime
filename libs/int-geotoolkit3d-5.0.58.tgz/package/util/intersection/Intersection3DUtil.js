/* eslint-disable */

export {s6t as Intersection3DUtil} from '@int/impl/geotoolkit3d.js';
