import { Mesh, Vector3 } from 'three';
import type { Object3D } from 'three';
import { IIntersectableMesh } from '@int/geotoolkit3d/util/intersection/IIntersectableMesh';
import type { Plot } from '@int/geotoolkit3d/Plot';
import { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import { LineSegments } from '@int/geotoolkit3d/scene/LineSegments';
import { PointSet } from '@int/geotoolkit3d/scene/pointset/PointSet';
import { Surface } from '@int/geotoolkit3d/scene/surface/Surface';
import type { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
import { ColorProviderName, ResultType, ValueName } from '@int/geotoolkit3d/util/intersection/Constants';
import { IIntersectablePolyhedron } from '@int/geotoolkit3d/util/intersection/IIntersectablePolyhedron';
import { Rect } from '@int/geotoolkit/util/Rect';
import { IOverlayableObject } from '@int/geotoolkit3d/util/intersection/IOverlayableObject';
/**
 * Utility class for generating and visualizing 3D intersections.
 * @example
 * Intersection3DUtil.generateIntersection(objectA, objectB, plot, intersectOption)
 *  .then((intersectionResult) => {
 *      const visualResult = Intersection3DUtil.generateIntersectionVisuals(intersectionResult, visualOptions);
 *      if (visualResult['linesegments'] != null) {
 *          plot.getRoot().add(visualResult['linesegments']);
 *      }
 *      if (visualResult['pointset'] != null) {
 *          plot.getRoot().add(visualResult['pointset']);
 *      }
 *      if (visualResult['surface'] != null) {
 *          plot.getRoot().add(visualResult['surface']);
 *      }
 *   })
 *  .catch((err) => {
 *   });
 */
export declare class Intersection3DUtil {
    /**
     * Generates the 3D intersection result for the given object pair, via an asynchronous Promise.<br>
     * For the intersection to succeed, both objects should be intersectable.
     * This means, both ObjectA and ObjectB should be, or contain at least one child who are either:
     * <ul>
     * <li>
     * A regular Three.js Mesh, not instanced.
     * </li>
     * <li>
     * Implement one of the intersection interfaces such as {@link @int/geotoolkit3d/util/intersection/IIntersectableMesh~IIntersectableMesh} and
     * {@link @int/geotoolkit3d/util/intersection/IIntersectablePolyhedron~IIntersectablePolyhedron}
     * </li>
     * </ul>
     * For complex user-made objects such as instanced geometries, or objects made of multiple nested sub-Objects,
     * it is the user's responsibility to implement the intersection interfaces so that intersections can be generated.<br>
     * When both ObjectA and ObjectB parameters contain eligible objects for intersection,
     * the first intersectable object in each group will be found and intersected.<br>
     * If multiple intersectable objects are contained in either ObjectA or B,
     * only one will be intersected by default and a warning will be logged.<br>
     * The result will depend on the nature of the intersected objects, as well as how they intersect.
     * For example, Mesh-Mesh intersection usually provide lines, but can occasionally produce points (when vertices share identical positions) or triangles (when two intersecting triangles are also co-planar).<br>
     * Mesh-Polyhedron intersection provide triangles.<br>
     * Important: For now, the intersection algorithm expect the polyhedron of the IIntersectablePolyhedron object to be convex.
     * It can work with slightly concave polyhedron, but artifacts are expected.
     * Affected Toolkit object includes ReservoirGrid, if the cell of a ReservoirGrid is concave, the intersection result will not be perfect.<br>
     * More intersection types will be supported in the future.
     * @param objectA Object3D that is Intersection3DUtil.Intersectable or contains one Intersection3DUtil.Intersectable.
     * @param objectB Object3D that is Intersection3DUtil.Intersectable or contains one Intersection3DUtil.Intersectable.
     * @param plot (optional) the 3D plot contains both objects, it is necessary when the global scale is applied to the scene graph via plot.options.scale
     * @param options Intersection3DUtil.Options
     * @returns Intersection3DUtil.Result
     * @throws {NoIntersectableError} if objectA or objectB lacks a valid intersectable object.
     * @throws {IntersectionNotSupportedError} if not support intersection between objectA and objectB.
     * @throws {IntersectionCancelledError} if current queued intersection Promises being cancelled.
     */
    static generateIntersection(objectA: Object3D | Intersection3DUtil.Intersectable, objectB: Object3D | Intersection3DUtil.Intersectable, plot?: Plot, options?: Intersection3DUtil.IntersectionOptions): Promise<Intersection3DUtil.Result>;
    /**
     * Generate intersection visual objects from intersection result
     * @param intersectionResult Intersection3DUtil.Result from Intersection3DUtil.generateIntersection method
     * @param options Intersection3DUtil.VisualOptions to configure visual effect of the intersection
     * @returns Intersection3DUtil.VisualResult
     */
    static generateIntersectionVisuals(intersectionResult: Intersection3DUtil.Result, options?: Intersection3DUtil.VisualOptions): Intersection3DUtil.VisualResult;
    /**
     * Convert the 3D intersection results into the given plane object.<br>
     * The result returned will be a deep copy of the original results, where instead the X and Y values will be updated, and the Z values will be set to 0.<br>
     * The Rect of the given plane is also returned so that the result can be further transformed to any canvas or texture coordinate.
     * @param result3D the intersection result to project to the given plane.
     * @param plane the plane object.
     * @param plot (optional) the 3D plot contains scale, it is necessary when the global scale is applied to the scene graph via plot.options.scale
     */
    static projectResultToPlane(result3D: Intersection3DUtil.Result, plane: Intersection3DUtil.PlaneObject, plot?: Plot): Intersection3DUtil.Result2D | null;
    /**
     * Convert the 3D intersection results into the given 2D plane.<br>
     * To do so, the orientation of the 2D plane must be located in 3D space first, using 3 points.
     * If the 2D plane have an equivalent plane/rectangle shape in 3D, these points would be its corners.<br>
     * The result returned will be a deep copy of the original results, where instead the X and Y values will be updated, and the Z values will be set to 0.<br>
     * The Rect of the given plane is also returned so that the result can be further transformed to any canvas or texture coordinate.
     * @param result3D the intersection result to project to the given plane.
     * @param planeCorner0 the 3D coordinate of the left top corner of the plane in business coordinate.
     * @param planeCorner1 the 3D coordinate of the right top corner of the plane in business coordinate.
     * @param planeCorner2 the 3D coordinate of the left bottom corner of the plane in business coordinate.
     */
    static projectResultTo2D(result3D: Intersection3DUtil.Result, planeCorner0: Vector3, planeCorner1: Vector3, planeCorner2: Vector3): Intersection3DUtil.Result2D;
    /**
     * Return the valid intersectable objects contained in the provided Object3D/Group.<br>
     * Please note that generateIntersection() expects only one intersectable object on each side. To intersect more objects, we recommend to make multiple calls to generateIntersection() for each pair to intersect.<br>
     * This method can be used by users to check how many objects can be intersected in the given group. If the returned array contain more than one intersectable, only the first in the array would be intersected by a single call to generateIntersection().
     */
    static getIntersectableObjects(obj: Object3D): Intersection3DUtil.Intersectable[];
    /**
     * Cancel the currently queued intersection Promises, causing them to reject early.
     */
    static clearQueuedIntersections(): void;
    static getClassName(): string;
}
export declare namespace Intersection3DUtil {
    /**
     * Options for Intersection3DUtil.generateIntersection().
     */
    type IntersectionOptions = {
        /**
         * If true, the method will compute and return the value of the intersected points if values are available.<br>
         * The values can either from object A or/and object B and can be used to color the intersection with color provider.<br>
         * Default value is true.
         */
        computevalue?: boolean;
    };
    /**
     * Intersection results.<br>
     * The content will change based on the intersected objects and options.<br>
     * When a mesh intersecting another mesh will produce Intersection3DUtil.MeshMeshResult.<br>
     * When a mesh intersecting polyhedron will produce Intersection3DUtil.MeshPolyhedronResult.<br>
     */
    type Result = MeshMeshResult & {
        type: ResultType.MeshMesh;
    } | MeshPolyhedronResult & {
        type: ResultType.MeshPolyhedron;
    };
    /**
     * Projected intersection results.<br>
     * Result2D is the result that project 3D intersection result to a given 2D plane.<br>
     * They shared the same structure as 3D result Intersection3DUtil.Result, except the z coordinates of the result are all zero.<br>
     * The Rect bounds of the given plane is also returned, so that the result can be transformed to any texture or canvas.
     */
    type Result2D = MeshMeshResult & {
        /**
         * Type of the result.
         */
        type: ResultType.MeshMesh;
        /**
         * The Rect bounds of the given plane in business space coordinate.
         */
        rect: Rect;
    } | MeshPolyhedronResult & {
        /**
         * Type of the result.
         */
        type: ResultType.MeshPolyhedron;
        /**
         * The Rect bounds of the given plane in business space coordinate.
         */
        rect: Rect;
    };
    /**
     * Common intersection result shared by different intersection type.
     */
    type CommonResult = {
        /**
         * The nullvalue for the object A values (if applicable).<br>
         * nullvalues are used to represent values that should be ignored and not rendered.
         */
        nullvaluea: number | null;
        /**
         * The colorprovider of the object A. If no colorprovider, the object material's solid color and opacity will be returned as ColorProvider.
         */
        colorprovidera: ColorProvider;
        /**
         * The nullvalue for the object B values (if applicable).<br>
         * nullvalues are used to represent values that should be ignored and not rendered.
         */
        nullvalueb: number | null;
        /**
         * The colorprovider of the object B. If no colorprovider, return the object material's solid color and opacity will be returned as ColorProvider.
         */
        colorproviderb: ColorProvider;
    };
    /**
     * The result of the intersection between two mesh objects.<br>
     * Mesh includes Toolkit objects like Plane, PlaneCurtain, Surface, native Three.js Mesh, and custom intersectable mesh object if implements {@link @int/geotoolkit3d/util/intersection/IIntersectableMesh~IIntersectableMesh}.<br>
     * When two surfaces intersect, the result may contains points, lines, or polygons, depending on how they intersect.
     */
    type MeshMeshResult = CommonResult & {
        /**
         * Intersection result as individual points.<br>
         * This consists of discrete 3D points, formed by two intersecting triangles in specific conditions.<br>
         * Two intersecting triangles can form points in these scenario:
         * <ul>
         * <li>Triangle A's only contact is with one of Triangle B's corner.</li>
         * <li>Only one of Triangle A's edge intersect with one of Triangle B's edge, forming a point instead of a line.</li>
         * <ul>
         */
        points: PointsResult;
        /**
         * Intersection result as lines.<br>
         * The intersection consists of discrete points that the triangles from the two meshes intersect at two points.
         * Two intersecting triangles can form lines in these scenario:
         * <ul>
         * <li>The two triangle faces crosses each other, while not coplanar (most common case).</li>
         * <li>The two triangles have one collinear edge.</li>
         * <ul>
         */
        lines: LinesResult;
        /**
         * Intersection result as polygons.<br>
         * If the intersection forms polygons, it indicates that some triangles from both meshes are coplanar.<br>
         * Instead of merely touching at points or edges, these triangles share a common plane, creating a contiguous polygonal region.
         */
        polygons: PolygonsResult;
    };
    /**
     * The result of the intersection between mesh and polyhedron objects.<br>
     * Mesh includes Toolkit objects like Plane, PlaneCurtain, Surface, native Three.js Mesh, and custom intersectable mesh object if implements {@link @int/geotoolkit3d/util/intersection/IIntersectableMesh~IIntersectableMesh}.<br>
     * polyhedron objects includes Toolkit objects like ReservoirGrid and custom intersectable polyhedron object if implements {@link @int/geotoolkit3d/util/intersection/IIntersectablePolyhedron~IIntersectablePolyhedron}.<br>
     * When mesh and polyhedron intersects, the result contains polygons.
     */
    type MeshPolyhedronResult = CommonResult & {
        /**
         * Intersection result as polygons.<br>
         */
        polygons: PolygonsResult;
    };
    /**
     * Intersection result as individual points
     */
    type PointsResult = {
        /**
         * Intersection result as individual points [p1x, p1y, p1z, p2x, p2y, p2z, etc].<br>
         * Might be empty if the intersection produced no points.
         */
        positions: number[];
        /**
         * The intersected points values for object A (if applicable). One value per point.
         */
        valuea?: number[];
        /**
         * The intersected points values for object B (if applicable). One value per point.
         */
        valueb?: number[];
    };
    /**
     * Intersection result as line segments
     */
    type LinesResult = {
        /**
         * Intersection result as pair of points/segments [a1x, a1y, a1z, b1x, b1y, b1z, a2x, a2y, a2z, b2x, b2y, b2z, etc].<br>
         * Might be empty if the intersection produced no lines.
         */
        positions: number[];
        /**
         * The intersected points values for object A (if applicable). One value per point.
         */
        valuea?: number[];
        /**
         * The intersected points values for object B (if applicable). One value per point.
         */
        valueb?: number[];
    };
    /**
     * Intersection result as polygons
     */
    type PolygonsResult = {
        /**
         * Intersection result as individual polygons, each made of points in circular order [[p1x1, p1y1, p1z1, ...], [p2x1, p2y1, p2z1, ...] ...].<br>
         * Might be empty if the intersection produced no polygons.
         */
        positions: number[];
        /**
         * The intersected points values for object A (if applicable). One value per point.
         */
        valuea?: number[];
        /**
         * The intersected points values for object B (if applicable). One value per point.
         */
        valueb?: number[];
    };
    /**
     * The options for Intersection3DUtil.generateIntersectionVisuals() to generate the visual representation of the intersection result.
     */
    type VisualOptions = {
        /**
         * Use this colorprovider/color for the visual, instead of the intersected object's.
         */
        overridecolorprovider?: ColorProvider | RgbaColor | string;
        /**
         * Which object's colorprovider or color to use for the visual. <br>
         * If overridecolorprovider is provided, we will use the override color instead of the colorprovidertouse.
         */
        colorprovidertouse?: ColorProviderName;
        /**
         * Which object values to use with the colorprovider.<br>
         * It is possible to use ObjectA values with ObjectB ColorProvider if desired (or vice-versa), but this only make sense if both objects share the same property or same colorMap.
         */
        valuestouse?: ValueName;
        /**
         * Options for points created from Intersection3DUtil.Result.points
         */
        pointoptions?: PointOptions;
        /**
         * Options for line segments created from Intersection3DUtil.Result.lines
         */
        lineoptions?: LineOptions;
        /**
         * Options for polygons created from Intersection3DUtil.Result.polygons
         */
        polygonoptions?: PolygonOptions;
    };
    /**
     * Options for points.<br>
     * More options can be set directly on the resulting points visual object, please see {@link @int/geotoolkit3d/scene/pointset/PointSet~PointSet#setOptions} for more details.
     */
    type PointOptions = {
        /**
         * Size of the points.<br>
         * Default value is 5;
         */
        pointsize?: number;
        /**
         * True if the point size should only depend on their value, ignores the projection and any scale.<br>
         * Default is false.
         */
        pointsizeindevice?: boolean;
        /**
         * If true and if the intersection produce points, Point visual will be generated.<br>
         * Default is true.
         */
        generatepoints?: boolean;
    };
    /**
     * Options for line segments.<br>
     * More options can be set directly on the resulting line segments visual object, please see {@link @int/geotoolkit3d/scene/LineSegments~LineSegments#setOptions} for more details.
     */
    type LineOptions = {
        /**
         * The line width.<br>
         * Default value is 3;
         */
        linewidth?: number;
        /**
         * If true, will enable polygon offset to prevent z-fighting.<br>
         * polygon offset apply a negative offset on the camera Z axis in the shaders, to make the line more 'in front' of the other objects, reducing depth buffer occlusion by other objects.<br>
         * Default value is true.
         */
        polygonoffset?: boolean;
        /**
         * Factors for polygon offset.<br>
         * Default value is 4.
         */
        polygonoffsetfactor?: number;
        /**
         * If true and if the intersection produce lines, Line visual will be generated.<br>
         * Default is true.
         */
        generatelines?: boolean;
    };
    /**
     * Options for polygons.<br>
     * More options can be set directly on the resulting polygon visual object, please see {@link @int/geotoolkit3d/scene/surface/Surface~Surface#setOptions} for more details.
     */
    type PolygonOptions = {
        /**
         * If true, will enable polygon offset to prevent z-fighting.<br>
         * polygon offset apply a negative offset on the camera Z axis in the shaders, to make the line more 'in front' of the other objects, reducing depth buffer occlusion by other objects.<br>
         * Default value is true.
         */
        polygonoffset?: boolean;
        /**
         * Factors for polygon offset.<br>
         * Default value is 4.
         */
        polygonoffsetfactor?: number;
        /**
         * If true and if the intersection produce polygons, Surface visual will be generated.<br>
         * Default is true.
         */
        generatepolygons?: boolean;
        /**
         * If true the surface will compute lighting effect.
         * Default is false.
         */
        enableshading?: boolean;
    };
    /**
     * Result for visual object of intersection
     */
    type VisualResult = {
        /**
         * PointSet to visualize intersection points.
         */
        pointset: PointSet | null;
        /**
         * LineSegments to visualize intersection lines.
         */
        linesegments: LineSegments | null;
        /**
         * Surface to visualize intersection polygons.
         */
        surface: Surface | null;
    };
    /**
     * Object types eligible for intersection.<br>
     * Three.js Mesh must not be instanced, if so, users need to implement one of the Intersectable interfaces such as {@link @int/geotoolkit3d/util/intersection/IIntersectableMesh~IIntersectableMesh}.
     */
    type Intersectable = Mesh | IIntersectableMesh | IIntersectablePolyhedron;
    /**
     * Plane object to project 3D intersection result.<br>
     * In Toolkit, plane objects include FencePanel, Slice, and Plane.
     */
    type PlaneObject = IOverlayableObject;
}
