import type { Box3, Triangle } from 'three';
import type { ColorProvider } from '@int/geotoolkit/util/ColorProvider';
import type { RgbaColor } from '@int/geotoolkit/util/RgbaColor';
/**
 * Define an interface to provide a way to retrieve intersection related data from a mesh object.<br>
 * 3D Objects implementing this interface will now be eligible for 3D intersection, via the {@link @int/geotoolkit3d/util/intersection/Intersection3DUtil~Intersection3DUtil} utility.
 * @interface
 */
export declare abstract class IIntersectableMesh {
    /**
     * Return the triangle data at given index.<br>
     * Vertices coordinates must be in the local coordinate space of the object inheriting this interface.
     * @param triangleIndex the index of the triangle
     * @param target result
     */
    abstract getTriangle(triangleIndex: number, target: IIntersectableMesh.TriangleData): void;
    /**
     * Return the number of triangle.
     */
    abstract getTriangleCount(): number;
    /**
     * Return the bounding box of the mesh.<br>
     * The bounding box should be calculated directly from the mesh's geometry vertex positions, representing the bounding box.
     * The box coordinates must be in the local coordinate space of the object inheriting this interface.
     * @param target result
     */
    abstract getMeshBoundingBox(target: Box3): void;
    /**
     * Return the color provider of the intersectable.
     */
    abstract getColorProvider(): ColorProvider | RgbaColor;
    static getClassName(): string;
    getClassName(): string;
}
export declare namespace IIntersectableMesh {
    type TriangleData = {
        /**
         * Triangle of the mesh.<br>
         * triangle.a, triangle.b and triangle.c corresponding to the three vertices position of the triangle.
         * Vertices coordinates must be in the local coordinate space of the object inheriting this interface.
         */
        triangle: Triangle;
        /**
         * Value per vertex.<br>
         * Each vertex of the triangle can have a value property to be used for rendering with ColorProvider.
         */
        value?: number[];
    };
}
