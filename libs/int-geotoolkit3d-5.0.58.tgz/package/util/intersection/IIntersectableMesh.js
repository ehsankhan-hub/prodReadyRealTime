/* eslint-disable */

export {A4t as IIntersectableMesh} from '@int/impl/geotoolkit3d.js';
