/* eslint-disable */

export {fVt as WebGLConstants} from '@int/impl/geotoolkit3d.js';
