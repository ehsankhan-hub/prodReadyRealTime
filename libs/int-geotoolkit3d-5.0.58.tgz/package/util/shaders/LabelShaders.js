/* eslint-disable */

export {Y3t as LabelShaders} from '@int/impl/geotoolkit3d.js';
