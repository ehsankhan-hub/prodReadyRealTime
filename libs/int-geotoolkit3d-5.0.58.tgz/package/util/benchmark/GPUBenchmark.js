/* eslint-disable */

export {w6t as GPUBenchmark} from '@int/impl/geotoolkit3d.js';
