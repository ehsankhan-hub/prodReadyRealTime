/* eslint-disable */

export {gVt as ShaderPass} from '@int/impl/geotoolkit3d.js';
