/* eslint-disable */

export {EOt as FullScreenQuad} from '@int/impl/geotoolkit3d.js';
