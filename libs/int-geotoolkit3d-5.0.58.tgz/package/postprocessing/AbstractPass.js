/* eslint-disable */

export {BOt as AbstractPass} from '@int/impl/geotoolkit3d.js';
