/* eslint-disable */

export {yXt as DepthPeelingPass} from '@int/impl/geotoolkit3d.js';
