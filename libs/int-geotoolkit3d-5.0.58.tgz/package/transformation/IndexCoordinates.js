/* eslint-disable */

export {x1t as IndexCoordinates} from '@int/impl/geotoolkit3d.js';
