/* eslint-disable */

export {qZt as XYCoordinates} from '@int/impl/geotoolkit3d.js';
